﻿namespace 生殖中心病例管理系统
{
    partial class 男方病例form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(男方病例form));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboBox30 = new System.Windows.Forms.ComboBox();
            this.comboBox27 = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.comboBox16 = new System.Windows.Forms.ComboBox();
            this.comboBox17 = new System.Windows.Forms.ComboBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.comboBox18 = new System.Windows.Forms.ComboBox();
            this.comboBox19 = new System.Windows.Forms.ComboBox();
            this.comboBox20 = new System.Windows.Forms.ComboBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.comboBox21 = new System.Windows.Forms.ComboBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.comboBox63 = new System.Windows.Forms.ComboBox();
            this.label67 = new System.Windows.Forms.Label();
            this.comboBox62 = new System.Windows.Forms.ComboBox();
            this.label66 = new System.Windows.Forms.Label();
            this.comboBox68 = new System.Windows.Forms.ComboBox();
            this.label72 = new System.Windows.Forms.Label();
            this.comboBox67 = new System.Windows.Forms.ComboBox();
            this.label71 = new System.Windows.Forms.Label();
            this.comboBox66 = new System.Windows.Forms.ComboBox();
            this.label70 = new System.Windows.Forms.Label();
            this.comboBox65 = new System.Windows.Forms.ComboBox();
            this.label69 = new System.Windows.Forms.Label();
            this.comboBox61 = new System.Windows.Forms.ComboBox();
            this.label65 = new System.Windows.Forms.Label();
            this.comboBox64 = new System.Windows.Forms.ComboBox();
            this.label68 = new System.Windows.Forms.Label();
            this.comboBox60 = new System.Windows.Forms.ComboBox();
            this.label64 = new System.Windows.Forms.Label();
            this.comboBox59 = new System.Windows.Forms.ComboBox();
            this.label63 = new System.Windows.Forms.Label();
            this.comboBox58 = new System.Windows.Forms.ComboBox();
            this.label62 = new System.Windows.Forms.Label();
            this.comboBox57 = new System.Windows.Forms.ComboBox();
            this.label61 = new System.Windows.Forms.Label();
            this.comboBox56 = new System.Windows.Forms.ComboBox();
            this.label60 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.comboBox39 = new System.Windows.Forms.ComboBox();
            this.comboBox52 = new System.Windows.Forms.ComboBox();
            this.comboBox51 = new System.Windows.Forms.ComboBox();
            this.comboBox47 = new System.Windows.Forms.ComboBox();
            this.comboBox50 = new System.Windows.Forms.ComboBox();
            this.comboBox46 = new System.Windows.Forms.ComboBox();
            this.comboBox49 = new System.Windows.Forms.ComboBox();
            this.comboBox45 = new System.Windows.Forms.ComboBox();
            this.comboBox55 = new System.Windows.Forms.ComboBox();
            this.comboBox54 = new System.Windows.Forms.ComboBox();
            this.comboBox53 = new System.Windows.Forms.ComboBox();
            this.comboBox48 = new System.Windows.Forms.ComboBox();
            this.comboBox44 = new System.Windows.Forms.ComboBox();
            this.comboBox43 = new System.Windows.Forms.ComboBox();
            this.comboBox42 = new System.Windows.Forms.ComboBox();
            this.comboBox41 = new System.Windows.Forms.ComboBox();
            this.comboBox40 = new System.Windows.Forms.ComboBox();
            this.comboBox38 = new System.Windows.Forms.ComboBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox28 = new System.Windows.Forms.ComboBox();
            this.comboBox37 = new System.Windows.Forms.ComboBox();
            this.comboBox35 = new System.Windows.Forms.ComboBox();
            this.comboBox33 = new System.Windows.Forms.ComboBox();
            this.comboBox31 = new System.Windows.Forms.ComboBox();
            this.comboBox36 = new System.Windows.Forms.ComboBox();
            this.comboBox34 = new System.Windows.Forms.ComboBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.comboBox32 = new System.Windows.Forms.ComboBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.comboBox29 = new System.Windows.Forms.ComboBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.comboBox25 = new System.Windows.Forms.ComboBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.comboBox23 = new System.Windows.Forms.ComboBox();
            this.comboBox22 = new System.Windows.Forms.ComboBox();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.comboBox26 = new System.Windows.Forms.ComboBox();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.comboBox24 = new System.Windows.Forms.ComboBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox141 = new System.Windows.Forms.ComboBox();
            this.label153 = new System.Windows.Forms.Label();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.label151 = new System.Windows.Forms.Label();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.label149 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(866, 416);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.AutoScrollMargin = new System.Drawing.Size(33, 33);
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(231)))), ((int)(((byte)(239)))));
            this.tabPage1.Controls.Add(this.dateTimePicker1);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(858, 390);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "     既往病史     ";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(640, 42);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(151, 21);
            this.dateTimePicker1.TabIndex = 24;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.comboBox4);
            this.groupBox3.Controls.Add(this.textBox5);
            this.groupBox3.Location = new System.Drawing.Point(113, 500);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(678, 100);
            this.groupBox3.TabIndex = 23;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "家族遗传史";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(89, 40);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(512, 20);
            this.comboBox4.TabIndex = 3;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(69, 39);
            this.textBox5.MaxLength = 1;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(20, 21);
            this.textBox5.TabIndex = 2;
            this.textBox5.Text = "无";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.comboBox6);
            this.groupBox5.Controls.Add(this.textBox7);
            this.groupBox5.Location = new System.Drawing.Point(113, 607);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(678, 100);
            this.groupBox5.TabIndex = 23;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "不孕不育病史";
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(89, 41);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(512, 20);
            this.comboBox6.TabIndex = 3;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(69, 40);
            this.textBox7.MaxLength = 1;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(20, 21);
            this.textBox7.TabIndex = 2;
            this.textBox7.Text = "无";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.comboBox30);
            this.groupBox4.Controls.Add(this.comboBox27);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.label34);
            this.groupBox4.Location = new System.Drawing.Point(113, 449);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(678, 45);
            this.groupBox4.TabIndex = 22;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "婚育史";
            // 
            // comboBox30
            // 
            this.comboBox30.FormattingEnabled = true;
            this.comboBox30.Items.AddRange(new object[] {
            "否",
            "是"});
            this.comboBox30.Location = new System.Drawing.Point(77, 14);
            this.comboBox30.Name = "comboBox30";
            this.comboBox30.Size = new System.Drawing.Size(71, 20);
            this.comboBox30.TabIndex = 1;
            this.comboBox30.Text = "否";
            // 
            // comboBox27
            // 
            this.comboBox27.FormattingEnabled = true;
            this.comboBox27.Items.AddRange(new object[] {
            "否",
            "是"});
            this.comboBox27.Location = new System.Drawing.Point(205, 14);
            this.comboBox27.Name = "comboBox27";
            this.comboBox27.Size = new System.Drawing.Size(71, 20);
            this.comboBox27.TabIndex = 1;
            this.comboBox27.Text = "否";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(170, 17);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(29, 12);
            this.label29.TabIndex = 0;
            this.label29.Text = "再婚";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(18, 17);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(53, 12);
            this.label34.TabIndex = 0;
            this.label34.Text = "近亲结婚";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboBox15);
            this.groupBox2.Controls.Add(this.comboBox12);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.comboBox13);
            this.groupBox2.Controls.Add(this.textBox13);
            this.groupBox2.Controls.Add(this.comboBox16);
            this.groupBox2.Controls.Add(this.comboBox17);
            this.groupBox2.Controls.Add(this.textBox15);
            this.groupBox2.Controls.Add(this.textBox16);
            this.groupBox2.Controls.Add(this.comboBox18);
            this.groupBox2.Controls.Add(this.comboBox19);
            this.groupBox2.Controls.Add(this.comboBox20);
            this.groupBox2.Controls.Add(this.textBox17);
            this.groupBox2.Controls.Add(this.textBox18);
            this.groupBox2.Controls.Add(this.textBox19);
            this.groupBox2.Controls.Add(this.comboBox21);
            this.groupBox2.Controls.Add(this.textBox20);
            this.groupBox2.Location = new System.Drawing.Point(113, 355);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(678, 88);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "个人史";
            // 
            // comboBox15
            // 
            this.comboBox15.FormattingEnabled = true;
            this.comboBox15.Location = new System.Drawing.Point(495, 60);
            this.comboBox15.Name = "comboBox15";
            this.comboBox15.Size = new System.Drawing.Size(106, 20);
            this.comboBox15.TabIndex = 3;
            this.comboBox15.Text = "良好";
            // 
            // comboBox12
            // 
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Location = new System.Drawing.Point(274, 60);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(106, 20);
            this.comboBox12.TabIndex = 3;
            this.comboBox12.Text = "良好";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(460, 63);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 12);
            this.label14.TabIndex = 2;
            this.label14.Text = "现在";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(386, 42);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(101, 12);
            this.label15.TabIndex = 2;
            this.label15.Text = "重大精神刺激疾史";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(460, 22);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 2;
            this.label16.Text = "吸毒";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(10, 63);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 2;
            this.label18.Text = "出生缺陷";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(10, 42);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 2;
            this.label19.Text = "习惯用药";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(191, 64);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(77, 12);
            this.label20.TabIndex = 2;
            this.label20.Text = "健康状况过去";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(203, 43);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 12);
            this.label21.TabIndex = 2;
            this.label21.Text = "药物过敏史";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(239, 22);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 12);
            this.label22.TabIndex = 2;
            this.label22.Text = "酗酒";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(34, 22);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(29, 12);
            this.label23.TabIndex = 2;
            this.label23.Text = "吸烟";
            // 
            // comboBox13
            // 
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Location = new System.Drawing.Point(515, 39);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(86, 20);
            this.comboBox13.TabIndex = 1;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(495, 38);
            this.textBox13.MaxLength = 1;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(20, 21);
            this.textBox13.TabIndex = 0;
            this.textBox13.Text = "无";
            // 
            // comboBox16
            // 
            this.comboBox16.FormattingEnabled = true;
            this.comboBox16.Location = new System.Drawing.Point(515, 19);
            this.comboBox16.Name = "comboBox16";
            this.comboBox16.Size = new System.Drawing.Size(86, 20);
            this.comboBox16.TabIndex = 1;
            // 
            // comboBox17
            // 
            this.comboBox17.FormattingEnabled = true;
            this.comboBox17.Location = new System.Drawing.Point(294, 40);
            this.comboBox17.Name = "comboBox17";
            this.comboBox17.Size = new System.Drawing.Size(86, 20);
            this.comboBox17.TabIndex = 1;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(495, 18);
            this.textBox15.MaxLength = 1;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(20, 21);
            this.textBox15.TabIndex = 0;
            this.textBox15.Text = "无";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(274, 39);
            this.textBox16.MaxLength = 1;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(20, 21);
            this.textBox16.TabIndex = 0;
            this.textBox16.Text = "无";
            // 
            // comboBox18
            // 
            this.comboBox18.FormattingEnabled = true;
            this.comboBox18.Location = new System.Drawing.Point(89, 59);
            this.comboBox18.Name = "comboBox18";
            this.comboBox18.Size = new System.Drawing.Size(86, 20);
            this.comboBox18.TabIndex = 1;
            // 
            // comboBox19
            // 
            this.comboBox19.FormattingEnabled = true;
            this.comboBox19.Location = new System.Drawing.Point(294, 20);
            this.comboBox19.Name = "comboBox19";
            this.comboBox19.Size = new System.Drawing.Size(86, 20);
            this.comboBox19.TabIndex = 1;
            // 
            // comboBox20
            // 
            this.comboBox20.FormattingEnabled = true;
            this.comboBox20.Location = new System.Drawing.Point(89, 40);
            this.comboBox20.Name = "comboBox20";
            this.comboBox20.Size = new System.Drawing.Size(86, 20);
            this.comboBox20.TabIndex = 1;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(69, 60);
            this.textBox17.MaxLength = 1;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(20, 21);
            this.textBox17.TabIndex = 0;
            this.textBox17.Text = "无";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(274, 19);
            this.textBox18.MaxLength = 1;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(20, 21);
            this.textBox18.TabIndex = 0;
            this.textBox18.Text = "无";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(69, 39);
            this.textBox19.MaxLength = 1;
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(20, 21);
            this.textBox19.TabIndex = 0;
            this.textBox19.Text = "无";
            // 
            // comboBox21
            // 
            this.comboBox21.FormattingEnabled = true;
            this.comboBox21.Location = new System.Drawing.Point(89, 20);
            this.comboBox21.Name = "comboBox21";
            this.comboBox21.Size = new System.Drawing.Size(86, 20);
            this.comboBox21.TabIndex = 1;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(69, 19);
            this.textBox20.MaxLength = 1;
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(20, 21);
            this.textBox20.TabIndex = 0;
            this.textBox20.Text = "无";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(113, 80);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(678, 157);
            this.textBox2.TabIndex = 20;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(71, 110);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(32, 26);
            this.button1.TabIndex = 19;
            this.button1.Text = "+";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(69, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 18;
            this.label3.Text = "现病史";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(113, 42);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(443, 21);
            this.textBox1.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(585, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 14;
            this.label2.Text = "初诊时间";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(67, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 15;
            this.label1.Text = "主诉";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.comboBox11);
            this.groupBox1.Controls.Add(this.comboBox9);
            this.groupBox1.Controls.Add(this.textBox10);
            this.groupBox1.Controls.Add(this.comboBox8);
            this.groupBox1.Controls.Add(this.comboBox3);
            this.groupBox1.Controls.Add(this.comboBox5);
            this.groupBox1.Controls.Add(this.textBox9);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.textBox6);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Location = new System.Drawing.Point(113, 243);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(678, 87);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "既往史";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(66, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 2;
            this.label13.Text = "其它";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(223, 43);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 12);
            this.label11.TabIndex = 2;
            this.label11.Text = "泌尿生殖病史";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(456, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 2;
            this.label7.Text = "心血管疾病";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(18, 43);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 12);
            this.label10.TabIndex = 2;
            this.label10.Text = "性传播疾病史";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(271, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 2;
            this.label5.Text = "结核";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(66, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 2;
            this.label4.Text = "肝炎";
            // 
            // comboBox11
            // 
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Items.AddRange(new object[] {
            "无"});
            this.comboBox11.Location = new System.Drawing.Point(101, 60);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(532, 20);
            this.comboBox11.TabIndex = 1;
            this.comboBox11.Text = "无特殊";
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Location = new System.Drawing.Point(121, 40);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(86, 20);
            this.comboBox9.TabIndex = 1;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(101, 39);
            this.textBox10.MaxLength = 1;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(20, 21);
            this.textBox10.TabIndex = 0;
            this.textBox10.Text = "无";
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Location = new System.Drawing.Point(326, 40);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(86, 20);
            this.comboBox8.TabIndex = 1;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(326, 20);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(86, 20);
            this.comboBox3.TabIndex = 1;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(547, 19);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(86, 20);
            this.comboBox5.TabIndex = 1;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(306, 39);
            this.textBox9.MaxLength = 1;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(20, 21);
            this.textBox9.TabIndex = 0;
            this.textBox9.Text = "无";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(306, 19);
            this.textBox4.MaxLength = 1;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(20, 21);
            this.textBox4.TabIndex = 0;
            this.textBox4.Text = "无";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(527, 18);
            this.textBox6.MaxLength = 1;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(20, 21);
            this.textBox6.TabIndex = 0;
            this.textBox6.Text = "无";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(121, 20);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(86, 20);
            this.comboBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(101, 19);
            this.textBox3.MaxLength = 1;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(20, 21);
            this.textBox3.TabIndex = 0;
            this.textBox3.Text = "无";
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.AutoScrollMargin = new System.Drawing.Size(33, 33);
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(231)))), ((int)(((byte)(239)))));
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(858, 390);
            this.tabPage2.TabIndex = 0;
            this.tabPage2.Text = "     检查与检验     ";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.comboBox63);
            this.groupBox8.Controls.Add(this.label67);
            this.groupBox8.Controls.Add(this.comboBox62);
            this.groupBox8.Controls.Add(this.label66);
            this.groupBox8.Controls.Add(this.comboBox68);
            this.groupBox8.Controls.Add(this.label72);
            this.groupBox8.Controls.Add(this.comboBox67);
            this.groupBox8.Controls.Add(this.label71);
            this.groupBox8.Controls.Add(this.comboBox66);
            this.groupBox8.Controls.Add(this.label70);
            this.groupBox8.Controls.Add(this.comboBox65);
            this.groupBox8.Controls.Add(this.label69);
            this.groupBox8.Controls.Add(this.comboBox61);
            this.groupBox8.Controls.Add(this.label65);
            this.groupBox8.Controls.Add(this.comboBox64);
            this.groupBox8.Controls.Add(this.label68);
            this.groupBox8.Controls.Add(this.comboBox60);
            this.groupBox8.Controls.Add(this.label64);
            this.groupBox8.Controls.Add(this.comboBox59);
            this.groupBox8.Controls.Add(this.label63);
            this.groupBox8.Controls.Add(this.comboBox58);
            this.groupBox8.Controls.Add(this.label62);
            this.groupBox8.Controls.Add(this.comboBox57);
            this.groupBox8.Controls.Add(this.label61);
            this.groupBox8.Controls.Add(this.comboBox56);
            this.groupBox8.Controls.Add(this.label60);
            this.groupBox8.Location = new System.Drawing.Point(64, 348);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(749, 127);
            this.groupBox8.TabIndex = 3;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "其他";
            // 
            // comboBox63
            // 
            this.comboBox63.FormattingEnabled = true;
            this.comboBox63.Location = new System.Drawing.Point(642, 46);
            this.comboBox63.Name = "comboBox63";
            this.comboBox63.Size = new System.Drawing.Size(83, 20);
            this.comboBox63.TabIndex = 6;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(595, 49);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(41, 12);
            this.label67.TabIndex = 7;
            this.label67.Text = "RH因子";
            // 
            // comboBox62
            // 
            this.comboBox62.FormattingEnabled = true;
            this.comboBox62.Location = new System.Drawing.Point(482, 46);
            this.comboBox62.Name = "comboBox62";
            this.comboBox62.Size = new System.Drawing.Size(83, 20);
            this.comboBox62.TabIndex = 6;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(435, 49);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(47, 12);
            this.label66.TabIndex = 7;
            this.label66.Text = "血型ABO";
            // 
            // comboBox68
            // 
            this.comboBox68.FormattingEnabled = true;
            this.comboBox68.Location = new System.Drawing.Point(118, 98);
            this.comboBox68.Name = "comboBox68";
            this.comboBox68.Size = new System.Drawing.Size(83, 20);
            this.comboBox68.TabIndex = 6;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(89, 101);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(17, 12);
            this.label72.TabIndex = 7;
            this.label72.Text = "E2";
            // 
            // comboBox67
            // 
            this.comboBox67.FormattingEnabled = true;
            this.comboBox67.Location = new System.Drawing.Point(642, 72);
            this.comboBox67.Name = "comboBox67";
            this.comboBox67.Size = new System.Drawing.Size(83, 20);
            this.comboBox67.TabIndex = 6;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(613, 75);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(23, 12);
            this.label71.TabIndex = 7;
            this.label71.Text = "PRL";
            // 
            // comboBox66
            // 
            this.comboBox66.FormattingEnabled = true;
            this.comboBox66.Location = new System.Drawing.Point(482, 72);
            this.comboBox66.Name = "comboBox66";
            this.comboBox66.Size = new System.Drawing.Size(83, 20);
            this.comboBox66.TabIndex = 6;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(464, 75);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(11, 12);
            this.label70.TabIndex = 7;
            this.label70.Text = "T";
            // 
            // comboBox65
            // 
            this.comboBox65.FormattingEnabled = true;
            this.comboBox65.Location = new System.Drawing.Point(295, 72);
            this.comboBox65.Name = "comboBox65";
            this.comboBox65.Size = new System.Drawing.Size(83, 20);
            this.comboBox65.TabIndex = 6;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(277, 75);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(17, 12);
            this.label69.TabIndex = 7;
            this.label69.Text = "LH";
            // 
            // comboBox61
            // 
            this.comboBox61.FormattingEnabled = true;
            this.comboBox61.Location = new System.Drawing.Point(295, 46);
            this.comboBox61.Name = "comboBox61";
            this.comboBox61.Size = new System.Drawing.Size(83, 20);
            this.comboBox61.TabIndex = 6;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(255, 49);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(41, 12);
            this.label65.TabIndex = 7;
            this.label65.Text = "染色体";
            // 
            // comboBox64
            // 
            this.comboBox64.FormattingEnabled = true;
            this.comboBox64.Location = new System.Drawing.Point(118, 72);
            this.comboBox64.Name = "comboBox64";
            this.comboBox64.Size = new System.Drawing.Size(83, 20);
            this.comboBox64.TabIndex = 6;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(6, 75);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(107, 12);
            this.label68.TabIndex = 7;
            this.label68.Text = "生殖激素测定：FSH";
            // 
            // comboBox60
            // 
            this.comboBox60.FormattingEnabled = true;
            this.comboBox60.Location = new System.Drawing.Point(89, 46);
            this.comboBox60.Name = "comboBox60";
            this.comboBox60.Size = new System.Drawing.Size(83, 20);
            this.comboBox60.TabIndex = 6;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(42, 49);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(41, 12);
            this.label64.TabIndex = 7;
            this.label64.Text = "衣原体";
            // 
            // comboBox59
            // 
            this.comboBox59.FormattingEnabled = true;
            this.comboBox59.Location = new System.Drawing.Point(642, 20);
            this.comboBox59.Name = "comboBox59";
            this.comboBox59.Size = new System.Drawing.Size(83, 20);
            this.comboBox59.TabIndex = 6;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(595, 23);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(41, 12);
            this.label63.TabIndex = 7;
            this.label63.Text = "支原体";
            // 
            // comboBox58
            // 
            this.comboBox58.FormattingEnabled = true;
            this.comboBox58.Location = new System.Drawing.Point(482, 20);
            this.comboBox58.Name = "comboBox58";
            this.comboBox58.Size = new System.Drawing.Size(83, 20);
            this.comboBox58.TabIndex = 6;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(435, 23);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(41, 12);
            this.label62.TabIndex = 7;
            this.label62.Text = "淋球菌";
            // 
            // comboBox57
            // 
            this.comboBox57.FormattingEnabled = true;
            this.comboBox57.Location = new System.Drawing.Point(295, 20);
            this.comboBox57.Name = "comboBox57";
            this.comboBox57.Size = new System.Drawing.Size(83, 20);
            this.comboBox57.TabIndex = 6;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(193, 23);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(101, 12);
            this.label61.TabIndex = 7;
            this.label61.Text = "人类免疫缺陷病毒";
            // 
            // comboBox56
            // 
            this.comboBox56.FormattingEnabled = true;
            this.comboBox56.Location = new System.Drawing.Point(88, 20);
            this.comboBox56.Name = "comboBox56";
            this.comboBox56.Size = new System.Drawing.Size(83, 20);
            this.comboBox56.TabIndex = 6;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(18, 23);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(65, 12);
            this.label60.TabIndex = 7;
            this.label60.Text = "梅毒螺旋体";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label40);
            this.groupBox7.Controls.Add(this.label56);
            this.groupBox7.Controls.Add(this.label48);
            this.groupBox7.Controls.Add(this.label55);
            this.groupBox7.Controls.Add(this.label47);
            this.groupBox7.Controls.Add(this.label54);
            this.groupBox7.Controls.Add(this.label46);
            this.groupBox7.Controls.Add(this.label53);
            this.groupBox7.Controls.Add(this.label45);
            this.groupBox7.Controls.Add(this.label59);
            this.groupBox7.Controls.Add(this.label58);
            this.groupBox7.Controls.Add(this.label57);
            this.groupBox7.Controls.Add(this.label49);
            this.groupBox7.Controls.Add(this.label44);
            this.groupBox7.Controls.Add(this.label43);
            this.groupBox7.Controls.Add(this.label42);
            this.groupBox7.Controls.Add(this.label41);
            this.groupBox7.Controls.Add(this.label39);
            this.groupBox7.Controls.Add(this.comboBox39);
            this.groupBox7.Controls.Add(this.comboBox52);
            this.groupBox7.Controls.Add(this.comboBox51);
            this.groupBox7.Controls.Add(this.comboBox47);
            this.groupBox7.Controls.Add(this.comboBox50);
            this.groupBox7.Controls.Add(this.comboBox46);
            this.groupBox7.Controls.Add(this.comboBox49);
            this.groupBox7.Controls.Add(this.comboBox45);
            this.groupBox7.Controls.Add(this.comboBox55);
            this.groupBox7.Controls.Add(this.comboBox54);
            this.groupBox7.Controls.Add(this.comboBox53);
            this.groupBox7.Controls.Add(this.comboBox48);
            this.groupBox7.Controls.Add(this.comboBox44);
            this.groupBox7.Controls.Add(this.comboBox43);
            this.groupBox7.Controls.Add(this.comboBox42);
            this.groupBox7.Controls.Add(this.comboBox41);
            this.groupBox7.Controls.Add(this.comboBox40);
            this.groupBox7.Controls.Add(this.comboBox38);
            this.groupBox7.Location = new System.Drawing.Point(64, 226);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(749, 116);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "精液常规分析";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(187, 23);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(53, 12);
            this.label40.TabIndex = 7;
            this.label40.Text = "禁欲天数";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(586, 63);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(95, 12);
            this.label56.TabIndex = 7;
            this.label56.Text = "白细胞(百万/ml)";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(616, 43);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(65, 12);
            this.label48.TabIndex = 7;
            this.label48.Text = "正常形态率";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(518, 63);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(29, 12);
            this.label55.TabIndex = 7;
            this.label55.Text = "凝集";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(500, 43);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(47, 12);
            this.label47.TabIndex = 7;
            this.label47.Text = "存活率%";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(386, 63);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(35, 12);
            this.label54.TabIndex = 7;
            this.label54.Text = "IM(%)";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(338, 43);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(83, 12);
            this.label46.TabIndex = 7;
            this.label46.Text = "密度(百万/ml)";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(205, 63);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(35, 12);
            this.label53.TabIndex = 7;
            this.label53.Text = "NP(%)";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(223, 43);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(17, 12);
            this.label45.TabIndex = 7;
            this.label45.Text = "PH";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(391, 89);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(29, 12);
            this.label59.TabIndex = 7;
            this.label59.Text = "血清";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(211, 89);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(29, 12);
            this.label58.TabIndex = 7;
            this.label58.Text = "精浆";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(18, 89);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(65, 12);
            this.label57.TabIndex = 7;
            this.label57.Text = "抗精子抗体";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(48, 63);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(35, 12);
            this.label49.TabIndex = 7;
            this.label49.Text = "PR(%)";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(42, 43);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(41, 12);
            this.label44.TabIndex = 7;
            this.label44.Text = "粘稠度";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(640, 23);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(41, 12);
            this.label43.TabIndex = 7;
            this.label43.Text = "量(ml)";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(518, 23);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(29, 12);
            this.label42.TabIndex = 7;
            this.label42.Text = "颜色";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(338, 23);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(83, 12);
            this.label41.TabIndex = 7;
            this.label41.Text = "液化时间(min)";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(54, 23);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(29, 12);
            this.label39.TabIndex = 7;
            this.label39.Text = "日期";
            // 
            // comboBox39
            // 
            this.comboBox39.FormattingEnabled = true;
            this.comboBox39.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.comboBox39.Location = new System.Drawing.Point(241, 20);
            this.comboBox39.Name = "comboBox39";
            this.comboBox39.Size = new System.Drawing.Size(55, 20);
            this.comboBox39.TabIndex = 6;
            this.comboBox39.Text = "1";
            // 
            // comboBox52
            // 
            this.comboBox52.FormattingEnabled = true;
            this.comboBox52.Location = new System.Drawing.Point(681, 60);
            this.comboBox52.Name = "comboBox52";
            this.comboBox52.Size = new System.Drawing.Size(55, 20);
            this.comboBox52.TabIndex = 6;
            // 
            // comboBox51
            // 
            this.comboBox51.FormattingEnabled = true;
            this.comboBox51.Location = new System.Drawing.Point(547, 60);
            this.comboBox51.Name = "comboBox51";
            this.comboBox51.Size = new System.Drawing.Size(38, 20);
            this.comboBox51.TabIndex = 6;
            this.comboBox51.Text = "无";
            // 
            // comboBox47
            // 
            this.comboBox47.FormattingEnabled = true;
            this.comboBox47.Location = new System.Drawing.Point(681, 40);
            this.comboBox47.Name = "comboBox47";
            this.comboBox47.Size = new System.Drawing.Size(55, 20);
            this.comboBox47.TabIndex = 6;
            // 
            // comboBox50
            // 
            this.comboBox50.FormattingEnabled = true;
            this.comboBox50.Location = new System.Drawing.Point(421, 60);
            this.comboBox50.Name = "comboBox50";
            this.comboBox50.Size = new System.Drawing.Size(55, 20);
            this.comboBox50.TabIndex = 6;
            // 
            // comboBox46
            // 
            this.comboBox46.FormattingEnabled = true;
            this.comboBox46.Location = new System.Drawing.Point(547, 40);
            this.comboBox46.Name = "comboBox46";
            this.comboBox46.Size = new System.Drawing.Size(55, 20);
            this.comboBox46.TabIndex = 6;
            // 
            // comboBox49
            // 
            this.comboBox49.FormattingEnabled = true;
            this.comboBox49.Location = new System.Drawing.Point(241, 60);
            this.comboBox49.Name = "comboBox49";
            this.comboBox49.Size = new System.Drawing.Size(55, 20);
            this.comboBox49.TabIndex = 6;
            this.comboBox49.Text = "7.5";
            // 
            // comboBox45
            // 
            this.comboBox45.FormattingEnabled = true;
            this.comboBox45.Location = new System.Drawing.Point(421, 40);
            this.comboBox45.Name = "comboBox45";
            this.comboBox45.Size = new System.Drawing.Size(55, 20);
            this.comboBox45.TabIndex = 6;
            // 
            // comboBox55
            // 
            this.comboBox55.FormattingEnabled = true;
            this.comboBox55.Location = new System.Drawing.Point(421, 86);
            this.comboBox55.Name = "comboBox55";
            this.comboBox55.Size = new System.Drawing.Size(55, 20);
            this.comboBox55.TabIndex = 6;
            // 
            // comboBox54
            // 
            this.comboBox54.FormattingEnabled = true;
            this.comboBox54.Location = new System.Drawing.Point(241, 86);
            this.comboBox54.Name = "comboBox54";
            this.comboBox54.Size = new System.Drawing.Size(55, 20);
            this.comboBox54.TabIndex = 6;
            // 
            // comboBox53
            // 
            this.comboBox53.FormattingEnabled = true;
            this.comboBox53.Location = new System.Drawing.Point(89, 86);
            this.comboBox53.Name = "comboBox53";
            this.comboBox53.Size = new System.Drawing.Size(55, 20);
            this.comboBox53.TabIndex = 6;
            // 
            // comboBox48
            // 
            this.comboBox48.FormattingEnabled = true;
            this.comboBox48.Location = new System.Drawing.Point(88, 60);
            this.comboBox48.Name = "comboBox48";
            this.comboBox48.Size = new System.Drawing.Size(55, 20);
            this.comboBox48.TabIndex = 6;
            // 
            // comboBox44
            // 
            this.comboBox44.FormattingEnabled = true;
            this.comboBox44.Location = new System.Drawing.Point(241, 40);
            this.comboBox44.Name = "comboBox44";
            this.comboBox44.Size = new System.Drawing.Size(55, 20);
            this.comboBox44.TabIndex = 6;
            this.comboBox44.Text = "7.5";
            // 
            // comboBox43
            // 
            this.comboBox43.FormattingEnabled = true;
            this.comboBox43.Location = new System.Drawing.Point(88, 40);
            this.comboBox43.Name = "comboBox43";
            this.comboBox43.Size = new System.Drawing.Size(55, 20);
            this.comboBox43.TabIndex = 6;
            // 
            // comboBox42
            // 
            this.comboBox42.FormattingEnabled = true;
            this.comboBox42.Location = new System.Drawing.Point(681, 20);
            this.comboBox42.Name = "comboBox42";
            this.comboBox42.Size = new System.Drawing.Size(55, 20);
            this.comboBox42.TabIndex = 6;
            // 
            // comboBox41
            // 
            this.comboBox41.FormattingEnabled = true;
            this.comboBox41.Location = new System.Drawing.Point(547, 20);
            this.comboBox41.Name = "comboBox41";
            this.comboBox41.Size = new System.Drawing.Size(55, 20);
            this.comboBox41.TabIndex = 6;
            this.comboBox41.Text = "灰白";
            // 
            // comboBox40
            // 
            this.comboBox40.FormattingEnabled = true;
            this.comboBox40.Location = new System.Drawing.Point(421, 20);
            this.comboBox40.Name = "comboBox40";
            this.comboBox40.Size = new System.Drawing.Size(55, 20);
            this.comboBox40.TabIndex = 6;
            this.comboBox40.Text = "30";
            // 
            // comboBox38
            // 
            this.comboBox38.FormattingEnabled = true;
            this.comboBox38.Location = new System.Drawing.Point(88, 20);
            this.comboBox38.Name = "comboBox38";
            this.comboBox38.Size = new System.Drawing.Size(83, 20);
            this.comboBox38.TabIndex = 6;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label28);
            this.groupBox6.Controls.Add(this.label38);
            this.groupBox6.Controls.Add(this.label36);
            this.groupBox6.Controls.Add(this.label33);
            this.groupBox6.Controls.Add(this.label31);
            this.groupBox6.Controls.Add(this.label37);
            this.groupBox6.Controls.Add(this.label35);
            this.groupBox6.Controls.Add(this.label32);
            this.groupBox6.Controls.Add(this.label30);
            this.groupBox6.Controls.Add(this.label26);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Controls.Add(this.label27);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.comboBox28);
            this.groupBox6.Controls.Add(this.comboBox37);
            this.groupBox6.Controls.Add(this.comboBox35);
            this.groupBox6.Controls.Add(this.comboBox33);
            this.groupBox6.Controls.Add(this.comboBox31);
            this.groupBox6.Controls.Add(this.comboBox36);
            this.groupBox6.Controls.Add(this.comboBox34);
            this.groupBox6.Controls.Add(this.textBox28);
            this.groupBox6.Controls.Add(this.comboBox32);
            this.groupBox6.Controls.Add(this.textBox26);
            this.groupBox6.Controls.Add(this.textBox29);
            this.groupBox6.Controls.Add(this.comboBox29);
            this.groupBox6.Controls.Add(this.textBox27);
            this.groupBox6.Controls.Add(this.textBox21);
            this.groupBox6.Controls.Add(this.textBox25);
            this.groupBox6.Controls.Add(this.comboBox25);
            this.groupBox6.Controls.Add(this.textBox14);
            this.groupBox6.Controls.Add(this.textBox12);
            this.groupBox6.Controls.Add(this.textBox11);
            this.groupBox6.Controls.Add(this.comboBox23);
            this.groupBox6.Controls.Add(this.comboBox22);
            this.groupBox6.Controls.Add(this.comboBox14);
            this.groupBox6.Controls.Add(this.comboBox26);
            this.groupBox6.Controls.Add(this.comboBox10);
            this.groupBox6.Controls.Add(this.comboBox24);
            this.groupBox6.Controls.Add(this.comboBox7);
            this.groupBox6.Controls.Add(this.textBox22);
            this.groupBox6.Controls.Add(this.textBox24);
            this.groupBox6.Controls.Add(this.textBox23);
            this.groupBox6.Controls.Add(this.label50);
            this.groupBox6.Controls.Add(this.label52);
            this.groupBox6.Controls.Add(this.label51);
            this.groupBox6.Location = new System.Drawing.Point(64, 29);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(749, 191);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "体格检查";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(463, 82);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(29, 12);
            this.label28.TabIndex = 5;
            this.label28.Text = "质地";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(356, 163);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(29, 12);
            this.label38.TabIndex = 5;
            this.label38.Text = "备注";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(321, 143);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(65, 12);
            this.label36.TabIndex = 5;
            this.label36.Text = "右精索静脉";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(333, 123);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(53, 12);
            this.label33.TabIndex = 5;
            this.label33.Text = "右输精管";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(344, 103);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(41, 12);
            this.label31.TabIndex = 5;
            this.label31.Text = "左附睾";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(41, 164);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(41, 12);
            this.label37.TabIndex = 5;
            this.label37.Text = "前列腺";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(18, 144);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(65, 12);
            this.label35.TabIndex = 5;
            this.label35.Text = "左精索静脉";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(29, 124);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(53, 12);
            this.label32.TabIndex = 5;
            this.label32.Text = "左输精管";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(41, 104);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(41, 12);
            this.label30.TabIndex = 5;
            this.label30.Text = "左附睾";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(160, 83);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(29, 12);
            this.label26.TabIndex = 5;
            this.label26.Text = "质地";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(357, 44);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(29, 12);
            this.label24.TabIndex = 5;
            this.label24.Text = "阴毛";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(526, 44);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 5;
            this.label17.Text = "乳房";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(54, 44);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 5;
            this.label12.Text = "胡须";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(223, 44);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 5;
            this.label9.Text = "喉结";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(321, 83);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(65, 12);
            this.label27.TabIndex = 5;
            this.label27.Text = "右睾丸体积";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(18, 84);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(65, 12);
            this.label25.TabIndex = 5;
            this.label25.Text = "左睾丸体积";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(30, 64);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 5;
            this.label8.Text = "阴茎长度";
            // 
            // comboBox28
            // 
            this.comboBox28.FormattingEnabled = true;
            this.comboBox28.Location = new System.Drawing.Point(528, 80);
            this.comboBox28.Name = "comboBox28";
            this.comboBox28.Size = new System.Drawing.Size(92, 20);
            this.comboBox28.TabIndex = 4;
            // 
            // comboBox37
            // 
            this.comboBox37.FormattingEnabled = true;
            this.comboBox37.Location = new System.Drawing.Point(391, 160);
            this.comboBox37.Name = "comboBox37";
            this.comboBox37.Size = new System.Drawing.Size(229, 20);
            this.comboBox37.TabIndex = 4;
            this.comboBox37.Text = "无";
            // 
            // comboBox35
            // 
            this.comboBox35.FormattingEnabled = true;
            this.comboBox35.Location = new System.Drawing.Point(421, 140);
            this.comboBox35.Name = "comboBox35";
            this.comboBox35.Size = new System.Drawing.Size(199, 20);
            this.comboBox35.TabIndex = 4;
            // 
            // comboBox33
            // 
            this.comboBox33.FormattingEnabled = true;
            this.comboBox33.Location = new System.Drawing.Point(421, 120);
            this.comboBox33.Name = "comboBox33";
            this.comboBox33.Size = new System.Drawing.Size(199, 20);
            this.comboBox33.TabIndex = 4;
            // 
            // comboBox31
            // 
            this.comboBox31.FormattingEnabled = true;
            this.comboBox31.Location = new System.Drawing.Point(421, 100);
            this.comboBox31.Name = "comboBox31";
            this.comboBox31.Size = new System.Drawing.Size(199, 20);
            this.comboBox31.TabIndex = 4;
            // 
            // comboBox36
            // 
            this.comboBox36.FormattingEnabled = true;
            this.comboBox36.Location = new System.Drawing.Point(118, 161);
            this.comboBox36.Name = "comboBox36";
            this.comboBox36.Size = new System.Drawing.Size(199, 20);
            this.comboBox36.TabIndex = 4;
            // 
            // comboBox34
            // 
            this.comboBox34.FormattingEnabled = true;
            this.comboBox34.Location = new System.Drawing.Point(118, 141);
            this.comboBox34.Name = "comboBox34";
            this.comboBox34.Size = new System.Drawing.Size(199, 20);
            this.comboBox34.TabIndex = 4;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(391, 139);
            this.textBox28.MaxLength = 1;
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(30, 21);
            this.textBox28.TabIndex = 3;
            this.textBox28.Text = "正常";
            // 
            // comboBox32
            // 
            this.comboBox32.FormattingEnabled = true;
            this.comboBox32.Location = new System.Drawing.Point(118, 121);
            this.comboBox32.Name = "comboBox32";
            this.comboBox32.Size = new System.Drawing.Size(199, 20);
            this.comboBox32.TabIndex = 4;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(391, 119);
            this.textBox26.MaxLength = 1;
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(30, 21);
            this.textBox26.TabIndex = 3;
            this.textBox26.Text = "正常";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(88, 160);
            this.textBox29.MaxLength = 1;
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(30, 21);
            this.textBox29.TabIndex = 3;
            this.textBox29.Text = "正常";
            // 
            // comboBox29
            // 
            this.comboBox29.FormattingEnabled = true;
            this.comboBox29.Location = new System.Drawing.Point(118, 101);
            this.comboBox29.Name = "comboBox29";
            this.comboBox29.Size = new System.Drawing.Size(199, 20);
            this.comboBox29.TabIndex = 4;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(88, 140);
            this.textBox27.MaxLength = 1;
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(30, 21);
            this.textBox27.TabIndex = 3;
            this.textBox27.Text = "正常";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(391, 99);
            this.textBox21.MaxLength = 1;
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(30, 21);
            this.textBox21.TabIndex = 3;
            this.textBox21.Text = "正常";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(88, 120);
            this.textBox25.MaxLength = 1;
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(30, 21);
            this.textBox25.TabIndex = 3;
            this.textBox25.Text = "正常";
            // 
            // comboBox25
            // 
            this.comboBox25.FormattingEnabled = true;
            this.comboBox25.Location = new System.Drawing.Point(225, 81);
            this.comboBox25.Name = "comboBox25";
            this.comboBox25.Size = new System.Drawing.Size(92, 20);
            this.comboBox25.TabIndex = 4;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(88, 100);
            this.textBox14.MaxLength = 1;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(30, 21);
            this.textBox14.TabIndex = 3;
            this.textBox14.Text = "正常";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(498, 79);
            this.textBox12.MaxLength = 1;
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(30, 21);
            this.textBox12.TabIndex = 3;
            this.textBox12.Text = "正常";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(195, 80);
            this.textBox11.MaxLength = 1;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(30, 21);
            this.textBox11.TabIndex = 3;
            this.textBox11.Text = "正常";
            // 
            // comboBox23
            // 
            this.comboBox23.FormattingEnabled = true;
            this.comboBox23.Location = new System.Drawing.Point(392, 41);
            this.comboBox23.Name = "comboBox23";
            this.comboBox23.Size = new System.Drawing.Size(59, 20);
            this.comboBox23.TabIndex = 4;
            this.comboBox23.Text = "正常";
            // 
            // comboBox22
            // 
            this.comboBox22.FormattingEnabled = true;
            this.comboBox22.Location = new System.Drawing.Point(561, 41);
            this.comboBox22.Name = "comboBox22";
            this.comboBox22.Size = new System.Drawing.Size(59, 20);
            this.comboBox22.TabIndex = 4;
            this.comboBox22.Text = "正常";
            // 
            // comboBox14
            // 
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.Location = new System.Drawing.Point(89, 41);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(59, 20);
            this.comboBox14.TabIndex = 4;
            this.comboBox14.Text = "正常";
            // 
            // comboBox26
            // 
            this.comboBox26.FormattingEnabled = true;
            this.comboBox26.Items.AddRange(new object[] {
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.comboBox26.Location = new System.Drawing.Point(392, 80);
            this.comboBox26.Name = "comboBox26";
            this.comboBox26.Size = new System.Drawing.Size(59, 20);
            this.comboBox26.TabIndex = 4;
            this.comboBox26.Text = "15";
            // 
            // comboBox10
            // 
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Location = new System.Drawing.Point(258, 41);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(59, 20);
            this.comboBox10.TabIndex = 4;
            this.comboBox10.Text = "正常";
            // 
            // comboBox24
            // 
            this.comboBox24.FormattingEnabled = true;
            this.comboBox24.Items.AddRange(new object[] {
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.comboBox24.Location = new System.Drawing.Point(89, 81);
            this.comboBox24.Name = "comboBox24";
            this.comboBox24.Size = new System.Drawing.Size(59, 20);
            this.comboBox24.TabIndex = 4;
            this.comboBox24.Text = "15";
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.comboBox7.Location = new System.Drawing.Point(89, 61);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(59, 20);
            this.comboBox7.TabIndex = 4;
            this.comboBox7.Text = "6";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(392, 20);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(59, 21);
            this.textBox22.TabIndex = 1;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(258, 20);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(59, 21);
            this.textBox24.TabIndex = 1;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(89, 20);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(59, 21);
            this.textBox23.TabIndex = 1;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(369, 23);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(17, 12);
            this.label50.TabIndex = 0;
            this.label50.Text = "BP";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(199, 23);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(53, 12);
            this.label52.TabIndex = 0;
            this.label52.Text = "体重(kg)";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(30, 23);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(53, 12);
            this.label51.TabIndex = 0;
            this.label51.Text = "身高(cm)";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(231)))), ((int)(((byte)(239)))));
            this.tabPage3.Controls.Add(this.textBox8);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.comboBox141);
            this.tabPage3.Controls.Add(this.label153);
            this.tabPage3.Controls.Add(this.textBox41);
            this.tabPage3.Controls.Add(this.label151);
            this.tabPage3.Controls.Add(this.textBox40);
            this.tabPage3.Controls.Add(this.label149);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(858, 390);
            this.tabPage3.TabIndex = 1;
            this.tabPage3.Text = "     诊断与方案     ";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(617, 300);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(117, 21);
            this.textBox8.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(572, 303);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 20;
            this.label6.Text = "日期";
            // 
            // comboBox141
            // 
            this.comboBox141.FormattingEnabled = true;
            this.comboBox141.Location = new System.Drawing.Point(617, 260);
            this.comboBox141.Name = "comboBox141";
            this.comboBox141.Size = new System.Drawing.Size(117, 20);
            this.comboBox141.TabIndex = 19;
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.Location = new System.Drawing.Point(560, 263);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(41, 12);
            this.label153.TabIndex = 18;
            this.label153.Text = "录入者";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(105, 107);
            this.textBox41.Multiline = true;
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(629, 129);
            this.textBox41.TabIndex = 16;
            // 
            // label151
            // 
            this.label151.AutoSize = true;
            this.label151.Location = new System.Drawing.Point(70, 110);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(29, 12);
            this.label151.TabIndex = 14;
            this.label151.Text = "诊断";
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(105, 42);
            this.textBox40.Multiline = true;
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(629, 59);
            this.textBox40.TabIndex = 17;
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.Location = new System.Drawing.Point(46, 45);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(53, 12);
            this.label149.TabIndex = 15;
            this.label149.Text = "诊断依据";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 391);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(866, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // 男方病例form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(866, 416);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.tabControl1);
            this.Name = "男方病例form";
            this.Text = "男方病例";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.男方病例_FormClosed);
            this.Load += new System.EventHandler(this.男方病例form_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.ComboBox comboBox16;
        private System.Windows.Forms.ComboBox comboBox17;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.ComboBox comboBox18;
        private System.Windows.Forms.ComboBox comboBox19;
        private System.Windows.Forms.ComboBox comboBox20;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.ComboBox comboBox21;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox comboBox30;
        private System.Windows.Forms.ComboBox comboBox27;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox141;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox28;
        private System.Windows.Forms.ComboBox comboBox37;
        private System.Windows.Forms.ComboBox comboBox35;
        private System.Windows.Forms.ComboBox comboBox33;
        private System.Windows.Forms.ComboBox comboBox31;
        private System.Windows.Forms.ComboBox comboBox36;
        private System.Windows.Forms.ComboBox comboBox34;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.ComboBox comboBox32;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.ComboBox comboBox29;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.ComboBox comboBox25;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.ComboBox comboBox23;
        private System.Windows.Forms.ComboBox comboBox22;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.ComboBox comboBox26;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.ComboBox comboBox24;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox comboBox39;
        private System.Windows.Forms.ComboBox comboBox52;
        private System.Windows.Forms.ComboBox comboBox51;
        private System.Windows.Forms.ComboBox comboBox47;
        private System.Windows.Forms.ComboBox comboBox50;
        private System.Windows.Forms.ComboBox comboBox46;
        private System.Windows.Forms.ComboBox comboBox49;
        private System.Windows.Forms.ComboBox comboBox45;
        private System.Windows.Forms.ComboBox comboBox48;
        private System.Windows.Forms.ComboBox comboBox44;
        private System.Windows.Forms.ComboBox comboBox43;
        private System.Windows.Forms.ComboBox comboBox42;
        private System.Windows.Forms.ComboBox comboBox41;
        private System.Windows.Forms.ComboBox comboBox40;
        private System.Windows.Forms.ComboBox comboBox38;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox comboBox63;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.ComboBox comboBox62;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.ComboBox comboBox68;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.ComboBox comboBox67;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.ComboBox comboBox66;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.ComboBox comboBox65;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.ComboBox comboBox61;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.ComboBox comboBox64;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.ComboBox comboBox60;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.ComboBox comboBox59;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.ComboBox comboBox58;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.ComboBox comboBox57;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.ComboBox comboBox56;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.ComboBox comboBox55;
        private System.Windows.Forms.ComboBox comboBox54;
        private System.Windows.Forms.ComboBox comboBox53;
        private System.Windows.Forms.ToolStrip toolStrip1;
        internal System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;

    }
}