﻿namespace 生殖中心病例管理系统
{
    partial class 女方病例
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.初诊日期_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.现病史_textBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.主诉_TextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboBox39 = new System.Windows.Forms.ComboBox();
            this.comboBox35 = new System.Windows.Forms.ComboBox();
            this.comboBox44 = new System.Windows.Forms.ComboBox();
            this.comboBox43 = new System.Windows.Forms.ComboBox();
            this.comboBox38 = new System.Windows.Forms.ComboBox();
            this.comboBox34 = new System.Windows.Forms.ComboBox();
            this.comboBox29 = new System.Windows.Forms.ComboBox();
            this.comboBox42 = new System.Windows.Forms.ComboBox();
            this.comboBox28 = new System.Windows.Forms.ComboBox();
            this.comboBox37 = new System.Windows.Forms.ComboBox();
            this.comboBox33 = new System.Windows.Forms.ComboBox();
            this.comboBox40 = new System.Windows.Forms.ComboBox();
            this.comboBox41 = new System.Windows.Forms.ComboBox();
            this.comboBox31 = new System.Windows.Forms.ComboBox();
            this.comboBox36 = new System.Windows.Forms.ComboBox();
            this.comboBox32 = new System.Windows.Forms.ComboBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.comboBox30 = new System.Windows.Forms.ComboBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.comboBox27 = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBox26 = new System.Windows.Forms.ComboBox();
            this.comboBox25 = new System.Windows.Forms.ComboBox();
            this.comboBox23 = new System.Windows.Forms.ComboBox();
            this.comboBox24 = new System.Windows.Forms.ComboBox();
            this.comboBox22 = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.comboBox16 = new System.Windows.Forms.ComboBox();
            this.comboBox17 = new System.Windows.Forms.ComboBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.comboBox18 = new System.Windows.Forms.ComboBox();
            this.comboBox19 = new System.Windows.Forms.ComboBox();
            this.comboBox20 = new System.Windows.Forms.ComboBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.comboBox21 = new System.Windows.Forms.ComboBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.Appendicitis = new System.Windows.Forms.Label();
            this.diseasesOfUrinarySystem = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.CardiovascularDiseases = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.kidneyDisease = new System.Windows.Forms.Label();
            this.tubercular = new System.Windows.Forms.Label();
            this.hepatitis = new System.Windows.Forms.Label();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.Appendicitis_comboBox = new System.Windows.Forms.ComboBox();
            this.Appendicitis_textBox = new System.Windows.Forms.TextBox();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.性传播疾病史_comboBox = new System.Windows.Forms.ComboBox();
            this.diseasesOfUrinarySystem_comboBox = new System.Windows.Forms.ComboBox();
            this.肾脏疾病_comboBox = new System.Windows.Forms.ComboBox();
            this.性传播疾病史_textBox = new System.Windows.Forms.TextBox();
            this.diseasesOfUrinarySystem_textBox = new System.Windows.Forms.TextBox();
            this.肾脏疾病_textBox = new System.Windows.Forms.TextBox();
            this.盆腔炎_comboBox = new System.Windows.Forms.ComboBox();
            this.结核_comboBox = new System.Windows.Forms.ComboBox();
            this.心血管疾病_comboBox = new System.Windows.Forms.ComboBox();
            this.盆腔炎_textBox = new System.Windows.Forms.TextBox();
            this.结核_textbox = new System.Windows.Forms.TextBox();
            this.心血管疾病_textBox = new System.Windows.Forms.TextBox();
            this.肝炎_comboBox = new System.Windows.Forms.ComboBox();
            this.肝炎_textBox = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label92 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.comboBox83 = new System.Windows.Forms.ComboBox();
            this.comboBox84 = new System.Windows.Forms.ComboBox();
            this.comboBox64 = new System.Windows.Forms.ComboBox();
            this.comboBox71 = new System.Windows.Forms.ComboBox();
            this.comboBox66 = new System.Windows.Forms.ComboBox();
            this.comboBox62 = new System.Windows.Forms.ComboBox();
            this.comboBox60 = new System.Windows.Forms.ComboBox();
            this.comboBox87 = new System.Windows.Forms.ComboBox();
            this.comboBox88 = new System.Windows.Forms.ComboBox();
            this.comboBox86 = new System.Windows.Forms.ComboBox();
            this.comboBox85 = new System.Windows.Forms.ComboBox();
            this.comboBox67 = new System.Windows.Forms.ComboBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label91 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.comboBox82 = new System.Windows.Forms.ComboBox();
            this.comboBox61 = new System.Windows.Forms.ComboBox();
            this.comboBox81 = new System.Windows.Forms.ComboBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.comboBox80 = new System.Windows.Forms.ComboBox();
            this.comboBox63 = new System.Windows.Forms.ComboBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.comboBox65 = new System.Windows.Forms.ComboBox();
            this.comboBox79 = new System.Windows.Forms.ComboBox();
            this.comboBox78 = new System.Windows.Forms.ComboBox();
            this.comboBox68 = new System.Windows.Forms.ComboBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.comboBox77 = new System.Windows.Forms.ComboBox();
            this.comboBox69 = new System.Windows.Forms.ComboBox();
            this.comboBox70 = new System.Windows.Forms.ComboBox();
            this.comboBox76 = new System.Windows.Forms.ComboBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.comboBox72 = new System.Windows.Forms.ComboBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.comboBox73 = new System.Windows.Forms.ComboBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.comboBox75 = new System.Windows.Forms.ComboBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.comboBox74 = new System.Windows.Forms.ComboBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.comboBox52 = new System.Windows.Forms.ComboBox();
            this.comboBox56 = new System.Windows.Forms.ComboBox();
            this.comboBox48 = new System.Windows.Forms.ComboBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.comboBox59 = new System.Windows.Forms.ComboBox();
            this.comboBox51 = new System.Windows.Forms.ComboBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.comboBox55 = new System.Windows.Forms.ComboBox();
            this.comboBox58 = new System.Windows.Forms.ComboBox();
            this.comboBox47 = new System.Windows.Forms.ComboBox();
            this.comboBox50 = new System.Windows.Forms.ComboBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.comboBox54 = new System.Windows.Forms.ComboBox();
            this.comboBox46 = new System.Windows.Forms.ComboBox();
            this.comboBox57 = new System.Windows.Forms.ComboBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.comboBox49 = new System.Windows.Forms.ComboBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.comboBox53 = new System.Windows.Forms.ComboBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.comboBox45 = new System.Windows.Forms.ComboBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label129 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.comboBox130 = new System.Windows.Forms.ComboBox();
            this.comboBox129 = new System.Windows.Forms.ComboBox();
            this.comboBox122 = new System.Windows.Forms.ComboBox();
            this.comboBox107 = new System.Windows.Forms.ComboBox();
            this.comboBox98 = new System.Windows.Forms.ComboBox();
            this.comboBox120 = new System.Windows.Forms.ComboBox();
            this.comboBox119 = new System.Windows.Forms.ComboBox();
            this.comboBox135 = new System.Windows.Forms.ComboBox();
            this.comboBox133 = new System.Windows.Forms.ComboBox();
            this.comboBox131 = new System.Windows.Forms.ComboBox();
            this.comboBox128 = new System.Windows.Forms.ComboBox();
            this.comboBox116 = new System.Windows.Forms.ComboBox();
            this.comboBox121 = new System.Windows.Forms.ComboBox();
            this.comboBox126 = new System.Windows.Forms.ComboBox();
            this.comboBox104 = new System.Windows.Forms.ComboBox();
            this.comboBox115 = new System.Windows.Forms.ComboBox();
            this.comboBox96 = new System.Windows.Forms.ComboBox();
            this.comboBox111 = new System.Windows.Forms.ComboBox();
            this.comboBox118 = new System.Windows.Forms.ComboBox();
            this.comboBox125 = new System.Windows.Forms.ComboBox();
            this.comboBox114 = new System.Windows.Forms.ComboBox();
            this.comboBox136 = new System.Windows.Forms.ComboBox();
            this.comboBox134 = new System.Windows.Forms.ComboBox();
            this.comboBox124 = new System.Windows.Forms.ComboBox();
            this.comboBox132 = new System.Windows.Forms.ComboBox();
            this.comboBox108 = new System.Windows.Forms.ComboBox();
            this.comboBox127 = new System.Windows.Forms.ComboBox();
            this.comboBox103 = new System.Windows.Forms.ComboBox();
            this.comboBox112 = new System.Windows.Forms.ComboBox();
            this.comboBox123 = new System.Windows.Forms.ComboBox();
            this.comboBox110 = new System.Windows.Forms.ComboBox();
            this.comboBox100 = new System.Windows.Forms.ComboBox();
            this.comboBox99 = new System.Windows.Forms.ComboBox();
            this.comboBox95 = new System.Windows.Forms.ComboBox();
            this.comboBox106 = new System.Windows.Forms.ComboBox();
            this.comboBox117 = new System.Windows.Forms.ComboBox();
            this.comboBox102 = new System.Windows.Forms.ComboBox();
            this.comboBox113 = new System.Windows.Forms.ComboBox();
            this.comboBox109 = new System.Windows.Forms.ComboBox();
            this.comboBox105 = new System.Windows.Forms.ComboBox();
            this.comboBox92 = new System.Windows.Forms.ComboBox();
            this.comboBox101 = new System.Windows.Forms.ComboBox();
            this.comboBox94 = new System.Windows.Forms.ComboBox();
            this.comboBox97 = new System.Windows.Forms.ComboBox();
            this.comboBox91 = new System.Windows.Forms.ComboBox();
            this.comboBox93 = new System.Windows.Forms.ComboBox();
            this.comboBox90 = new System.Windows.Forms.ComboBox();
            this.comboBox89 = new System.Windows.Forms.ComboBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.comboBox141 = new System.Windows.Forms.ComboBox();
            this.comboBox140 = new System.Windows.Forms.ComboBox();
            this.label153 = new System.Windows.Forms.Label();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.label152 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.label149 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.checkBox26 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox30 = new System.Windows.Forms.CheckBox();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox29 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.checkBox28 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label147 = new System.Windows.Forms.Label();
            this.label148 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.comboBox138 = new System.Windows.Forms.ComboBox();
            this.comboBox139 = new System.Windows.Forms.ComboBox();
            this.comboBox137 = new System.Windows.Forms.ComboBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label162 = new System.Windows.Forms.Label();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.comboBox147 = new System.Windows.Forms.ComboBox();
            this.comboBox145 = new System.Windows.Forms.ComboBox();
            this.label159 = new System.Windows.Forms.Label();
            this.label157 = new System.Windows.Forms.Label();
            this.comboBox143 = new System.Windows.Forms.ComboBox();
            this.comboBox149 = new System.Windows.Forms.ComboBox();
            this.comboBox148 = new System.Windows.Forms.ComboBox();
            this.comboBox146 = new System.Windows.Forms.ComboBox();
            this.label161 = new System.Windows.Forms.Label();
            this.comboBox144 = new System.Windows.Forms.ComboBox();
            this.label160 = new System.Windows.Forms.Label();
            this.label155 = new System.Windows.Forms.Label();
            this.label158 = new System.Windows.Forms.Label();
            this.label156 = new System.Windows.Forms.Label();
            this.comboBox142 = new System.Windows.Forms.ComboBox();
            this.label154 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.label150 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.ItemSize = new System.Drawing.Size(44, 20);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(856, 450);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(848, 422);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "   既往病史   ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.AutoScrollMargin = new System.Drawing.Size(10, 10);
            this.panel1.AutoScrollMinSize = new System.Drawing.Size(10, 10);
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(231)))), ((int)(((byte)(239)))));
            this.panel1.Controls.Add(this.初诊日期_dateTimePicker);
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Controls.Add(this.现病史_textBox);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.主诉_TextBox);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(842, 416);
            this.panel1.TabIndex = 6;
            // 
            // 初诊日期_dateTimePicker
            // 
            this.初诊日期_dateTimePicker.Location = new System.Drawing.Point(582, 11);
            this.初诊日期_dateTimePicker.Name = "初诊日期_dateTimePicker";
            this.初诊日期_dateTimePicker.Size = new System.Drawing.Size(147, 21);
            this.初诊日期_dateTimePicker.TabIndex = 14;
            // 
            // groupBox5
            // 
            this.groupBox5.Location = new System.Drawing.Point(51, 634);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(678, 100);
            this.groupBox5.TabIndex = 13;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "不孕不育病史";
            // 
            // 现病史_textBox
            // 
            this.现病史_textBox.Location = new System.Drawing.Point(51, 49);
            this.现病史_textBox.Multiline = true;
            this.现病史_textBox.Name = "现病史_textBox";
            this.现病史_textBox.Size = new System.Drawing.Size(678, 157);
            this.现病史_textBox.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(9, 79);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(32, 26);
            this.button1.TabIndex = 11;
            this.button1.Text = "+";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "现病史";
            // 
            // 主诉_TextBox
            // 
            this.主诉_TextBox.Location = new System.Drawing.Point(51, 11);
            this.主诉_TextBox.Name = "主诉_TextBox";
            this.主诉_TextBox.Size = new System.Drawing.Size(443, 21);
            this.主诉_TextBox.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(523, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "初诊时间";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "主诉";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.comboBox39);
            this.groupBox4.Controls.Add(this.comboBox35);
            this.groupBox4.Controls.Add(this.comboBox44);
            this.groupBox4.Controls.Add(this.comboBox43);
            this.groupBox4.Controls.Add(this.comboBox38);
            this.groupBox4.Controls.Add(this.comboBox34);
            this.groupBox4.Controls.Add(this.comboBox29);
            this.groupBox4.Controls.Add(this.comboBox42);
            this.groupBox4.Controls.Add(this.comboBox28);
            this.groupBox4.Controls.Add(this.comboBox37);
            this.groupBox4.Controls.Add(this.comboBox33);
            this.groupBox4.Controls.Add(this.comboBox40);
            this.groupBox4.Controls.Add(this.comboBox41);
            this.groupBox4.Controls.Add(this.comboBox31);
            this.groupBox4.Controls.Add(this.comboBox36);
            this.groupBox4.Controls.Add(this.comboBox32);
            this.groupBox4.Controls.Add(this.label41);
            this.groupBox4.Controls.Add(this.label46);
            this.groupBox4.Controls.Add(this.comboBox30);
            this.groupBox4.Controls.Add(this.label45);
            this.groupBox4.Controls.Add(this.label37);
            this.groupBox4.Controls.Add(this.label40);
            this.groupBox4.Controls.Add(this.comboBox27);
            this.groupBox4.Controls.Add(this.label36);
            this.groupBox4.Controls.Add(this.label44);
            this.groupBox4.Controls.Add(this.label31);
            this.groupBox4.Controls.Add(this.label39);
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Controls.Add(this.label35);
            this.groupBox4.Controls.Add(this.label43);
            this.groupBox4.Controls.Add(this.label42);
            this.groupBox4.Controls.Add(this.label38);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.label33);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.label34);
            this.groupBox4.Location = new System.Drawing.Point(51, 495);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(678, 133);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "婚育史";
            // 
            // comboBox39
            // 
            this.comboBox39.FormattingEnabled = true;
            this.comboBox39.Location = new System.Drawing.Point(495, 57);
            this.comboBox39.Name = "comboBox39";
            this.comboBox39.Size = new System.Drawing.Size(71, 20);
            this.comboBox39.TabIndex = 1;
            // 
            // comboBox35
            // 
            this.comboBox35.FormattingEnabled = true;
            this.comboBox35.Location = new System.Drawing.Point(495, 35);
            this.comboBox35.Name = "comboBox35";
            this.comboBox35.Size = new System.Drawing.Size(71, 20);
            this.comboBox35.TabIndex = 1;
            // 
            // comboBox44
            // 
            this.comboBox44.FormattingEnabled = true;
            this.comboBox44.Location = new System.Drawing.Point(146, 101);
            this.comboBox44.Name = "comboBox44";
            this.comboBox44.Size = new System.Drawing.Size(473, 20);
            this.comboBox44.TabIndex = 1;
            this.comboBox44.Text = "无";
            // 
            // comboBox43
            // 
            this.comboBox43.FormattingEnabled = true;
            this.comboBox43.Location = new System.Drawing.Point(335, 78);
            this.comboBox43.Name = "comboBox43";
            this.comboBox43.Size = new System.Drawing.Size(71, 20);
            this.comboBox43.TabIndex = 1;
            // 
            // comboBox38
            // 
            this.comboBox38.FormattingEnabled = true;
            this.comboBox38.Location = new System.Drawing.Point(335, 57);
            this.comboBox38.Name = "comboBox38";
            this.comboBox38.Size = new System.Drawing.Size(71, 20);
            this.comboBox38.TabIndex = 1;
            // 
            // comboBox34
            // 
            this.comboBox34.FormattingEnabled = true;
            this.comboBox34.Location = new System.Drawing.Point(335, 35);
            this.comboBox34.Name = "comboBox34";
            this.comboBox34.Size = new System.Drawing.Size(71, 20);
            this.comboBox34.TabIndex = 1;
            // 
            // comboBox29
            // 
            this.comboBox29.FormattingEnabled = true;
            this.comboBox29.Location = new System.Drawing.Point(495, 14);
            this.comboBox29.Name = "comboBox29";
            this.comboBox29.Size = new System.Drawing.Size(71, 20);
            this.comboBox29.TabIndex = 1;
            // 
            // comboBox42
            // 
            this.comboBox42.FormattingEnabled = true;
            this.comboBox42.Location = new System.Drawing.Point(77, 78);
            this.comboBox42.Name = "comboBox42";
            this.comboBox42.Size = new System.Drawing.Size(71, 20);
            this.comboBox42.TabIndex = 1;
            // 
            // comboBox28
            // 
            this.comboBox28.FormattingEnabled = true;
            this.comboBox28.Location = new System.Drawing.Point(335, 14);
            this.comboBox28.Name = "comboBox28";
            this.comboBox28.Size = new System.Drawing.Size(71, 20);
            this.comboBox28.TabIndex = 1;
            // 
            // comboBox37
            // 
            this.comboBox37.FormattingEnabled = true;
            this.comboBox37.Location = new System.Drawing.Point(77, 57);
            this.comboBox37.Name = "comboBox37";
            this.comboBox37.Size = new System.Drawing.Size(71, 20);
            this.comboBox37.TabIndex = 1;
            // 
            // comboBox33
            // 
            this.comboBox33.FormattingEnabled = true;
            this.comboBox33.Location = new System.Drawing.Point(77, 35);
            this.comboBox33.Name = "comboBox33";
            this.comboBox33.Size = new System.Drawing.Size(71, 20);
            this.comboBox33.TabIndex = 1;
            // 
            // comboBox40
            // 
            this.comboBox40.FormattingEnabled = true;
            this.comboBox40.Location = new System.Drawing.Point(617, 57);
            this.comboBox40.Name = "comboBox40";
            this.comboBox40.Size = new System.Drawing.Size(47, 20);
            this.comboBox40.TabIndex = 1;
            // 
            // comboBox41
            // 
            this.comboBox41.FormattingEnabled = true;
            this.comboBox41.Location = new System.Drawing.Point(205, 78);
            this.comboBox41.Name = "comboBox41";
            this.comboBox41.Size = new System.Drawing.Size(71, 20);
            this.comboBox41.TabIndex = 1;
            // 
            // comboBox31
            // 
            this.comboBox31.FormattingEnabled = true;
            this.comboBox31.Location = new System.Drawing.Point(617, 35);
            this.comboBox31.Name = "comboBox31";
            this.comboBox31.Size = new System.Drawing.Size(47, 20);
            this.comboBox31.TabIndex = 1;
            // 
            // comboBox36
            // 
            this.comboBox36.FormattingEnabled = true;
            this.comboBox36.Location = new System.Drawing.Point(205, 57);
            this.comboBox36.Name = "comboBox36";
            this.comboBox36.Size = new System.Drawing.Size(71, 20);
            this.comboBox36.TabIndex = 1;
            // 
            // comboBox32
            // 
            this.comboBox32.FormattingEnabled = true;
            this.comboBox32.Location = new System.Drawing.Point(205, 35);
            this.comboBox32.Name = "comboBox32";
            this.comboBox32.Size = new System.Drawing.Size(71, 20);
            this.comboBox32.TabIndex = 1;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(436, 60);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(53, 12);
            this.label41.TabIndex = 0;
            this.label41.Text = "现有子女";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(34, 104);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(89, 12);
            this.label46.TabIndex = 0;
            this.label46.Text = "宫外孕处理情况";
            // 
            // comboBox30
            // 
            this.comboBox30.FormattingEnabled = true;
            this.comboBox30.Items.AddRange(new object[] {
            "否",
            "是"});
            this.comboBox30.Location = new System.Drawing.Point(77, 14);
            this.comboBox30.Name = "comboBox30";
            this.comboBox30.Size = new System.Drawing.Size(71, 20);
            this.comboBox30.TabIndex = 1;
            this.comboBox30.Text = "否";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(280, 81);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(53, 12);
            this.label45.TabIndex = 0;
            this.label45.Text = "右侧次数";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(436, 38);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(53, 12);
            this.label37.TabIndex = 0;
            this.label37.Text = "自然流产";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(288, 60);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(41, 12);
            this.label40.TabIndex = 0;
            this.label40.Text = "足月产";
            // 
            // comboBox27
            // 
            this.comboBox27.FormattingEnabled = true;
            this.comboBox27.Items.AddRange(new object[] {
            "否",
            "是"});
            this.comboBox27.Location = new System.Drawing.Point(205, 14);
            this.comboBox27.Name = "comboBox27";
            this.comboBox27.Size = new System.Drawing.Size(71, 20);
            this.comboBox27.TabIndex = 1;
            this.comboBox27.Text = "否";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(276, 38);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(53, 12);
            this.label36.TabIndex = 0;
            this.label36.Text = "人工流产";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(154, 82);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(53, 12);
            this.label44.TabIndex = 0;
            this.label44.Text = "左侧次数";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(412, 17);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(77, 12);
            this.label31.TabIndex = 0;
            this.label31.Text = "末次妊娠时间";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(170, 60);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(29, 12);
            this.label39.TabIndex = 0;
            this.label39.Text = "早产";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(300, 17);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(29, 12);
            this.label30.TabIndex = 0;
            this.label30.Text = "妊娠";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(182, 38);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(17, 12);
            this.label35.TabIndex = 0;
            this.label35.Text = "产";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(-2, 82);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(77, 12);
            this.label43.TabIndex = 0;
            this.label43.Text = "异位妊娠次数";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(566, 60);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(53, 12);
            this.label42.TabIndex = 0;
            this.label42.Text = "领养子女";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(42, 60);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(29, 12);
            this.label38.TabIndex = 0;
            this.label38.Text = "引产";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(582, 38);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(29, 12);
            this.label32.TabIndex = 0;
            this.label32.Text = "药流";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(54, 38);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(17, 12);
            this.label33.TabIndex = 0;
            this.label33.Text = "孕";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(170, 17);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(29, 12);
            this.label29.TabIndex = 0;
            this.label29.Text = "再婚";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(18, 17);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(53, 12);
            this.label34.TabIndex = 0;
            this.label34.Text = "近亲结婚";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.comboBox26);
            this.groupBox3.Controls.Add(this.comboBox25);
            this.groupBox3.Controls.Add(this.comboBox23);
            this.groupBox3.Controls.Add(this.comboBox24);
            this.groupBox3.Controls.Add(this.comboBox22);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.comboBox14);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Location = new System.Drawing.Point(51, 415);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(678, 74);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "月经史";
            // 
            // comboBox26
            // 
            this.comboBox26.FormattingEnabled = true;
            this.comboBox26.ItemHeight = 12;
            this.comboBox26.Items.AddRange(new object[] {
            "无"});
            this.comboBox26.Location = new System.Drawing.Point(495, 48);
            this.comboBox26.Name = "comboBox26";
            this.comboBox26.Size = new System.Drawing.Size(106, 20);
            this.comboBox26.TabIndex = 1;
            this.comboBox26.Text = "无";
            // 
            // comboBox25
            // 
            this.comboBox25.FormattingEnabled = true;
            this.comboBox25.ItemHeight = 12;
            this.comboBox25.Items.AddRange(new object[] {
            "无",
            "轻微",
            "剧痛"});
            this.comboBox25.Location = new System.Drawing.Point(274, 48);
            this.comboBox25.Name = "comboBox25";
            this.comboBox25.Size = new System.Drawing.Size(106, 20);
            this.comboBox25.TabIndex = 1;
            this.comboBox25.Text = "无";
            // 
            // comboBox23
            // 
            this.comboBox23.FormattingEnabled = true;
            this.comboBox23.ItemHeight = 12;
            this.comboBox23.Items.AddRange(new object[] {
            "4",
            "5",
            "6",
            "7"});
            this.comboBox23.Location = new System.Drawing.Point(495, 28);
            this.comboBox23.Name = "comboBox23";
            this.comboBox23.Size = new System.Drawing.Size(106, 20);
            this.comboBox23.TabIndex = 1;
            this.comboBox23.Text = "7";
            // 
            // comboBox24
            // 
            this.comboBox24.FormattingEnabled = true;
            this.comboBox24.Items.AddRange(new object[] {
            "较少",
            "正常",
            "较多"});
            this.comboBox24.Location = new System.Drawing.Point(69, 48);
            this.comboBox24.Name = "comboBox24";
            this.comboBox24.Size = new System.Drawing.Size(106, 20);
            this.comboBox24.TabIndex = 1;
            this.comboBox24.Text = "正常";
            // 
            // comboBox22
            // 
            this.comboBox22.FormattingEnabled = true;
            this.comboBox22.ItemHeight = 12;
            this.comboBox22.Items.AddRange(new object[] {
            "29",
            "30",
            "31",
            "32"});
            this.comboBox22.Location = new System.Drawing.Point(274, 28);
            this.comboBox22.Name = "comboBox22";
            this.comboBox22.Size = new System.Drawing.Size(106, 20);
            this.comboBox22.TabIndex = 1;
            this.comboBox22.Text = "28";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(460, 51);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(29, 12);
            this.label28.TabIndex = 0;
            this.label28.Text = "血块";
            // 
            // comboBox14
            // 
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.Items.AddRange(new object[] {
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17"});
            this.comboBox14.Location = new System.Drawing.Point(69, 28);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(106, 20);
            this.comboBox14.TabIndex = 1;
            this.comboBox14.Text = "12";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(239, 51);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(29, 12);
            this.label27.TabIndex = 0;
            this.label27.Text = "痛经";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(412, 31);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 12);
            this.label25.TabIndex = 0;
            this.label25.Text = "持续时间(天)";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(10, 51);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(29, 12);
            this.label26.TabIndex = 0;
            this.label26.Text = "经量";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(191, 31);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(77, 12);
            this.label24.TabIndex = 0;
            this.label24.Text = "月经周期(天)";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(10, 31);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 12);
            this.label17.TabIndex = 0;
            this.label17.Text = "初潮(岁)";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboBox15);
            this.groupBox2.Controls.Add(this.comboBox12);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.comboBox13);
            this.groupBox2.Controls.Add(this.textBox13);
            this.groupBox2.Controls.Add(this.comboBox16);
            this.groupBox2.Controls.Add(this.comboBox17);
            this.groupBox2.Controls.Add(this.textBox15);
            this.groupBox2.Controls.Add(this.textBox16);
            this.groupBox2.Controls.Add(this.comboBox18);
            this.groupBox2.Controls.Add(this.comboBox19);
            this.groupBox2.Controls.Add(this.comboBox20);
            this.groupBox2.Controls.Add(this.textBox17);
            this.groupBox2.Controls.Add(this.textBox18);
            this.groupBox2.Controls.Add(this.textBox19);
            this.groupBox2.Controls.Add(this.comboBox21);
            this.groupBox2.Controls.Add(this.textBox20);
            this.groupBox2.Location = new System.Drawing.Point(51, 321);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(678, 88);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "个人史";
            // 
            // comboBox15
            // 
            this.comboBox15.FormattingEnabled = true;
            this.comboBox15.Location = new System.Drawing.Point(495, 60);
            this.comboBox15.Name = "comboBox15";
            this.comboBox15.Size = new System.Drawing.Size(106, 20);
            this.comboBox15.TabIndex = 3;
            this.comboBox15.Text = "良好";
            // 
            // comboBox12
            // 
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Location = new System.Drawing.Point(274, 60);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(106, 20);
            this.comboBox12.TabIndex = 3;
            this.comboBox12.Text = "良好";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(460, 63);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 12);
            this.label14.TabIndex = 2;
            this.label14.Text = "现在";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(424, 41);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 12);
            this.label15.TabIndex = 2;
            this.label15.Text = "精神疾病史";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(460, 22);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 2;
            this.label16.Text = "吸毒";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(10, 63);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 2;
            this.label18.Text = "出生缺陷";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(10, 42);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 2;
            this.label19.Text = "习惯用药";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(191, 64);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(77, 12);
            this.label20.TabIndex = 2;
            this.label20.Text = "健康状况过去";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(203, 43);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 12);
            this.label21.TabIndex = 2;
            this.label21.Text = "药物过敏史";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(239, 22);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 12);
            this.label22.TabIndex = 2;
            this.label22.Text = "酗酒";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(34, 22);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(29, 12);
            this.label23.TabIndex = 2;
            this.label23.Text = "吸烟";
            // 
            // comboBox13
            // 
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Location = new System.Drawing.Point(515, 39);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(86, 20);
            this.comboBox13.TabIndex = 1;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(495, 38);
            this.textBox13.MaxLength = 1;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(20, 21);
            this.textBox13.TabIndex = 0;
            this.textBox13.Text = "无";
            // 
            // comboBox16
            // 
            this.comboBox16.FormattingEnabled = true;
            this.comboBox16.Location = new System.Drawing.Point(515, 19);
            this.comboBox16.Name = "comboBox16";
            this.comboBox16.Size = new System.Drawing.Size(86, 20);
            this.comboBox16.TabIndex = 1;
            // 
            // comboBox17
            // 
            this.comboBox17.FormattingEnabled = true;
            this.comboBox17.Location = new System.Drawing.Point(294, 40);
            this.comboBox17.Name = "comboBox17";
            this.comboBox17.Size = new System.Drawing.Size(86, 20);
            this.comboBox17.TabIndex = 1;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(495, 18);
            this.textBox15.MaxLength = 1;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(20, 21);
            this.textBox15.TabIndex = 0;
            this.textBox15.Text = "无";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(274, 39);
            this.textBox16.MaxLength = 1;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(20, 21);
            this.textBox16.TabIndex = 0;
            this.textBox16.Text = "无";
            // 
            // comboBox18
            // 
            this.comboBox18.FormattingEnabled = true;
            this.comboBox18.Location = new System.Drawing.Point(89, 59);
            this.comboBox18.Name = "comboBox18";
            this.comboBox18.Size = new System.Drawing.Size(86, 20);
            this.comboBox18.TabIndex = 1;
            // 
            // comboBox19
            // 
            this.comboBox19.FormattingEnabled = true;
            this.comboBox19.Location = new System.Drawing.Point(294, 20);
            this.comboBox19.Name = "comboBox19";
            this.comboBox19.Size = new System.Drawing.Size(86, 20);
            this.comboBox19.TabIndex = 1;
            // 
            // comboBox20
            // 
            this.comboBox20.FormattingEnabled = true;
            this.comboBox20.Location = new System.Drawing.Point(89, 40);
            this.comboBox20.Name = "comboBox20";
            this.comboBox20.Size = new System.Drawing.Size(86, 20);
            this.comboBox20.TabIndex = 1;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(69, 60);
            this.textBox17.MaxLength = 1;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(20, 21);
            this.textBox17.TabIndex = 0;
            this.textBox17.Text = "无";
            this.textBox17.Click += new System.EventHandler(this.textBox3_Click);
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(274, 19);
            this.textBox18.MaxLength = 1;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(20, 21);
            this.textBox18.TabIndex = 0;
            this.textBox18.Text = "无";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(69, 39);
            this.textBox19.MaxLength = 1;
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(20, 21);
            this.textBox19.TabIndex = 0;
            this.textBox19.Text = "无";
            // 
            // comboBox21
            // 
            this.comboBox21.FormattingEnabled = true;
            this.comboBox21.Location = new System.Drawing.Point(89, 20);
            this.comboBox21.Name = "comboBox21";
            this.comboBox21.Size = new System.Drawing.Size(86, 20);
            this.comboBox21.TabIndex = 1;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(69, 19);
            this.textBox20.MaxLength = 1;
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(20, 21);
            this.textBox20.TabIndex = 0;
            this.textBox20.Text = "无";
            this.textBox20.TextChanged += new System.EventHandler(this.textBox20_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.Appendicitis);
            this.groupBox1.Controls.Add(this.diseasesOfUrinarySystem);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.CardiovascularDiseases);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.kidneyDisease);
            this.groupBox1.Controls.Add(this.tubercular);
            this.groupBox1.Controls.Add(this.hepatitis);
            this.groupBox1.Controls.Add(this.comboBox10);
            this.groupBox1.Controls.Add(this.textBox11);
            this.groupBox1.Controls.Add(this.Appendicitis_comboBox);
            this.groupBox1.Controls.Add(this.Appendicitis_textBox);
            this.groupBox1.Controls.Add(this.comboBox11);
            this.groupBox1.Controls.Add(this.性传播疾病史_comboBox);
            this.groupBox1.Controls.Add(this.diseasesOfUrinarySystem_comboBox);
            this.groupBox1.Controls.Add(this.肾脏疾病_comboBox);
            this.groupBox1.Controls.Add(this.性传播疾病史_textBox);
            this.groupBox1.Controls.Add(this.diseasesOfUrinarySystem_textBox);
            this.groupBox1.Controls.Add(this.肾脏疾病_textBox);
            this.groupBox1.Controls.Add(this.盆腔炎_comboBox);
            this.groupBox1.Controls.Add(this.结核_comboBox);
            this.groupBox1.Controls.Add(this.心血管疾病_comboBox);
            this.groupBox1.Controls.Add(this.盆腔炎_textBox);
            this.groupBox1.Controls.Add(this.结核_textbox);
            this.groupBox1.Controls.Add(this.心血管疾病_textBox);
            this.groupBox1.Controls.Add(this.肝炎_comboBox);
            this.groupBox1.Controls.Add(this.肝炎_textBox);
            this.groupBox1.Location = new System.Drawing.Point(51, 212);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(678, 106);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "既往史";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(448, 63);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 2;
            this.label12.Text = "手术史";
            // 
            // Appendicitis
            // 
            this.Appendicitis.AutoSize = true;
            this.Appendicitis.Location = new System.Drawing.Point(448, 42);
            this.Appendicitis.Name = "Appendicitis";
            this.Appendicitis.Size = new System.Drawing.Size(41, 12);
            this.Appendicitis.TabIndex = 2;
            this.Appendicitis.Text = "阑尾炎";
            // 
            // diseasesOfUrinarySystem
            // 
            this.diseasesOfUrinarySystem.AutoSize = true;
            this.diseasesOfUrinarySystem.Location = new System.Drawing.Point(412, 22);
            this.diseasesOfUrinarySystem.Name = "diseasesOfUrinarySystem";
            this.diseasesOfUrinarySystem.Size = new System.Drawing.Size(77, 12);
            this.diseasesOfUrinarySystem.TabIndex = 2;
            this.diseasesOfUrinarySystem.Text = "泌尿系统疾病";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(34, 84);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 2;
            this.label13.Text = "其它";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(22, 62);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 2;
            this.label11.Text = "盆腔炎";
            // 
            // CardiovascularDiseases
            // 
            this.CardiovascularDiseases.AutoSize = true;
            this.CardiovascularDiseases.Location = new System.Drawing.Point(-2, 40);
            this.CardiovascularDiseases.Name = "CardiovascularDiseases";
            this.CardiovascularDiseases.Size = new System.Drawing.Size(65, 12);
            this.CardiovascularDiseases.TabIndex = 2;
            this.CardiovascularDiseases.Text = "心血管疾病";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(191, 63);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 12);
            this.label10.TabIndex = 2;
            this.label10.Text = "性传播疾病史";
            // 
            // kidneyDisease
            // 
            this.kidneyDisease.AutoSize = true;
            this.kidneyDisease.Location = new System.Drawing.Point(215, 43);
            this.kidneyDisease.Name = "kidneyDisease";
            this.kidneyDisease.Size = new System.Drawing.Size(53, 12);
            this.kidneyDisease.TabIndex = 2;
            this.kidneyDisease.Text = "肾脏疾病";
            // 
            // tubercular
            // 
            this.tubercular.AutoSize = true;
            this.tubercular.Location = new System.Drawing.Point(239, 22);
            this.tubercular.Name = "tubercular";
            this.tubercular.Size = new System.Drawing.Size(29, 12);
            this.tubercular.TabIndex = 2;
            this.tubercular.Text = "结核";
            // 
            // hepatitis
            // 
            this.hepatitis.AutoSize = true;
            this.hepatitis.Location = new System.Drawing.Point(34, 22);
            this.hepatitis.Name = "hepatitis";
            this.hepatitis.Size = new System.Drawing.Size(29, 12);
            this.hepatitis.TabIndex = 2;
            this.hepatitis.Text = "肝炎";
            // 
            // comboBox10
            // 
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Location = new System.Drawing.Point(515, 60);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(86, 20);
            this.comboBox10.TabIndex = 1;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(495, 59);
            this.textBox11.MaxLength = 1;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(20, 21);
            this.textBox11.TabIndex = 0;
            this.textBox11.Text = "无";
            // 
            // Appendicitis_comboBox
            // 
            this.Appendicitis_comboBox.FormattingEnabled = true;
            this.Appendicitis_comboBox.Location = new System.Drawing.Point(515, 40);
            this.Appendicitis_comboBox.Name = "Appendicitis_comboBox";
            this.Appendicitis_comboBox.Size = new System.Drawing.Size(86, 20);
            this.Appendicitis_comboBox.TabIndex = 1;
            // 
            // Appendicitis_textBox
            // 
            this.Appendicitis_textBox.Location = new System.Drawing.Point(495, 39);
            this.Appendicitis_textBox.MaxLength = 1;
            this.Appendicitis_textBox.Name = "Appendicitis_textBox";
            this.Appendicitis_textBox.Size = new System.Drawing.Size(20, 21);
            this.Appendicitis_textBox.TabIndex = 0;
            this.Appendicitis_textBox.Text = "无";
            // 
            // comboBox11
            // 
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Items.AddRange(new object[] {
            "无"});
            this.comboBox11.Location = new System.Drawing.Point(69, 80);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(532, 20);
            this.comboBox11.TabIndex = 1;
            this.comboBox11.Text = "无";
            // 
            // 性传播疾病史_comboBox
            // 
            this.性传播疾病史_comboBox.FormattingEnabled = true;
            this.性传播疾病史_comboBox.Location = new System.Drawing.Point(294, 60);
            this.性传播疾病史_comboBox.Name = "性传播疾病史_comboBox";
            this.性传播疾病史_comboBox.Size = new System.Drawing.Size(86, 20);
            this.性传播疾病史_comboBox.TabIndex = 1;
            // 
            // diseasesOfUrinarySystem_comboBox
            // 
            this.diseasesOfUrinarySystem_comboBox.FormattingEnabled = true;
            this.diseasesOfUrinarySystem_comboBox.Location = new System.Drawing.Point(515, 20);
            this.diseasesOfUrinarySystem_comboBox.Name = "diseasesOfUrinarySystem_comboBox";
            this.diseasesOfUrinarySystem_comboBox.Size = new System.Drawing.Size(86, 20);
            this.diseasesOfUrinarySystem_comboBox.TabIndex = 1;
            // 
            // 肾脏疾病_comboBox
            // 
            this.肾脏疾病_comboBox.FormattingEnabled = true;
            this.肾脏疾病_comboBox.Location = new System.Drawing.Point(294, 40);
            this.肾脏疾病_comboBox.Name = "肾脏疾病_comboBox";
            this.肾脏疾病_comboBox.Size = new System.Drawing.Size(86, 20);
            this.肾脏疾病_comboBox.TabIndex = 1;
            // 
            // 性传播疾病史_textBox
            // 
            this.性传播疾病史_textBox.Location = new System.Drawing.Point(274, 59);
            this.性传播疾病史_textBox.MaxLength = 1;
            this.性传播疾病史_textBox.Name = "性传播疾病史_textBox";
            this.性传播疾病史_textBox.Size = new System.Drawing.Size(20, 21);
            this.性传播疾病史_textBox.TabIndex = 0;
            this.性传播疾病史_textBox.Text = "无";
            // 
            // diseasesOfUrinarySystem_textBox
            // 
            this.diseasesOfUrinarySystem_textBox.Location = new System.Drawing.Point(495, 19);
            this.diseasesOfUrinarySystem_textBox.MaxLength = 1;
            this.diseasesOfUrinarySystem_textBox.Name = "diseasesOfUrinarySystem_textBox";
            this.diseasesOfUrinarySystem_textBox.Size = new System.Drawing.Size(20, 21);
            this.diseasesOfUrinarySystem_textBox.TabIndex = 0;
            this.diseasesOfUrinarySystem_textBox.Text = "无";
            // 
            // 肾脏疾病_textBox
            // 
            this.肾脏疾病_textBox.Location = new System.Drawing.Point(274, 39);
            this.肾脏疾病_textBox.MaxLength = 1;
            this.肾脏疾病_textBox.Name = "肾脏疾病_textBox";
            this.肾脏疾病_textBox.Size = new System.Drawing.Size(20, 21);
            this.肾脏疾病_textBox.TabIndex = 0;
            this.肾脏疾病_textBox.Text = "无";
            // 
            // 盆腔炎_comboBox
            // 
            this.盆腔炎_comboBox.FormattingEnabled = true;
            this.盆腔炎_comboBox.Location = new System.Drawing.Point(89, 60);
            this.盆腔炎_comboBox.Name = "盆腔炎_comboBox";
            this.盆腔炎_comboBox.Size = new System.Drawing.Size(86, 20);
            this.盆腔炎_comboBox.TabIndex = 1;
            // 
            // 结核_comboBox
            // 
            this.结核_comboBox.FormattingEnabled = true;
            this.结核_comboBox.Location = new System.Drawing.Point(294, 20);
            this.结核_comboBox.Name = "结核_comboBox";
            this.结核_comboBox.Size = new System.Drawing.Size(86, 20);
            this.结核_comboBox.TabIndex = 1;
            // 
            // 心血管疾病_comboBox
            // 
            this.心血管疾病_comboBox.FormattingEnabled = true;
            this.心血管疾病_comboBox.Location = new System.Drawing.Point(89, 40);
            this.心血管疾病_comboBox.Name = "心血管疾病_comboBox";
            this.心血管疾病_comboBox.Size = new System.Drawing.Size(86, 20);
            this.心血管疾病_comboBox.TabIndex = 1;
            // 
            // 盆腔炎_textBox
            // 
            this.盆腔炎_textBox.Location = new System.Drawing.Point(69, 59);
            this.盆腔炎_textBox.MaxLength = 1;
            this.盆腔炎_textBox.Name = "盆腔炎_textBox";
            this.盆腔炎_textBox.Size = new System.Drawing.Size(20, 21);
            this.盆腔炎_textBox.TabIndex = 0;
            this.盆腔炎_textBox.Text = "无";
            // 
            // 结核_textbox
            // 
            this.结核_textbox.Location = new System.Drawing.Point(274, 19);
            this.结核_textbox.MaxLength = 1;
            this.结核_textbox.Name = "结核_textbox";
            this.结核_textbox.Size = new System.Drawing.Size(20, 21);
            this.结核_textbox.TabIndex = 0;
            this.结核_textbox.Text = "无";
            this.结核_textbox.Click += new System.EventHandler(this.textBox4_Click);
            // 
            // 心血管疾病_textBox
            // 
            this.心血管疾病_textBox.Location = new System.Drawing.Point(69, 39);
            this.心血管疾病_textBox.MaxLength = 1;
            this.心血管疾病_textBox.Name = "心血管疾病_textBox";
            this.心血管疾病_textBox.Size = new System.Drawing.Size(20, 21);
            this.心血管疾病_textBox.TabIndex = 0;
            this.心血管疾病_textBox.Text = "无";
            // 
            // 肝炎_comboBox
            // 
            this.肝炎_comboBox.FormattingEnabled = true;
            this.肝炎_comboBox.Location = new System.Drawing.Point(89, 20);
            this.肝炎_comboBox.Name = "肝炎_comboBox";
            this.肝炎_comboBox.Size = new System.Drawing.Size(86, 20);
            this.肝炎_comboBox.TabIndex = 2;
            // 
            // 肝炎_textBox
            // 
            this.肝炎_textBox.Location = new System.Drawing.Point(69, 19);
            this.肝炎_textBox.MaxLength = 1;
            this.肝炎_textBox.Name = "肝炎_textBox";
            this.肝炎_textBox.Size = new System.Drawing.Size(20, 21);
            this.肝炎_textBox.TabIndex = 0;
            this.肝炎_textBox.Text = "无";
            this.肝炎_textBox.Click += new System.EventHandler(this.textBox3_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.AutoScrollMargin = new System.Drawing.Size(33, 33);
            this.tabPage2.AutoScrollMinSize = new System.Drawing.Size(44, 44);
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(231)))), ((int)(((byte)(239)))));
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(848, 422);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "   常规检查   ";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label92);
            this.groupBox8.Controls.Add(this.label76);
            this.groupBox8.Controls.Add(this.label71);
            this.groupBox8.Controls.Add(this.label93);
            this.groupBox8.Controls.Add(this.label75);
            this.groupBox8.Controls.Add(this.label80);
            this.groupBox8.Controls.Add(this.label69);
            this.groupBox8.Controls.Add(this.label96);
            this.groupBox8.Controls.Add(this.label94);
            this.groupBox8.Controls.Add(this.label97);
            this.groupBox8.Controls.Add(this.label95);
            this.groupBox8.Controls.Add(this.label73);
            this.groupBox8.Controls.Add(this.comboBox83);
            this.groupBox8.Controls.Add(this.comboBox84);
            this.groupBox8.Controls.Add(this.comboBox64);
            this.groupBox8.Controls.Add(this.comboBox71);
            this.groupBox8.Controls.Add(this.comboBox66);
            this.groupBox8.Controls.Add(this.comboBox62);
            this.groupBox8.Controls.Add(this.comboBox60);
            this.groupBox8.Controls.Add(this.comboBox87);
            this.groupBox8.Controls.Add(this.comboBox88);
            this.groupBox8.Controls.Add(this.comboBox86);
            this.groupBox8.Controls.Add(this.comboBox85);
            this.groupBox8.Controls.Add(this.comboBox67);
            this.groupBox8.Location = new System.Drawing.Point(44, 330);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(749, 192);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(192, 56);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(29, 12);
            this.label92.TabIndex = 5;
            this.label92.Text = "详述";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(144, 36);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(77, 12);
            this.label76.TabIndex = 5;
            this.label76.Text = "子宫内膜活检";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(192, 16);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(29, 12);
            this.label71.TabIndex = 5;
            this.label71.Text = "详述";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(-2, 97);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(149, 12);
            this.label93.TabIndex = 5;
            this.label93.Text = "子宫输卵管造影：子宫形态";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(-2, 77);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(89, 12);
            this.label75.TabIndex = 5;
            this.label75.Text = "子宫输卵管通液";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(22, 57);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(65, 12);
            this.label80.TabIndex = 5;
            this.label80.Text = "腹腔镜日期";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(22, 17);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(65, 12);
            this.label69.TabIndex = 5;
            this.label69.Text = "宫腔镜日期";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(455, 137);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(29, 12);
            this.label96.TabIndex = 5;
            this.label96.Text = "胸片";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(419, 117);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(65, 12);
            this.label94.TabIndex = 5;
            this.label94.Text = "左侧输卵管";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(40, 157);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(47, 12);
            this.label97.TabIndex = 5;
            this.label97.Text = "妇科B超";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(46, 137);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(41, 12);
            this.label95.TabIndex = 5;
            this.label95.Text = "心电图";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(22, 117);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(65, 12);
            this.label73.TabIndex = 5;
            this.label73.Text = "左侧输卵管";
            // 
            // comboBox83
            // 
            this.comboBox83.FormattingEnabled = true;
            this.comboBox83.Location = new System.Drawing.Point(227, 53);
            this.comboBox83.Name = "comboBox83";
            this.comboBox83.Size = new System.Drawing.Size(499, 20);
            this.comboBox83.TabIndex = 4;
            this.comboBox83.Text = "未做";
            // 
            // comboBox84
            // 
            this.comboBox84.FormattingEnabled = true;
            this.comboBox84.Location = new System.Drawing.Point(153, 94);
            this.comboBox84.Name = "comboBox84";
            this.comboBox84.Size = new System.Drawing.Size(573, 20);
            this.comboBox84.TabIndex = 4;
            this.comboBox84.Text = "未做";
            // 
            // comboBox64
            // 
            this.comboBox64.FormattingEnabled = true;
            this.comboBox64.Location = new System.Drawing.Point(93, 74);
            this.comboBox64.Name = "comboBox64";
            this.comboBox64.Size = new System.Drawing.Size(633, 20);
            this.comboBox64.TabIndex = 4;
            this.comboBox64.Text = "未做";
            // 
            // comboBox71
            // 
            this.comboBox71.FormattingEnabled = true;
            this.comboBox71.Location = new System.Drawing.Point(93, 54);
            this.comboBox71.Name = "comboBox71";
            this.comboBox71.Size = new System.Drawing.Size(88, 20);
            this.comboBox71.TabIndex = 4;
            this.comboBox71.Text = "未做";
            // 
            // comboBox66
            // 
            this.comboBox66.FormattingEnabled = true;
            this.comboBox66.Location = new System.Drawing.Point(227, 33);
            this.comboBox66.Name = "comboBox66";
            this.comboBox66.Size = new System.Drawing.Size(499, 20);
            this.comboBox66.TabIndex = 4;
            // 
            // comboBox62
            // 
            this.comboBox62.FormattingEnabled = true;
            this.comboBox62.Location = new System.Drawing.Point(227, 13);
            this.comboBox62.Name = "comboBox62";
            this.comboBox62.Size = new System.Drawing.Size(499, 20);
            this.comboBox62.TabIndex = 4;
            this.comboBox62.Text = "未做";
            // 
            // comboBox60
            // 
            this.comboBox60.FormattingEnabled = true;
            this.comboBox60.Location = new System.Drawing.Point(93, 13);
            this.comboBox60.Name = "comboBox60";
            this.comboBox60.Size = new System.Drawing.Size(88, 20);
            this.comboBox60.TabIndex = 4;
            this.comboBox60.Text = "未做";
            // 
            // comboBox87
            // 
            this.comboBox87.FormattingEnabled = true;
            this.comboBox87.Location = new System.Drawing.Point(487, 134);
            this.comboBox87.Name = "comboBox87";
            this.comboBox87.Size = new System.Drawing.Size(239, 20);
            this.comboBox87.TabIndex = 4;
            this.comboBox87.Text = "未做";
            // 
            // comboBox88
            // 
            this.comboBox88.FormattingEnabled = true;
            this.comboBox88.Location = new System.Drawing.Point(95, 154);
            this.comboBox88.Name = "comboBox88";
            this.comboBox88.Size = new System.Drawing.Size(239, 20);
            this.comboBox88.TabIndex = 4;
            this.comboBox88.Text = "未做";
            // 
            // comboBox86
            // 
            this.comboBox86.FormattingEnabled = true;
            this.comboBox86.Location = new System.Drawing.Point(95, 134);
            this.comboBox86.Name = "comboBox86";
            this.comboBox86.Size = new System.Drawing.Size(239, 20);
            this.comboBox86.TabIndex = 4;
            this.comboBox86.Text = "未做";
            // 
            // comboBox85
            // 
            this.comboBox85.FormattingEnabled = true;
            this.comboBox85.Location = new System.Drawing.Point(487, 114);
            this.comboBox85.Name = "comboBox85";
            this.comboBox85.Size = new System.Drawing.Size(239, 20);
            this.comboBox85.TabIndex = 4;
            this.comboBox85.Text = "未做";
            // 
            // comboBox67
            // 
            this.comboBox67.FormattingEnabled = true;
            this.comboBox67.Location = new System.Drawing.Point(95, 114);
            this.comboBox67.Name = "comboBox67";
            this.comboBox67.Size = new System.Drawing.Size(239, 20);
            this.comboBox67.TabIndex = 4;
            this.comboBox67.Text = "未做";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label91);
            this.groupBox7.Controls.Add(this.label70);
            this.groupBox7.Controls.Add(this.label72);
            this.groupBox7.Controls.Add(this.label74);
            this.groupBox7.Controls.Add(this.label77);
            this.groupBox7.Controls.Add(this.label78);
            this.groupBox7.Controls.Add(this.label79);
            this.groupBox7.Controls.Add(this.label81);
            this.groupBox7.Controls.Add(this.label82);
            this.groupBox7.Controls.Add(this.label83);
            this.groupBox7.Controls.Add(this.comboBox82);
            this.groupBox7.Controls.Add(this.comboBox61);
            this.groupBox7.Controls.Add(this.comboBox81);
            this.groupBox7.Controls.Add(this.textBox61);
            this.groupBox7.Controls.Add(this.textBox60);
            this.groupBox7.Controls.Add(this.comboBox80);
            this.groupBox7.Controls.Add(this.comboBox63);
            this.groupBox7.Controls.Add(this.textBox59);
            this.groupBox7.Controls.Add(this.comboBox65);
            this.groupBox7.Controls.Add(this.comboBox79);
            this.groupBox7.Controls.Add(this.comboBox78);
            this.groupBox7.Controls.Add(this.comboBox68);
            this.groupBox7.Controls.Add(this.textBox58);
            this.groupBox7.Controls.Add(this.textBox57);
            this.groupBox7.Controls.Add(this.textBox47);
            this.groupBox7.Controls.Add(this.comboBox77);
            this.groupBox7.Controls.Add(this.comboBox69);
            this.groupBox7.Controls.Add(this.comboBox70);
            this.groupBox7.Controls.Add(this.comboBox76);
            this.groupBox7.Controls.Add(this.textBox56);
            this.groupBox7.Controls.Add(this.comboBox72);
            this.groupBox7.Controls.Add(this.textBox49);
            this.groupBox7.Controls.Add(this.textBox55);
            this.groupBox7.Controls.Add(this.comboBox73);
            this.groupBox7.Controls.Add(this.textBox51);
            this.groupBox7.Controls.Add(this.comboBox75);
            this.groupBox7.Controls.Add(this.textBox54);
            this.groupBox7.Controls.Add(this.comboBox74);
            this.groupBox7.Controls.Add(this.textBox53);
            this.groupBox7.Controls.Add(this.label84);
            this.groupBox7.Controls.Add(this.label85);
            this.groupBox7.Controls.Add(this.label86);
            this.groupBox7.Controls.Add(this.label87);
            this.groupBox7.Controls.Add(this.label88);
            this.groupBox7.Controls.Add(this.label89);
            this.groupBox7.Controls.Add(this.label90);
            this.groupBox7.Location = new System.Drawing.Point(44, 175);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(749, 149);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "妇科检查";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(591, 42);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(29, 12);
            this.label91.TabIndex = 5;
            this.label91.Text = "质地";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(579, 103);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(41, 12);
            this.label70.TabIndex = 5;
            this.label70.Text = "清洁度";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(30, 124);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(29, 12);
            this.label72.TabIndex = 5;
            this.label72.Text = "其他";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(386, 103);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(29, 12);
            this.label74.TabIndex = 5;
            this.label74.Text = "细菌";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(362, 83);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(53, 12);
            this.label77.TabIndex = 5;
            this.label77.Text = "右侧附件";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(199, 103);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(29, 12);
            this.label78.TabIndex = 5;
            this.label78.Text = "霉菌";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(199, 63);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(29, 12);
            this.label79.TabIndex = 5;
            this.label79.Text = "压痛";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(6, 83);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(53, 12);
            this.label81.TabIndex = 5;
            this.label81.Text = "左侧附件";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(30, 103);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(29, 12);
            this.label82.TabIndex = 5;
            this.label82.Text = "滴虫";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(18, 64);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(41, 12);
            this.label83.TabIndex = 5;
            this.label83.Text = "活动度";
            // 
            // comboBox82
            // 
            this.comboBox82.FormattingEnabled = true;
            this.comboBox82.Location = new System.Drawing.Point(656, 40);
            this.comboBox82.Name = "comboBox82";
            this.comboBox82.Size = new System.Drawing.Size(70, 20);
            this.comboBox82.TabIndex = 4;
            // 
            // comboBox61
            // 
            this.comboBox61.FormattingEnabled = true;
            this.comboBox61.Location = new System.Drawing.Point(626, 100);
            this.comboBox61.Name = "comboBox61";
            this.comboBox61.Size = new System.Drawing.Size(100, 20);
            this.comboBox61.TabIndex = 4;
            this.comboBox61.Text = "Ⅱ度";
            // 
            // comboBox81
            // 
            this.comboBox81.FormattingEnabled = true;
            this.comboBox81.Location = new System.Drawing.Point(656, 20);
            this.comboBox81.Name = "comboBox81";
            this.comboBox81.Size = new System.Drawing.Size(70, 20);
            this.comboBox81.TabIndex = 4;
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(626, 39);
            this.textBox61.MaxLength = 1;
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(30, 21);
            this.textBox61.TabIndex = 3;
            this.textBox61.Text = "中";
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(626, 19);
            this.textBox60.MaxLength = 1;
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(30, 21);
            this.textBox60.TabIndex = 3;
            this.textBox60.Text = "无";
            // 
            // comboBox80
            // 
            this.comboBox80.FormattingEnabled = true;
            this.comboBox80.Location = new System.Drawing.Point(451, 41);
            this.comboBox80.Name = "comboBox80";
            this.comboBox80.Size = new System.Drawing.Size(70, 20);
            this.comboBox80.TabIndex = 4;
            // 
            // comboBox63
            // 
            this.comboBox63.FormattingEnabled = true;
            this.comboBox63.Location = new System.Drawing.Point(65, 121);
            this.comboBox63.Name = "comboBox63";
            this.comboBox63.Size = new System.Drawing.Size(661, 20);
            this.comboBox63.TabIndex = 4;
            this.comboBox63.Text = "未见异常";
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(421, 40);
            this.textBox59.MaxLength = 1;
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(30, 21);
            this.textBox59.TabIndex = 3;
            this.textBox59.Text = "正常";
            // 
            // comboBox65
            // 
            this.comboBox65.FormattingEnabled = true;
            this.comboBox65.Location = new System.Drawing.Point(421, 101);
            this.comboBox65.Name = "comboBox65";
            this.comboBox65.Size = new System.Drawing.Size(100, 20);
            this.comboBox65.TabIndex = 4;
            this.comboBox65.Text = "无";
            // 
            // comboBox79
            // 
            this.comboBox79.FormattingEnabled = true;
            this.comboBox79.Location = new System.Drawing.Point(451, 21);
            this.comboBox79.Name = "comboBox79";
            this.comboBox79.Size = new System.Drawing.Size(70, 20);
            this.comboBox79.TabIndex = 4;
            // 
            // comboBox78
            // 
            this.comboBox78.FormattingEnabled = true;
            this.comboBox78.Location = new System.Drawing.Point(264, 41);
            this.comboBox78.Name = "comboBox78";
            this.comboBox78.Size = new System.Drawing.Size(70, 20);
            this.comboBox78.TabIndex = 4;
            // 
            // comboBox68
            // 
            this.comboBox68.FormattingEnabled = true;
            this.comboBox68.Location = new System.Drawing.Point(451, 80);
            this.comboBox68.Name = "comboBox68";
            this.comboBox68.Size = new System.Drawing.Size(275, 20);
            this.comboBox68.TabIndex = 4;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(421, 20);
            this.textBox58.MaxLength = 1;
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(30, 21);
            this.textBox58.TabIndex = 3;
            this.textBox58.Text = "光滑";
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(234, 40);
            this.textBox57.MaxLength = 1;
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(30, 21);
            this.textBox57.TabIndex = 3;
            this.textBox57.Text = "正常";
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(421, 79);
            this.textBox47.MaxLength = 1;
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(30, 21);
            this.textBox47.TabIndex = 3;
            this.textBox47.Text = "正常";
            // 
            // comboBox77
            // 
            this.comboBox77.FormattingEnabled = true;
            this.comboBox77.Location = new System.Drawing.Point(264, 21);
            this.comboBox77.Name = "comboBox77";
            this.comboBox77.Size = new System.Drawing.Size(70, 20);
            this.comboBox77.TabIndex = 4;
            // 
            // comboBox69
            // 
            this.comboBox69.FormattingEnabled = true;
            this.comboBox69.Location = new System.Drawing.Point(234, 101);
            this.comboBox69.Name = "comboBox69";
            this.comboBox69.Size = new System.Drawing.Size(100, 20);
            this.comboBox69.TabIndex = 4;
            this.comboBox69.Text = "无";
            // 
            // comboBox70
            // 
            this.comboBox70.FormattingEnabled = true;
            this.comboBox70.Location = new System.Drawing.Point(264, 61);
            this.comboBox70.Name = "comboBox70";
            this.comboBox70.Size = new System.Drawing.Size(70, 20);
            this.comboBox70.TabIndex = 4;
            // 
            // comboBox76
            // 
            this.comboBox76.FormattingEnabled = true;
            this.comboBox76.Location = new System.Drawing.Point(95, 41);
            this.comboBox76.Name = "comboBox76";
            this.comboBox76.Size = new System.Drawing.Size(70, 20);
            this.comboBox76.TabIndex = 4;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(234, 20);
            this.textBox56.MaxLength = 1;
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(30, 21);
            this.textBox56.TabIndex = 3;
            this.textBox56.Text = "正常";
            // 
            // comboBox72
            // 
            this.comboBox72.FormattingEnabled = true;
            this.comboBox72.Location = new System.Drawing.Point(95, 81);
            this.comboBox72.Name = "comboBox72";
            this.comboBox72.Size = new System.Drawing.Size(239, 20);
            this.comboBox72.TabIndex = 4;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(234, 60);
            this.textBox49.MaxLength = 1;
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(30, 21);
            this.textBox49.TabIndex = 3;
            this.textBox49.Text = "无";
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(65, 40);
            this.textBox55.MaxLength = 1;
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(30, 21);
            this.textBox55.TabIndex = 3;
            this.textBox55.Text = "无";
            // 
            // comboBox73
            // 
            this.comboBox73.FormattingEnabled = true;
            this.comboBox73.Location = new System.Drawing.Point(65, 101);
            this.comboBox73.Name = "comboBox73";
            this.comboBox73.Size = new System.Drawing.Size(100, 20);
            this.comboBox73.TabIndex = 4;
            this.comboBox73.Text = "无";
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(65, 80);
            this.textBox51.MaxLength = 1;
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(30, 21);
            this.textBox51.TabIndex = 3;
            this.textBox51.Text = "正常";
            // 
            // comboBox75
            // 
            this.comboBox75.FormattingEnabled = true;
            this.comboBox75.Location = new System.Drawing.Point(95, 21);
            this.comboBox75.Name = "comboBox75";
            this.comboBox75.Size = new System.Drawing.Size(70, 20);
            this.comboBox75.TabIndex = 4;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(65, 20);
            this.textBox54.MaxLength = 1;
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(30, 21);
            this.textBox54.TabIndex = 3;
            this.textBox54.Text = "正常";
            // 
            // comboBox74
            // 
            this.comboBox74.FormattingEnabled = true;
            this.comboBox74.Location = new System.Drawing.Point(95, 61);
            this.comboBox74.Name = "comboBox74";
            this.comboBox74.Size = new System.Drawing.Size(70, 20);
            this.comboBox74.TabIndex = 4;
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(65, 60);
            this.textBox53.MaxLength = 1;
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(30, 21);
            this.textBox53.TabIndex = 3;
            this.textBox53.Text = "活动";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(386, 43);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(29, 12);
            this.label84.TabIndex = 0;
            this.label84.Text = "大小";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(567, 23);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(53, 12);
            this.label85.TabIndex = 0;
            this.label85.Text = "纳氏囊肿";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(175, 44);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(53, 12);
            this.label86.TabIndex = 0;
            this.label86.Text = "子宫位置";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(386, 23);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(29, 12);
            this.label87.TabIndex = 0;
            this.label87.Text = "宫颈";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(30, 43);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(29, 12);
            this.label88.TabIndex = 0;
            this.label88.Text = "肥大";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(199, 23);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(29, 12);
            this.label89.TabIndex = 0;
            this.label89.Text = "阴道";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(30, 23);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(29, 12);
            this.label90.TabIndex = 0;
            this.label90.Text = "外阴";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label61);
            this.groupBox6.Controls.Add(this.label65);
            this.groupBox6.Controls.Add(this.label57);
            this.groupBox6.Controls.Add(this.label68);
            this.groupBox6.Controls.Add(this.label60);
            this.groupBox6.Controls.Add(this.label64);
            this.groupBox6.Controls.Add(this.label56);
            this.groupBox6.Controls.Add(this.label67);
            this.groupBox6.Controls.Add(this.label59);
            this.groupBox6.Controls.Add(this.label63);
            this.groupBox6.Controls.Add(this.label55);
            this.groupBox6.Controls.Add(this.label66);
            this.groupBox6.Controls.Add(this.label58);
            this.groupBox6.Controls.Add(this.label62);
            this.groupBox6.Controls.Add(this.label54);
            this.groupBox6.Controls.Add(this.comboBox52);
            this.groupBox6.Controls.Add(this.comboBox56);
            this.groupBox6.Controls.Add(this.comboBox48);
            this.groupBox6.Controls.Add(this.textBox33);
            this.groupBox6.Controls.Add(this.textBox37);
            this.groupBox6.Controls.Add(this.textBox29);
            this.groupBox6.Controls.Add(this.comboBox59);
            this.groupBox6.Controls.Add(this.comboBox51);
            this.groupBox6.Controls.Add(this.textBox32);
            this.groupBox6.Controls.Add(this.comboBox55);
            this.groupBox6.Controls.Add(this.comboBox58);
            this.groupBox6.Controls.Add(this.comboBox47);
            this.groupBox6.Controls.Add(this.comboBox50);
            this.groupBox6.Controls.Add(this.textBox36);
            this.groupBox6.Controls.Add(this.textBox39);
            this.groupBox6.Controls.Add(this.textBox28);
            this.groupBox6.Controls.Add(this.textBox31);
            this.groupBox6.Controls.Add(this.comboBox54);
            this.groupBox6.Controls.Add(this.comboBox46);
            this.groupBox6.Controls.Add(this.comboBox57);
            this.groupBox6.Controls.Add(this.textBox35);
            this.groupBox6.Controls.Add(this.comboBox49);
            this.groupBox6.Controls.Add(this.textBox27);
            this.groupBox6.Controls.Add(this.textBox38);
            this.groupBox6.Controls.Add(this.comboBox53);
            this.groupBox6.Controls.Add(this.textBox30);
            this.groupBox6.Controls.Add(this.textBox34);
            this.groupBox6.Controls.Add(this.comboBox45);
            this.groupBox6.Controls.Add(this.textBox26);
            this.groupBox6.Controls.Add(this.textBox22);
            this.groupBox6.Controls.Add(this.textBox25);
            this.groupBox6.Controls.Add(this.textBox24);
            this.groupBox6.Controls.Add(this.textBox21);
            this.groupBox6.Controls.Add(this.textBox23);
            this.groupBox6.Controls.Add(this.textBox14);
            this.groupBox6.Controls.Add(this.textBox12);
            this.groupBox6.Controls.Add(this.label53);
            this.groupBox6.Controls.Add(this.label50);
            this.groupBox6.Controls.Add(this.label52);
            this.groupBox6.Controls.Add(this.label49);
            this.groupBox6.Controls.Add(this.label51);
            this.groupBox6.Controls.Add(this.label48);
            this.groupBox6.Controls.Add(this.label47);
            this.groupBox6.Location = new System.Drawing.Point(44, 20);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(749, 149);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "体格检查";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(591, 82);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(29, 12);
            this.label61.TabIndex = 5;
            this.label61.Text = "溢乳";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(591, 102);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(29, 12);
            this.label65.TabIndex = 5;
            this.label65.Text = "脾脏";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(591, 62);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(29, 12);
            this.label57.TabIndex = 5;
            this.label57.Text = "毛发";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(386, 123);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(29, 12);
            this.label68.TabIndex = 5;
            this.label68.Text = "其他";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(386, 83);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(29, 12);
            this.label60.TabIndex = 5;
            this.label60.Text = "乳房";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(386, 103);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(29, 12);
            this.label64.TabIndex = 5;
            this.label64.Text = "肝脏";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(386, 63);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(29, 12);
            this.label56.TabIndex = 5;
            this.label56.Text = "精神";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(175, 124);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(53, 12);
            this.label67.TabIndex = 5;
            this.label67.Text = "脊柱四肢";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(187, 84);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(41, 12);
            this.label59.TabIndex = 5;
            this.label59.Text = "淋巴结";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(199, 103);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(29, 12);
            this.label63.TabIndex = 5;
            this.label63.Text = "肺脏";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(199, 63);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(29, 12);
            this.label55.TabIndex = 5;
            this.label55.Text = "发育";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(30, 123);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(29, 12);
            this.label66.TabIndex = 5;
            this.label66.Text = "肾脏";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(6, 83);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(53, 12);
            this.label58.TabIndex = 5;
            this.label58.Text = "皮肤粘膜";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(30, 103);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(29, 12);
            this.label62.TabIndex = 5;
            this.label62.Text = "心脏";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(30, 63);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(29, 12);
            this.label54.TabIndex = 5;
            this.label54.Text = "营养";
            // 
            // comboBox52
            // 
            this.comboBox52.FormattingEnabled = true;
            this.comboBox52.Location = new System.Drawing.Point(656, 80);
            this.comboBox52.Name = "comboBox52";
            this.comboBox52.Size = new System.Drawing.Size(70, 20);
            this.comboBox52.TabIndex = 4;
            // 
            // comboBox56
            // 
            this.comboBox56.FormattingEnabled = true;
            this.comboBox56.Location = new System.Drawing.Point(656, 100);
            this.comboBox56.Name = "comboBox56";
            this.comboBox56.Size = new System.Drawing.Size(70, 20);
            this.comboBox56.TabIndex = 4;
            // 
            // comboBox48
            // 
            this.comboBox48.FormattingEnabled = true;
            this.comboBox48.Location = new System.Drawing.Point(656, 60);
            this.comboBox48.Name = "comboBox48";
            this.comboBox48.Size = new System.Drawing.Size(70, 20);
            this.comboBox48.TabIndex = 4;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(626, 79);
            this.textBox33.MaxLength = 1;
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(30, 21);
            this.textBox33.TabIndex = 3;
            this.textBox33.Text = "正常";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(626, 99);
            this.textBox37.MaxLength = 1;
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(30, 21);
            this.textBox37.TabIndex = 3;
            this.textBox37.Text = "正常";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(626, 59);
            this.textBox29.MaxLength = 1;
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(30, 21);
            this.textBox29.TabIndex = 3;
            this.textBox29.Text = "正常";
            // 
            // comboBox59
            // 
            this.comboBox59.FormattingEnabled = true;
            this.comboBox59.Location = new System.Drawing.Point(421, 121);
            this.comboBox59.Name = "comboBox59";
            this.comboBox59.Size = new System.Drawing.Size(305, 20);
            this.comboBox59.TabIndex = 4;
            this.comboBox59.Text = "未见异常";
            // 
            // comboBox51
            // 
            this.comboBox51.FormattingEnabled = true;
            this.comboBox51.Location = new System.Drawing.Point(451, 81);
            this.comboBox51.Name = "comboBox51";
            this.comboBox51.Size = new System.Drawing.Size(70, 20);
            this.comboBox51.TabIndex = 4;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(421, 80);
            this.textBox32.MaxLength = 1;
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(30, 21);
            this.textBox32.TabIndex = 3;
            this.textBox32.Text = "正常";
            // 
            // comboBox55
            // 
            this.comboBox55.FormattingEnabled = true;
            this.comboBox55.Location = new System.Drawing.Point(451, 101);
            this.comboBox55.Name = "comboBox55";
            this.comboBox55.Size = new System.Drawing.Size(70, 20);
            this.comboBox55.TabIndex = 4;
            // 
            // comboBox58
            // 
            this.comboBox58.FormattingEnabled = true;
            this.comboBox58.Location = new System.Drawing.Point(264, 121);
            this.comboBox58.Name = "comboBox58";
            this.comboBox58.Size = new System.Drawing.Size(70, 20);
            this.comboBox58.TabIndex = 4;
            // 
            // comboBox47
            // 
            this.comboBox47.FormattingEnabled = true;
            this.comboBox47.Location = new System.Drawing.Point(451, 61);
            this.comboBox47.Name = "comboBox47";
            this.comboBox47.Size = new System.Drawing.Size(70, 20);
            this.comboBox47.TabIndex = 4;
            // 
            // comboBox50
            // 
            this.comboBox50.FormattingEnabled = true;
            this.comboBox50.Location = new System.Drawing.Point(264, 81);
            this.comboBox50.Name = "comboBox50";
            this.comboBox50.Size = new System.Drawing.Size(70, 20);
            this.comboBox50.TabIndex = 4;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(421, 100);
            this.textBox36.MaxLength = 1;
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(30, 21);
            this.textBox36.TabIndex = 3;
            this.textBox36.Text = "正常";
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(234, 120);
            this.textBox39.MaxLength = 1;
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(30, 21);
            this.textBox39.TabIndex = 3;
            this.textBox39.Text = "正常";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(421, 60);
            this.textBox28.MaxLength = 1;
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(30, 21);
            this.textBox28.TabIndex = 3;
            this.textBox28.Text = "正常";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(234, 80);
            this.textBox31.MaxLength = 1;
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(30, 21);
            this.textBox31.TabIndex = 3;
            this.textBox31.Text = "正常";
            // 
            // comboBox54
            // 
            this.comboBox54.FormattingEnabled = true;
            this.comboBox54.Location = new System.Drawing.Point(264, 101);
            this.comboBox54.Name = "comboBox54";
            this.comboBox54.Size = new System.Drawing.Size(70, 20);
            this.comboBox54.TabIndex = 4;
            // 
            // comboBox46
            // 
            this.comboBox46.FormattingEnabled = true;
            this.comboBox46.Location = new System.Drawing.Point(264, 61);
            this.comboBox46.Name = "comboBox46";
            this.comboBox46.Size = new System.Drawing.Size(70, 20);
            this.comboBox46.TabIndex = 4;
            // 
            // comboBox57
            // 
            this.comboBox57.FormattingEnabled = true;
            this.comboBox57.Location = new System.Drawing.Point(95, 121);
            this.comboBox57.Name = "comboBox57";
            this.comboBox57.Size = new System.Drawing.Size(70, 20);
            this.comboBox57.TabIndex = 4;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(234, 100);
            this.textBox35.MaxLength = 1;
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(30, 21);
            this.textBox35.TabIndex = 3;
            this.textBox35.Text = "正常";
            // 
            // comboBox49
            // 
            this.comboBox49.FormattingEnabled = true;
            this.comboBox49.Location = new System.Drawing.Point(95, 81);
            this.comboBox49.Name = "comboBox49";
            this.comboBox49.Size = new System.Drawing.Size(70, 20);
            this.comboBox49.TabIndex = 4;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(234, 60);
            this.textBox27.MaxLength = 1;
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(30, 21);
            this.textBox27.TabIndex = 3;
            this.textBox27.Text = "正常";
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(65, 120);
            this.textBox38.MaxLength = 1;
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(30, 21);
            this.textBox38.TabIndex = 3;
            this.textBox38.Text = "正常";
            // 
            // comboBox53
            // 
            this.comboBox53.FormattingEnabled = true;
            this.comboBox53.Location = new System.Drawing.Point(95, 101);
            this.comboBox53.Name = "comboBox53";
            this.comboBox53.Size = new System.Drawing.Size(70, 20);
            this.comboBox53.TabIndex = 4;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(65, 80);
            this.textBox30.MaxLength = 1;
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(30, 21);
            this.textBox30.TabIndex = 3;
            this.textBox30.Text = "正常";
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(65, 100);
            this.textBox34.MaxLength = 1;
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(30, 21);
            this.textBox34.TabIndex = 3;
            this.textBox34.Text = "正常";
            // 
            // comboBox45
            // 
            this.comboBox45.FormattingEnabled = true;
            this.comboBox45.Location = new System.Drawing.Point(95, 61);
            this.comboBox45.Name = "comboBox45";
            this.comboBox45.Size = new System.Drawing.Size(70, 20);
            this.comboBox45.TabIndex = 4;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(65, 60);
            this.textBox26.MaxLength = 1;
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(30, 21);
            this.textBox26.TabIndex = 3;
            this.textBox26.Text = "正常";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(626, 20);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(100, 21);
            this.textBox22.TabIndex = 1;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(421, 40);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(100, 21);
            this.textBox25.TabIndex = 1;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(234, 40);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(100, 21);
            this.textBox24.TabIndex = 1;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(421, 20);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(100, 21);
            this.textBox21.TabIndex = 1;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(65, 40);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(100, 21);
            this.textBox23.TabIndex = 1;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(234, 20);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 21);
            this.textBox14.TabIndex = 1;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(65, 20);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 21);
            this.textBox12.TabIndex = 1;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(362, 43);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(53, 12);
            this.label53.TabIndex = 0;
            this.label53.Text = "体重指数";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(603, 23);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(17, 12);
            this.label50.TabIndex = 0;
            this.label50.Text = "BP";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(175, 43);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(53, 12);
            this.label52.TabIndex = 0;
            this.label52.Text = "体重(kg)";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(404, 23);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(11, 12);
            this.label49.TabIndex = 0;
            this.label49.Text = "R";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(6, 43);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(53, 12);
            this.label51.TabIndex = 0;
            this.label51.Text = "身高(cm)";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(217, 23);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(11, 12);
            this.label48.TabIndex = 0;
            this.label48.Text = "P";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(48, 23);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(11, 12);
            this.label47.TabIndex = 0;
            this.label47.Text = "T";
            // 
            // tabPage3
            // 
            this.tabPage3.AutoScroll = true;
            this.tabPage3.AutoScrollMargin = new System.Drawing.Size(33, 33);
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(231)))), ((int)(((byte)(239)))));
            this.tabPage3.Controls.Add(this.panel2);
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(848, 422);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "   化验检查   ";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label129);
            this.panel2.Controls.Add(this.label125);
            this.panel2.Controls.Add(this.label101);
            this.panel2.Controls.Add(this.label139);
            this.panel2.Controls.Add(this.label138);
            this.panel2.Controls.Add(this.label131);
            this.panel2.Controls.Add(this.label116);
            this.panel2.Controls.Add(this.label107);
            this.panel2.Controls.Add(this.label128);
            this.panel2.Controls.Add(this.label124);
            this.panel2.Controls.Add(this.label120);
            this.panel2.Controls.Add(this.label144);
            this.panel2.Controls.Add(this.label142);
            this.panel2.Controls.Add(this.label140);
            this.panel2.Controls.Add(this.label137);
            this.panel2.Controls.Add(this.label130);
            this.panel2.Controls.Add(this.label135);
            this.panel2.Controls.Add(this.label113);
            this.panel2.Controls.Add(this.label105);
            this.panel2.Controls.Add(this.label100);
            this.panel2.Controls.Add(this.label127);
            this.panel2.Controls.Add(this.label123);
            this.panel2.Controls.Add(this.label119);
            this.panel2.Controls.Add(this.label115);
            this.panel2.Controls.Add(this.label111);
            this.panel2.Controls.Add(this.label103);
            this.panel2.Controls.Add(this.label134);
            this.panel2.Controls.Add(this.label117);
            this.panel2.Controls.Add(this.label133);
            this.panel2.Controls.Add(this.label112);
            this.panel2.Controls.Add(this.label108);
            this.panel2.Controls.Add(this.label145);
            this.panel2.Controls.Add(this.label143);
            this.panel2.Controls.Add(this.label141);
            this.panel2.Controls.Add(this.label136);
            this.panel2.Controls.Add(this.label121);
            this.panel2.Controls.Add(this.label132);
            this.panel2.Controls.Add(this.label109);
            this.panel2.Controls.Add(this.label104);
            this.panel2.Controls.Add(this.label99);
            this.panel2.Controls.Add(this.label126);
            this.panel2.Controls.Add(this.label122);
            this.panel2.Controls.Add(this.label118);
            this.panel2.Controls.Add(this.label114);
            this.panel2.Controls.Add(this.label110);
            this.panel2.Controls.Add(this.label106);
            this.panel2.Controls.Add(this.label102);
            this.panel2.Controls.Add(this.label98);
            this.panel2.Controls.Add(this.comboBox130);
            this.panel2.Controls.Add(this.comboBox129);
            this.panel2.Controls.Add(this.comboBox122);
            this.panel2.Controls.Add(this.comboBox107);
            this.panel2.Controls.Add(this.comboBox98);
            this.panel2.Controls.Add(this.comboBox120);
            this.panel2.Controls.Add(this.comboBox119);
            this.panel2.Controls.Add(this.comboBox135);
            this.panel2.Controls.Add(this.comboBox133);
            this.panel2.Controls.Add(this.comboBox131);
            this.panel2.Controls.Add(this.comboBox128);
            this.panel2.Controls.Add(this.comboBox116);
            this.panel2.Controls.Add(this.comboBox121);
            this.panel2.Controls.Add(this.comboBox126);
            this.panel2.Controls.Add(this.comboBox104);
            this.panel2.Controls.Add(this.comboBox115);
            this.panel2.Controls.Add(this.comboBox96);
            this.panel2.Controls.Add(this.comboBox111);
            this.panel2.Controls.Add(this.comboBox118);
            this.panel2.Controls.Add(this.comboBox125);
            this.panel2.Controls.Add(this.comboBox114);
            this.panel2.Controls.Add(this.comboBox136);
            this.panel2.Controls.Add(this.comboBox134);
            this.panel2.Controls.Add(this.comboBox124);
            this.panel2.Controls.Add(this.comboBox132);
            this.panel2.Controls.Add(this.comboBox108);
            this.panel2.Controls.Add(this.comboBox127);
            this.panel2.Controls.Add(this.comboBox103);
            this.panel2.Controls.Add(this.comboBox112);
            this.panel2.Controls.Add(this.comboBox123);
            this.panel2.Controls.Add(this.comboBox110);
            this.panel2.Controls.Add(this.comboBox100);
            this.panel2.Controls.Add(this.comboBox99);
            this.panel2.Controls.Add(this.comboBox95);
            this.panel2.Controls.Add(this.comboBox106);
            this.panel2.Controls.Add(this.comboBox117);
            this.panel2.Controls.Add(this.comboBox102);
            this.panel2.Controls.Add(this.comboBox113);
            this.panel2.Controls.Add(this.comboBox109);
            this.panel2.Controls.Add(this.comboBox105);
            this.panel2.Controls.Add(this.comboBox92);
            this.panel2.Controls.Add(this.comboBox101);
            this.panel2.Controls.Add(this.comboBox94);
            this.panel2.Controls.Add(this.comboBox97);
            this.panel2.Controls.Add(this.comboBox91);
            this.panel2.Controls.Add(this.comboBox93);
            this.panel2.Controls.Add(this.comboBox90);
            this.panel2.Controls.Add(this.comboBox89);
            this.panel2.Location = new System.Drawing.Point(45, 19);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(749, 565);
            this.panel2.TabIndex = 0;
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Location = new System.Drawing.Point(85, 200);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(35, 12);
            this.label129.TabIndex = 7;
            this.label129.Text = "CA125";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(576, 175);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(65, 12);
            this.label125.TabIndex = 7;
            this.label125.Text = "AMH(ng/ml)";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(600, 25);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(41, 12);
            this.label101.TabIndex = 7;
            this.label101.Text = "血小板";
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Location = new System.Drawing.Point(600, 425);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(41, 12);
            this.label139.TabIndex = 7;
            this.label139.Text = "AHCGAb";
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Location = new System.Drawing.Point(477, 425);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(23, 12);
            this.label138.TabIndex = 7;
            this.label138.Text = "AcA";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Location = new System.Drawing.Point(426, 347);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(53, 12);
            this.label131.TabIndex = 7;
            this.label131.Text = "梅毒抗体";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(444, 300);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(35, 12);
            this.label116.TabIndex = 7;
            this.label116.Text = "HBeAg";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(414, 254);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(65, 12);
            this.label107.TabIndex = 7;
            this.label107.Text = "巨细胞病毒";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(456, 227);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(23, 12);
            this.label128.TabIndex = 7;
            this.label128.Text = "FT4";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(456, 175);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(23, 12);
            this.label124.TabIndex = 7;
            this.label124.Text = "PRL";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(462, 155);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(17, 12);
            this.label120.TabIndex = 7;
            this.label120.Text = "E2";
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Location = new System.Drawing.Point(480, 477);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(23, 12);
            this.label144.TabIndex = 7;
            this.label144.Text = "TCT";
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Location = new System.Drawing.Point(258, 451);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(41, 12);
            this.label142.TabIndex = 7;
            this.label142.Text = "阴道镜";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Location = new System.Drawing.Point(210, 425);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(29, 12);
            this.label140.TabIndex = 7;
            this.label140.Text = "EmAb";
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Location = new System.Drawing.Point(350, 425);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(29, 12);
            this.label137.TabIndex = 7;
            this.label137.Text = "AoAb";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Location = new System.Drawing.Point(264, 347);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(35, 12);
            this.label130.TabIndex = 7;
            this.label130.Text = "HIVAb";
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Location = new System.Drawing.Point(276, 373);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(23, 12);
            this.label135.TabIndex = 7;
            this.label135.Text = "AST";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(264, 300);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(35, 12);
            this.label113.TabIndex = 7;
            this.label113.Text = "HBsAb";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(246, 253);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(53, 12);
            this.label105.TabIndex = 7;
            this.label105.Text = "风疹病毒";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(414, 25);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(65, 12);
            this.label100.TabIndex = 7;
            this.label100.Text = "血细胞容积";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(276, 227);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(23, 12);
            this.label127.TabIndex = 7;
            this.label127.Text = "FT3";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(288, 175);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(11, 12);
            this.label123.TabIndex = 7;
            this.label123.Text = "T";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(282, 155);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(17, 12);
            this.label119.TabIndex = 7;
            this.label119.Text = "LH";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(270, 128);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(29, 12);
            this.label115.TabIndex = 7;
            this.label115.Text = "APTT";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(258, 103);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(41, 12);
            this.label111.TabIndex = 7;
            this.label111.Text = "Rh因子";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(270, 50);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(29, 12);
            this.label103.TabIndex = 7;
            this.label103.Text = "血沉";
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Location = new System.Drawing.Point(246, 393);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(53, 12);
            this.label134.TabIndex = 7;
            this.label134.Text = "血尿素氮";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(264, 320);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(35, 12);
            this.label117.TabIndex = 7;
            this.label117.Text = "HBcAb";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(43, 393);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(77, 12);
            this.label133.TabIndex = 7;
            this.label133.Text = "肾功：血肌酐";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(85, 320);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(35, 12);
            this.label112.TabIndex = 7;
            this.label112.Text = "HBeAb";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(43, 273);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(77, 12);
            this.label108.TabIndex = 7;
            this.label108.Text = "单纯疱疹Ⅱ型";
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.Location = new System.Drawing.Point(79, 504);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(41, 12);
            this.label145.TabIndex = 7;
            this.label145.Text = "衣原体";
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Location = new System.Drawing.Point(79, 477);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(41, 12);
            this.label143.TabIndex = 7;
            this.label143.Text = "染色体";
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Location = new System.Drawing.Point(91, 451);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(23, 12);
            this.label141.TabIndex = 7;
            this.label141.Text = "HPV";
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Location = new System.Drawing.Point(31, 425);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(89, 12);
            this.label136.TabIndex = 7;
            this.label136.Text = "生殖免疫：AsAb";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(13, 348);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(107, 12);
            this.label121.TabIndex = 7;
            this.label121.Text = "传染病三项：HCVAb";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Location = new System.Drawing.Point(61, 373);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(59, 12);
            this.label132.TabIndex = 7;
            this.label132.Text = "肝功：ALT";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(49, 300);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(71, 12);
            this.label109.TabIndex = 7;
            this.label109.Text = "乙肝：HBsAg";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(37, 254);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(83, 12);
            this.label104.TabIndex = 7;
            this.label104.Text = "TORCH：弓形虫";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(234, 25);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(65, 12);
            this.label99.TabIndex = 7;
            this.label99.Text = "红细胞计数";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(61, 227);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(59, 12);
            this.label126.TabIndex = 7;
            this.label126.Text = "甲功：TSH";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(109, 175);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(11, 12);
            this.label122.TabIndex = 7;
            this.label122.Text = "P";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(19, 156);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(95, 12);
            this.label118.TabIndex = 7;
            this.label118.Text = "基础内分泌：FSH";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(43, 129);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(77, 12);
            this.label114.TabIndex = 7;
            this.label114.Text = "凝血功能：PT";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(49, 103);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(71, 12);
            this.label110.TabIndex = 7;
            this.label110.Text = "血型：ABO型";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(79, 77);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(41, 12);
            this.label106.TabIndex = 7;
            this.label106.Text = "尿常规";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(55, 51);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(65, 12);
            this.label102.TabIndex = 7;
            this.label102.Text = "白细胞计数";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(19, 26);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(101, 12);
            this.label98.TabIndex = 7;
            this.label98.Text = "血常规：血红蛋白";
            // 
            // comboBox130
            // 
            this.comboBox130.FormattingEnabled = true;
            this.comboBox130.Location = new System.Drawing.Point(647, 422);
            this.comboBox130.Name = "comboBox130";
            this.comboBox130.Size = new System.Drawing.Size(88, 20);
            this.comboBox130.TabIndex = 6;
            this.comboBox130.Text = "阴性";
            // 
            // comboBox129
            // 
            this.comboBox129.FormattingEnabled = true;
            this.comboBox129.Location = new System.Drawing.Point(506, 422);
            this.comboBox129.Name = "comboBox129";
            this.comboBox129.Size = new System.Drawing.Size(88, 20);
            this.comboBox129.TabIndex = 6;
            this.comboBox129.Text = "阴性";
            // 
            // comboBox122
            // 
            this.comboBox122.FormattingEnabled = true;
            this.comboBox122.Location = new System.Drawing.Point(482, 344);
            this.comboBox122.Name = "comboBox122";
            this.comboBox122.Size = new System.Drawing.Size(88, 20);
            this.comboBox122.TabIndex = 6;
            this.comboBox122.Text = "阴性";
            // 
            // comboBox107
            // 
            this.comboBox107.FormattingEnabled = true;
            this.comboBox107.Location = new System.Drawing.Point(482, 297);
            this.comboBox107.Name = "comboBox107";
            this.comboBox107.Size = new System.Drawing.Size(88, 20);
            this.comboBox107.TabIndex = 6;
            this.comboBox107.Text = "阴性";
            // 
            // comboBox98
            // 
            this.comboBox98.FormattingEnabled = true;
            this.comboBox98.Location = new System.Drawing.Point(482, 250);
            this.comboBox98.Name = "comboBox98";
            this.comboBox98.Size = new System.Drawing.Size(88, 20);
            this.comboBox98.TabIndex = 6;
            this.comboBox98.Text = "阴性";
            // 
            // comboBox120
            // 
            this.comboBox120.FormattingEnabled = true;
            this.comboBox120.Location = new System.Drawing.Point(120, 197);
            this.comboBox120.Name = "comboBox120";
            this.comboBox120.Size = new System.Drawing.Size(88, 20);
            this.comboBox120.TabIndex = 6;
            // 
            // comboBox119
            // 
            this.comboBox119.FormattingEnabled = true;
            this.comboBox119.Location = new System.Drawing.Point(482, 223);
            this.comboBox119.Name = "comboBox119";
            this.comboBox119.Size = new System.Drawing.Size(88, 20);
            this.comboBox119.TabIndex = 6;
            // 
            // comboBox135
            // 
            this.comboBox135.FormattingEnabled = true;
            this.comboBox135.Location = new System.Drawing.Point(506, 474);
            this.comboBox135.Name = "comboBox135";
            this.comboBox135.Size = new System.Drawing.Size(229, 20);
            this.comboBox135.TabIndex = 6;
            // 
            // comboBox133
            // 
            this.comboBox133.FormattingEnabled = true;
            this.comboBox133.Location = new System.Drawing.Point(302, 448);
            this.comboBox133.Name = "comboBox133";
            this.comboBox133.Size = new System.Drawing.Size(433, 20);
            this.comboBox133.TabIndex = 6;
            // 
            // comboBox131
            // 
            this.comboBox131.FormattingEnabled = true;
            this.comboBox131.Location = new System.Drawing.Point(245, 422);
            this.comboBox131.Name = "comboBox131";
            this.comboBox131.Size = new System.Drawing.Size(88, 20);
            this.comboBox131.TabIndex = 6;
            this.comboBox131.Text = "阴性";
            // 
            // comboBox128
            // 
            this.comboBox128.FormattingEnabled = true;
            this.comboBox128.Location = new System.Drawing.Point(383, 422);
            this.comboBox128.Name = "comboBox128";
            this.comboBox128.Size = new System.Drawing.Size(88, 20);
            this.comboBox128.TabIndex = 6;
            this.comboBox128.Text = "阴性";
            // 
            // comboBox116
            // 
            this.comboBox116.FormattingEnabled = true;
            this.comboBox116.Location = new System.Drawing.Point(647, 171);
            this.comboBox116.Name = "comboBox116";
            this.comboBox116.Size = new System.Drawing.Size(88, 20);
            this.comboBox116.TabIndex = 6;
            // 
            // comboBox121
            // 
            this.comboBox121.FormattingEnabled = true;
            this.comboBox121.Location = new System.Drawing.Point(302, 344);
            this.comboBox121.Name = "comboBox121";
            this.comboBox121.Size = new System.Drawing.Size(88, 20);
            this.comboBox121.TabIndex = 6;
            this.comboBox121.Text = "阴性";
            // 
            // comboBox126
            // 
            this.comboBox126.FormattingEnabled = true;
            this.comboBox126.Location = new System.Drawing.Point(302, 370);
            this.comboBox126.Name = "comboBox126";
            this.comboBox126.Size = new System.Drawing.Size(88, 20);
            this.comboBox126.TabIndex = 6;
            // 
            // comboBox104
            // 
            this.comboBox104.FormattingEnabled = true;
            this.comboBox104.Location = new System.Drawing.Point(302, 297);
            this.comboBox104.Name = "comboBox104";
            this.comboBox104.Size = new System.Drawing.Size(88, 20);
            this.comboBox104.TabIndex = 6;
            this.comboBox104.Text = "阴性";
            // 
            // comboBox115
            // 
            this.comboBox115.FormattingEnabled = true;
            this.comboBox115.Location = new System.Drawing.Point(482, 171);
            this.comboBox115.Name = "comboBox115";
            this.comboBox115.Size = new System.Drawing.Size(88, 20);
            this.comboBox115.TabIndex = 6;
            // 
            // comboBox96
            // 
            this.comboBox96.FormattingEnabled = true;
            this.comboBox96.Location = new System.Drawing.Point(302, 250);
            this.comboBox96.Name = "comboBox96";
            this.comboBox96.Size = new System.Drawing.Size(88, 20);
            this.comboBox96.TabIndex = 6;
            this.comboBox96.Text = "阴性";
            // 
            // comboBox111
            // 
            this.comboBox111.FormattingEnabled = true;
            this.comboBox111.Location = new System.Drawing.Point(482, 151);
            this.comboBox111.Name = "comboBox111";
            this.comboBox111.Size = new System.Drawing.Size(88, 20);
            this.comboBox111.TabIndex = 6;
            // 
            // comboBox118
            // 
            this.comboBox118.FormattingEnabled = true;
            this.comboBox118.Location = new System.Drawing.Point(302, 223);
            this.comboBox118.Name = "comboBox118";
            this.comboBox118.Size = new System.Drawing.Size(88, 20);
            this.comboBox118.TabIndex = 6;
            // 
            // comboBox125
            // 
            this.comboBox125.FormattingEnabled = true;
            this.comboBox125.Location = new System.Drawing.Point(302, 390);
            this.comboBox125.Name = "comboBox125";
            this.comboBox125.Size = new System.Drawing.Size(88, 20);
            this.comboBox125.TabIndex = 6;
            // 
            // comboBox114
            // 
            this.comboBox114.FormattingEnabled = true;
            this.comboBox114.Location = new System.Drawing.Point(302, 171);
            this.comboBox114.Name = "comboBox114";
            this.comboBox114.Size = new System.Drawing.Size(88, 20);
            this.comboBox114.TabIndex = 6;
            // 
            // comboBox136
            // 
            this.comboBox136.FormattingEnabled = true;
            this.comboBox136.Location = new System.Drawing.Point(120, 500);
            this.comboBox136.Name = "comboBox136";
            this.comboBox136.Size = new System.Drawing.Size(88, 20);
            this.comboBox136.TabIndex = 6;
            this.comboBox136.Text = "阴性";
            // 
            // comboBox134
            // 
            this.comboBox134.FormattingEnabled = true;
            this.comboBox134.Location = new System.Drawing.Point(120, 474);
            this.comboBox134.Name = "comboBox134";
            this.comboBox134.Size = new System.Drawing.Size(270, 20);
            this.comboBox134.TabIndex = 6;
            // 
            // comboBox124
            // 
            this.comboBox124.FormattingEnabled = true;
            this.comboBox124.Location = new System.Drawing.Point(120, 390);
            this.comboBox124.Name = "comboBox124";
            this.comboBox124.Size = new System.Drawing.Size(88, 20);
            this.comboBox124.TabIndex = 6;
            // 
            // comboBox132
            // 
            this.comboBox132.FormattingEnabled = true;
            this.comboBox132.Location = new System.Drawing.Point(120, 448);
            this.comboBox132.Name = "comboBox132";
            this.comboBox132.Size = new System.Drawing.Size(88, 20);
            this.comboBox132.TabIndex = 6;
            // 
            // comboBox108
            // 
            this.comboBox108.FormattingEnabled = true;
            this.comboBox108.Location = new System.Drawing.Point(302, 317);
            this.comboBox108.Name = "comboBox108";
            this.comboBox108.Size = new System.Drawing.Size(88, 20);
            this.comboBox108.TabIndex = 6;
            this.comboBox108.Text = "阴性";
            // 
            // comboBox127
            // 
            this.comboBox127.FormattingEnabled = true;
            this.comboBox127.Location = new System.Drawing.Point(120, 422);
            this.comboBox127.Name = "comboBox127";
            this.comboBox127.Size = new System.Drawing.Size(88, 20);
            this.comboBox127.TabIndex = 6;
            this.comboBox127.Text = "阴性";
            // 
            // comboBox103
            // 
            this.comboBox103.FormattingEnabled = true;
            this.comboBox103.Location = new System.Drawing.Point(120, 317);
            this.comboBox103.Name = "comboBox103";
            this.comboBox103.Size = new System.Drawing.Size(88, 20);
            this.comboBox103.TabIndex = 6;
            this.comboBox103.Text = "阴性";
            // 
            // comboBox112
            // 
            this.comboBox112.FormattingEnabled = true;
            this.comboBox112.Location = new System.Drawing.Point(120, 344);
            this.comboBox112.Name = "comboBox112";
            this.comboBox112.Size = new System.Drawing.Size(88, 20);
            this.comboBox112.TabIndex = 6;
            this.comboBox112.Text = "阴性";
            // 
            // comboBox123
            // 
            this.comboBox123.FormattingEnabled = true;
            this.comboBox123.Location = new System.Drawing.Point(120, 370);
            this.comboBox123.Name = "comboBox123";
            this.comboBox123.Size = new System.Drawing.Size(88, 20);
            this.comboBox123.TabIndex = 6;
            // 
            // comboBox110
            // 
            this.comboBox110.FormattingEnabled = true;
            this.comboBox110.Location = new System.Drawing.Point(302, 151);
            this.comboBox110.Name = "comboBox110";
            this.comboBox110.Size = new System.Drawing.Size(88, 20);
            this.comboBox110.TabIndex = 6;
            // 
            // comboBox100
            // 
            this.comboBox100.FormattingEnabled = true;
            this.comboBox100.Location = new System.Drawing.Point(120, 297);
            this.comboBox100.Name = "comboBox100";
            this.comboBox100.Size = new System.Drawing.Size(88, 20);
            this.comboBox100.TabIndex = 6;
            this.comboBox100.Text = "阴性";
            // 
            // comboBox99
            // 
            this.comboBox99.FormattingEnabled = true;
            this.comboBox99.Location = new System.Drawing.Point(120, 270);
            this.comboBox99.Name = "comboBox99";
            this.comboBox99.Size = new System.Drawing.Size(88, 20);
            this.comboBox99.TabIndex = 6;
            this.comboBox99.Text = "阴性";
            // 
            // comboBox95
            // 
            this.comboBox95.FormattingEnabled = true;
            this.comboBox95.Location = new System.Drawing.Point(120, 250);
            this.comboBox95.Name = "comboBox95";
            this.comboBox95.Size = new System.Drawing.Size(88, 20);
            this.comboBox95.TabIndex = 6;
            this.comboBox95.Text = "阴性";
            // 
            // comboBox106
            // 
            this.comboBox106.FormattingEnabled = true;
            this.comboBox106.Location = new System.Drawing.Point(302, 125);
            this.comboBox106.Name = "comboBox106";
            this.comboBox106.Size = new System.Drawing.Size(88, 20);
            this.comboBox106.TabIndex = 6;
            // 
            // comboBox117
            // 
            this.comboBox117.FormattingEnabled = true;
            this.comboBox117.Location = new System.Drawing.Point(120, 223);
            this.comboBox117.Name = "comboBox117";
            this.comboBox117.Size = new System.Drawing.Size(88, 20);
            this.comboBox117.TabIndex = 6;
            // 
            // comboBox102
            // 
            this.comboBox102.FormattingEnabled = true;
            this.comboBox102.Location = new System.Drawing.Point(302, 99);
            this.comboBox102.Name = "comboBox102";
            this.comboBox102.Size = new System.Drawing.Size(88, 20);
            this.comboBox102.TabIndex = 6;
            this.comboBox102.Text = "阳性";
            // 
            // comboBox113
            // 
            this.comboBox113.FormattingEnabled = true;
            this.comboBox113.Location = new System.Drawing.Point(120, 171);
            this.comboBox113.Name = "comboBox113";
            this.comboBox113.Size = new System.Drawing.Size(88, 20);
            this.comboBox113.TabIndex = 6;
            // 
            // comboBox109
            // 
            this.comboBox109.FormattingEnabled = true;
            this.comboBox109.Location = new System.Drawing.Point(120, 151);
            this.comboBox109.Name = "comboBox109";
            this.comboBox109.Size = new System.Drawing.Size(88, 20);
            this.comboBox109.TabIndex = 6;
            // 
            // comboBox105
            // 
            this.comboBox105.FormattingEnabled = true;
            this.comboBox105.Location = new System.Drawing.Point(120, 125);
            this.comboBox105.Name = "comboBox105";
            this.comboBox105.Size = new System.Drawing.Size(88, 20);
            this.comboBox105.TabIndex = 6;
            // 
            // comboBox92
            // 
            this.comboBox92.FormattingEnabled = true;
            this.comboBox92.Location = new System.Drawing.Point(647, 21);
            this.comboBox92.Name = "comboBox92";
            this.comboBox92.Size = new System.Drawing.Size(88, 20);
            this.comboBox92.TabIndex = 6;
            // 
            // comboBox101
            // 
            this.comboBox101.FormattingEnabled = true;
            this.comboBox101.Location = new System.Drawing.Point(120, 99);
            this.comboBox101.Name = "comboBox101";
            this.comboBox101.Size = new System.Drawing.Size(88, 20);
            this.comboBox101.TabIndex = 6;
            // 
            // comboBox94
            // 
            this.comboBox94.FormattingEnabled = true;
            this.comboBox94.Location = new System.Drawing.Point(302, 47);
            this.comboBox94.Name = "comboBox94";
            this.comboBox94.Size = new System.Drawing.Size(88, 20);
            this.comboBox94.TabIndex = 6;
            // 
            // comboBox97
            // 
            this.comboBox97.FormattingEnabled = true;
            this.comboBox97.Location = new System.Drawing.Point(120, 73);
            this.comboBox97.Name = "comboBox97";
            this.comboBox97.Size = new System.Drawing.Size(615, 20);
            this.comboBox97.TabIndex = 6;
            this.comboBox97.Text = "正常";
            // 
            // comboBox91
            // 
            this.comboBox91.FormattingEnabled = true;
            this.comboBox91.Location = new System.Drawing.Point(482, 21);
            this.comboBox91.Name = "comboBox91";
            this.comboBox91.Size = new System.Drawing.Size(88, 20);
            this.comboBox91.TabIndex = 6;
            // 
            // comboBox93
            // 
            this.comboBox93.FormattingEnabled = true;
            this.comboBox93.Location = new System.Drawing.Point(120, 47);
            this.comboBox93.Name = "comboBox93";
            this.comboBox93.Size = new System.Drawing.Size(88, 20);
            this.comboBox93.TabIndex = 6;
            // 
            // comboBox90
            // 
            this.comboBox90.FormattingEnabled = true;
            this.comboBox90.Location = new System.Drawing.Point(302, 21);
            this.comboBox90.Name = "comboBox90";
            this.comboBox90.Size = new System.Drawing.Size(88, 20);
            this.comboBox90.TabIndex = 6;
            // 
            // comboBox89
            // 
            this.comboBox89.FormattingEnabled = true;
            this.comboBox89.Location = new System.Drawing.Point(120, 21);
            this.comboBox89.Name = "comboBox89";
            this.comboBox89.Size = new System.Drawing.Size(88, 20);
            this.comboBox89.TabIndex = 6;
            // 
            // tabPage4
            // 
            this.tabPage4.AutoScroll = true;
            this.tabPage4.AutoScrollMargin = new System.Drawing.Size(33, 33);
            this.tabPage4.AutoScrollMinSize = new System.Drawing.Size(33, 33);
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(231)))), ((int)(((byte)(239)))));
            this.tabPage4.Controls.Add(this.comboBox141);
            this.tabPage4.Controls.Add(this.comboBox140);
            this.tabPage4.Controls.Add(this.label153);
            this.tabPage4.Controls.Add(this.textBox41);
            this.tabPage4.Controls.Add(this.label152);
            this.tabPage4.Controls.Add(this.label151);
            this.tabPage4.Controls.Add(this.textBox40);
            this.tabPage4.Controls.Add(this.label149);
            this.tabPage4.Controls.Add(this.groupBox9);
            this.tabPage4.Controls.Add(this.panel3);
            this.tabPage4.Controls.Add(this.label147);
            this.tabPage4.Controls.Add(this.label148);
            this.tabPage4.Controls.Add(this.label146);
            this.tabPage4.Controls.Add(this.comboBox138);
            this.tabPage4.Controls.Add(this.comboBox139);
            this.tabPage4.Controls.Add(this.comboBox137);
            this.tabPage4.Location = new System.Drawing.Point(4, 24);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(848, 422);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "   诊断与方案   ";
            // 
            // comboBox141
            // 
            this.comboBox141.FormattingEnabled = true;
            this.comboBox141.Location = new System.Drawing.Point(651, 553);
            this.comboBox141.Name = "comboBox141";
            this.comboBox141.Size = new System.Drawing.Size(78, 20);
            this.comboBox141.TabIndex = 14;
            // 
            // comboBox140
            // 
            this.comboBox140.FormattingEnabled = true;
            this.comboBox140.Location = new System.Drawing.Point(101, 528);
            this.comboBox140.Name = "comboBox140";
            this.comboBox140.Size = new System.Drawing.Size(629, 20);
            this.comboBox140.TabIndex = 14;
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.Location = new System.Drawing.Point(604, 556);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(41, 12);
            this.label153.TabIndex = 12;
            this.label153.Text = "录入者";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(101, 429);
            this.textBox41.Multiline = true;
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(629, 94);
            this.textBox41.TabIndex = 13;
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.Location = new System.Drawing.Point(18, 531);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(77, 12);
            this.label152.TabIndex = 12;
            this.label152.Text = "拟行用药方案";
            // 
            // label151
            // 
            this.label151.AutoSize = true;
            this.label151.Location = new System.Drawing.Point(41, 435);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(53, 12);
            this.label151.TabIndex = 12;
            this.label151.Text = "诊疗计划";
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(101, 329);
            this.textBox40.Multiline = true;
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(629, 94);
            this.textBox40.TabIndex = 13;
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.Location = new System.Drawing.Point(66, 332);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(29, 12);
            this.label149.TabIndex = 12;
            this.label149.Text = "诊断";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.radioButton8);
            this.groupBox9.Controls.Add(this.radioButton6);
            this.groupBox9.Controls.Add(this.radioButton12);
            this.groupBox9.Controls.Add(this.radioButton11);
            this.groupBox9.Controls.Add(this.radioButton5);
            this.groupBox9.Controls.Add(this.radioButton10);
            this.groupBox9.Controls.Add(this.radioButton4);
            this.groupBox9.Controls.Add(this.radioButton3);
            this.groupBox9.Controls.Add(this.radioButton9);
            this.groupBox9.Controls.Add(this.radioButton7);
            this.groupBox9.Controls.Add(this.radioButton2);
            this.groupBox9.Controls.Add(this.radioButton1);
            this.groupBox9.Location = new System.Drawing.Point(100, 257);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(630, 63);
            this.groupBox9.TabIndex = 11;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "拟行助孕方案";
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(1, 42);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(41, 16);
            this.radioButton8.TabIndex = 0;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "IVF";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(281, 20);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(35, 16);
            this.radioButton6.TabIndex = 0;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "DS";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(234, 42);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(35, 16);
            this.radioButton12.TabIndex = 0;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "DO";
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(178, 42);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(41, 16);
            this.radioButton11.TabIndex = 0;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "PGD";
            this.radioButton11.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(234, 20);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(41, 16);
            this.radioButton5.TabIndex = 0;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "FET";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(109, 42);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(71, 16);
            this.radioButton10.TabIndex = 0;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "IVF+ICSI";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(178, 20);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(41, 16);
            this.radioButton4.TabIndex = 0;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "AIH";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(109, 20);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(53, 16);
            this.radioButton3.TabIndex = 0;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "RICSI";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(57, 42);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(47, 16);
            this.radioButton9.TabIndex = 0;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "ICSI";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(-269, 42);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(47, 16);
            this.radioButton7.TabIndex = 0;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "PESA";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(57, 20);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(47, 16);
            this.radioButton2.TabIndex = 0;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "TESA";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(1, 20);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(47, 16);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "PESA";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Control;
            this.panel3.Controls.Add(this.checkBox26);
            this.panel3.Controls.Add(this.checkBox16);
            this.panel3.Controls.Add(this.checkBox8);
            this.panel3.Controls.Add(this.checkBox25);
            this.panel3.Controls.Add(this.checkBox18);
            this.panel3.Controls.Add(this.checkBox7);
            this.panel3.Controls.Add(this.checkBox24);
            this.panel3.Controls.Add(this.checkBox15);
            this.panel3.Controls.Add(this.checkBox23);
            this.panel3.Controls.Add(this.checkBox6);
            this.panel3.Controls.Add(this.checkBox14);
            this.panel3.Controls.Add(this.checkBox22);
            this.panel3.Controls.Add(this.checkBox5);
            this.panel3.Controls.Add(this.checkBox13);
            this.panel3.Controls.Add(this.checkBox30);
            this.panel3.Controls.Add(this.checkBox21);
            this.panel3.Controls.Add(this.checkBox4);
            this.panel3.Controls.Add(this.checkBox12);
            this.panel3.Controls.Add(this.checkBox29);
            this.panel3.Controls.Add(this.checkBox20);
            this.panel3.Controls.Add(this.checkBox28);
            this.panel3.Controls.Add(this.checkBox3);
            this.panel3.Controls.Add(this.checkBox19);
            this.panel3.Controls.Add(this.checkBox11);
            this.panel3.Controls.Add(this.checkBox10);
            this.panel3.Controls.Add(this.checkBox2);
            this.panel3.Controls.Add(this.checkBox1);
            this.panel3.Location = new System.Drawing.Point(100, 75);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(630, 176);
            this.panel3.TabIndex = 10;
            // 
            // checkBox26
            // 
            this.checkBox26.AutoSize = true;
            this.checkBox26.Location = new System.Drawing.Point(349, 158);
            this.checkBox26.Name = "checkBox26";
            this.checkBox26.Size = new System.Drawing.Size(84, 16);
            this.checkBox26.TabIndex = 0;
            this.checkBox26.Text = "男方死精症";
            this.checkBox26.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Location = new System.Drawing.Point(169, 158);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(84, 16);
            this.checkBox16.TabIndex = 0;
            this.checkBox16.Text = "男方弱精症";
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.checkBox8.Location = new System.Drawing.Point(0, 158);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(102, 17);
            this.checkBox8.TabIndex = 0;
            this.checkBox8.Text = "女方免疫因素";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Location = new System.Drawing.Point(349, 136);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(120, 16);
            this.checkBox25.TabIndex = 0;
            this.checkBox25.Text = "男方严重少弱精症";
            this.checkBox25.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Location = new System.Drawing.Point(169, 136);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(84, 16);
            this.checkBox18.TabIndex = 0;
            this.checkBox18.Text = "男方无精症";
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(0, 136);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(96, 16);
            this.checkBox7.TabIndex = 0;
            this.checkBox7.Text = "女方排卵障碍";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Location = new System.Drawing.Point(349, 114);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(108, 16);
            this.checkBox24.TabIndex = 0;
            this.checkBox24.Text = "男方少弱畸精症";
            this.checkBox24.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Location = new System.Drawing.Point(169, 114);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(84, 16);
            this.checkBox15.TabIndex = 0;
            this.checkBox15.Text = "3次AIH失败";
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Location = new System.Drawing.Point(349, 92);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(96, 16);
            this.checkBox23.TabIndex = 0;
            this.checkBox23.Text = "男方弱畸精症";
            this.checkBox23.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(0, 114);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(96, 16);
            this.checkBox6.TabIndex = 0;
            this.checkBox6.Text = "女方心理因素";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Location = new System.Drawing.Point(169, 92);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(120, 16);
            this.checkBox14.TabIndex = 0;
            this.checkBox14.Text = "女方卵巢储备下降";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Location = new System.Drawing.Point(349, 70);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(96, 16);
            this.checkBox22.TabIndex = 0;
            this.checkBox22.Text = "男方少畸精症";
            this.checkBox22.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(0, 92);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(96, 16);
            this.checkBox5.TabIndex = 0;
            this.checkBox5.Text = "女方宫颈因素";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(169, 70);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(72, 16);
            this.checkBox13.TabIndex = 0;
            this.checkBox13.Text = "女方高龄";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox30
            // 
            this.checkBox30.AutoSize = true;
            this.checkBox30.Location = new System.Drawing.Point(491, 48);
            this.checkBox30.Name = "checkBox30";
            this.checkBox30.Size = new System.Drawing.Size(96, 16);
            this.checkBox30.TabIndex = 0;
            this.checkBox30.Text = "男方原因不明";
            this.checkBox30.UseVisualStyleBackColor = true;
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Location = new System.Drawing.Point(349, 48);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(96, 16);
            this.checkBox21.TabIndex = 0;
            this.checkBox21.Text = "男方少弱精症";
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(0, 70);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(108, 16);
            this.checkBox4.TabIndex = 0;
            this.checkBox4.Text = "女方生殖道畸形";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(169, 48);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(96, 16);
            this.checkBox12.TabIndex = 0;
            this.checkBox12.Text = "女方原因不明";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox29
            // 
            this.checkBox29.AutoSize = true;
            this.checkBox29.Location = new System.Drawing.Point(491, 26);
            this.checkBox29.Name = "checkBox29";
            this.checkBox29.Size = new System.Drawing.Size(108, 16);
            this.checkBox29.TabIndex = 0;
            this.checkBox29.Text = "男方染色体异常";
            this.checkBox29.UseVisualStyleBackColor = true;
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Location = new System.Drawing.Point(349, 26);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(84, 16);
            this.checkBox20.TabIndex = 0;
            this.checkBox20.Text = "男方畸精症";
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // checkBox28
            // 
            this.checkBox28.AutoSize = true;
            this.checkBox28.Location = new System.Drawing.Point(491, 4);
            this.checkBox28.Name = "checkBox28";
            this.checkBox28.Size = new System.Drawing.Size(96, 16);
            this.checkBox28.TabIndex = 0;
            this.checkBox28.Text = "男方排精障碍";
            this.checkBox28.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(0, 48);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(156, 16);
            this.checkBox3.TabIndex = 0;
            this.checkBox3.Text = "女方子宫内膜异位经盆腔";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Location = new System.Drawing.Point(349, 4);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(84, 16);
            this.checkBox19.TabIndex = 0;
            this.checkBox19.Text = "男方少精症";
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(169, 26);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(96, 16);
            this.checkBox11.TabIndex = 0;
            this.checkBox11.Text = "女方其他因素";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(169, 4);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(108, 16);
            this.checkBox10.TabIndex = 0;
            this.checkBox10.Text = "女方染色体异常";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(0, 25);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(132, 16);
            this.checkBox2.TabIndex = 0;
            this.checkBox2.Text = "女方子宫内膜异位症";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(0, 4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(144, 16);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "女方盆腔及输卵管因素";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.Location = new System.Drawing.Point(276, 26);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(53, 12);
            this.label147.TabIndex = 9;
            this.label147.Text = "不孕类型";
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.Location = new System.Drawing.Point(98, 52);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(53, 12);
            this.label148.TabIndex = 9;
            this.label148.Text = "不孕因素";
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.Location = new System.Drawing.Point(98, 26);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(53, 12);
            this.label146.TabIndex = 9;
            this.label146.Text = "不孕年限";
            // 
            // comboBox138
            // 
            this.comboBox138.FormattingEnabled = true;
            this.comboBox138.Location = new System.Drawing.Point(335, 23);
            this.comboBox138.Name = "comboBox138";
            this.comboBox138.Size = new System.Drawing.Size(221, 20);
            this.comboBox138.TabIndex = 8;
            // 
            // comboBox139
            // 
            this.comboBox139.FormattingEnabled = true;
            this.comboBox139.Location = new System.Drawing.Point(157, 49);
            this.comboBox139.Name = "comboBox139";
            this.comboBox139.Size = new System.Drawing.Size(399, 20);
            this.comboBox139.TabIndex = 8;
            // 
            // comboBox137
            // 
            this.comboBox137.FormattingEnabled = true;
            this.comboBox137.Location = new System.Drawing.Point(157, 23);
            this.comboBox137.Name = "comboBox137";
            this.comboBox137.Size = new System.Drawing.Size(88, 20);
            this.comboBox137.TabIndex = 8;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(231)))), ((int)(((byte)(239)))));
            this.tabPage5.Controls.Add(this.label162);
            this.tabPage5.Controls.Add(this.textBox42);
            this.tabPage5.Controls.Add(this.comboBox147);
            this.tabPage5.Controls.Add(this.comboBox145);
            this.tabPage5.Controls.Add(this.label159);
            this.tabPage5.Controls.Add(this.label157);
            this.tabPage5.Controls.Add(this.comboBox143);
            this.tabPage5.Controls.Add(this.comboBox149);
            this.tabPage5.Controls.Add(this.comboBox148);
            this.tabPage5.Controls.Add(this.comboBox146);
            this.tabPage5.Controls.Add(this.label161);
            this.tabPage5.Controls.Add(this.comboBox144);
            this.tabPage5.Controls.Add(this.label160);
            this.tabPage5.Controls.Add(this.label155);
            this.tabPage5.Controls.Add(this.label158);
            this.tabPage5.Controls.Add(this.label156);
            this.tabPage5.Controls.Add(this.comboBox142);
            this.tabPage5.Controls.Add(this.label154);
            this.tabPage5.Location = new System.Drawing.Point(4, 24);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(848, 422);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "   其 他   ";
            // 
            // label162
            // 
            this.label162.AutoSize = true;
            this.label162.Location = new System.Drawing.Point(118, 133);
            this.label162.Name = "label162";
            this.label162.Size = new System.Drawing.Size(53, 12);
            this.label162.TabIndex = 3;
            this.label162.Text = "病史小结";
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(173, 130);
            this.textBox42.Multiline = true;
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(474, 241);
            this.textBox42.TabIndex = 2;
            // 
            // comboBox147
            // 
            this.comboBox147.FormattingEnabled = true;
            this.comboBox147.Location = new System.Drawing.Point(356, 67);
            this.comboBox147.Name = "comboBox147";
            this.comboBox147.Size = new System.Drawing.Size(92, 20);
            this.comboBox147.TabIndex = 1;
            // 
            // comboBox145
            // 
            this.comboBox145.FormattingEnabled = true;
            this.comboBox145.Location = new System.Drawing.Point(356, 46);
            this.comboBox145.Name = "comboBox145";
            this.comboBox145.Size = new System.Drawing.Size(92, 20);
            this.comboBox145.TabIndex = 1;
            // 
            // label159
            // 
            this.label159.AutoSize = true;
            this.label159.Location = new System.Drawing.Point(285, 70);
            this.label159.Name = "label159";
            this.label159.Size = new System.Drawing.Size(65, 12);
            this.label159.TabIndex = 0;
            this.label159.Text = "ET内管长度";
            // 
            // label157
            // 
            this.label157.AutoSize = true;
            this.label157.Location = new System.Drawing.Point(297, 49);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(53, 12);
            this.label157.TabIndex = 0;
            this.label157.Text = "器械辅助";
            // 
            // comboBox143
            // 
            this.comboBox143.FormattingEnabled = true;
            this.comboBox143.Location = new System.Drawing.Point(356, 25);
            this.comboBox143.Name = "comboBox143";
            this.comboBox143.Size = new System.Drawing.Size(92, 20);
            this.comboBox143.TabIndex = 1;
            // 
            // comboBox149
            // 
            this.comboBox149.FormattingEnabled = true;
            this.comboBox149.Location = new System.Drawing.Point(173, 109);
            this.comboBox149.Name = "comboBox149";
            this.comboBox149.Size = new System.Drawing.Size(275, 20);
            this.comboBox149.TabIndex = 1;
            // 
            // comboBox148
            // 
            this.comboBox148.FormattingEnabled = true;
            this.comboBox148.Location = new System.Drawing.Point(173, 88);
            this.comboBox148.Name = "comboBox148";
            this.comboBox148.Size = new System.Drawing.Size(275, 20);
            this.comboBox148.TabIndex = 1;
            // 
            // comboBox146
            // 
            this.comboBox146.FormattingEnabled = true;
            this.comboBox146.Location = new System.Drawing.Point(173, 67);
            this.comboBox146.Name = "comboBox146";
            this.comboBox146.Size = new System.Drawing.Size(92, 20);
            this.comboBox146.TabIndex = 1;
            // 
            // label161
            // 
            this.label161.AutoSize = true;
            this.label161.Location = new System.Drawing.Point(106, 112);
            this.label161.Name = "label161";
            this.label161.Size = new System.Drawing.Size(65, 12);
            this.label161.TabIndex = 0;
            this.label161.Text = "预移植总结";
            // 
            // comboBox144
            // 
            this.comboBox144.FormattingEnabled = true;
            this.comboBox144.Location = new System.Drawing.Point(173, 46);
            this.comboBox144.Name = "comboBox144";
            this.comboBox144.Size = new System.Drawing.Size(92, 20);
            this.comboBox144.TabIndex = 1;
            // 
            // label160
            // 
            this.label160.AutoSize = true;
            this.label160.Location = new System.Drawing.Point(118, 91);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(53, 12);
            this.label160.TabIndex = 0;
            this.label160.Text = "进入路径";
            // 
            // label155
            // 
            this.label155.AutoSize = true;
            this.label155.Location = new System.Drawing.Point(297, 28);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(53, 12);
            this.label155.TabIndex = 0;
            this.label155.Text = "宫颈深度";
            // 
            // label158
            // 
            this.label158.AutoSize = true;
            this.label158.Location = new System.Drawing.Point(106, 70);
            this.label158.Name = "label158";
            this.label158.Size = new System.Drawing.Size(65, 12);
            this.label158.TabIndex = 0;
            this.label158.Text = "ET外管长度";
            // 
            // label156
            // 
            this.label156.AutoSize = true;
            this.label156.Location = new System.Drawing.Point(118, 49);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(53, 12);
            this.label156.TabIndex = 0;
            this.label156.Text = "ET管型号";
            // 
            // comboBox142
            // 
            this.comboBox142.FormattingEnabled = true;
            this.comboBox142.Location = new System.Drawing.Point(173, 25);
            this.comboBox142.Name = "comboBox142";
            this.comboBox142.Size = new System.Drawing.Size(92, 20);
            this.comboBox142.TabIndex = 1;
            // 
            // label154
            // 
            this.label154.AutoSize = true;
            this.label154.Location = new System.Drawing.Point(58, 28);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(113, 12);
            this.label154.TabIndex = 0;
            this.label154.Text = "ET预测试：子宫位置";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.Location = new System.Drawing.Point(0, 425);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(856, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // label150
            // 
            this.label150.AutoSize = true;
            this.label150.Location = new System.Drawing.Point(21, 480);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(77, 12);
            this.label150.TabIndex = 12;
            this.label150.Text = "拟行用药方案";
            // 
            // 女方病例
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(231)))), ((int)(((byte)(239)))));
            this.ClientSize = new System.Drawing.Size(856, 450);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label150);
            this.Name = "女方病例";
            this.Text = "女方病例";
            this.Load += new System.EventHandler(this.女方病例_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox 肝炎_textBox;
        private System.Windows.Forms.TextBox 现病史_textBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox 主诉_TextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox comboBox26;
        private System.Windows.Forms.ComboBox comboBox25;
        private System.Windows.Forms.ComboBox comboBox23;
        private System.Windows.Forms.ComboBox comboBox24;
        private System.Windows.Forms.ComboBox comboBox22;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.ComboBox comboBox16;
        private System.Windows.Forms.ComboBox comboBox17;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.ComboBox comboBox18;
        private System.Windows.Forms.ComboBox comboBox19;
        private System.Windows.Forms.ComboBox comboBox20;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.ComboBox comboBox21;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label Appendicitis;
        private System.Windows.Forms.Label diseasesOfUrinarySystem;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label CardiovascularDiseases;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label kidneyDisease;
        private System.Windows.Forms.Label tubercular;
        private System.Windows.Forms.Label hepatitis;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.ComboBox Appendicitis_comboBox;
        private System.Windows.Forms.TextBox Appendicitis_textBox;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.ComboBox 性传播疾病史_comboBox;
        private System.Windows.Forms.ComboBox diseasesOfUrinarySystem_comboBox;
        private System.Windows.Forms.ComboBox 肾脏疾病_comboBox;
        private System.Windows.Forms.TextBox 性传播疾病史_textBox;
        private System.Windows.Forms.TextBox diseasesOfUrinarySystem_textBox;
        private System.Windows.Forms.TextBox 肾脏疾病_textBox;
        private System.Windows.Forms.ComboBox 盆腔炎_comboBox;
        private System.Windows.Forms.ComboBox 结核_comboBox;
        private System.Windows.Forms.ComboBox 心血管疾病_comboBox;
        private System.Windows.Forms.TextBox 盆腔炎_textBox;
        private System.Windows.Forms.TextBox 结核_textbox;
        private System.Windows.Forms.TextBox 心血管疾病_textBox;
        private System.Windows.Forms.ComboBox 肝炎_comboBox;
        private System.Windows.Forms.ComboBox comboBox39;
        private System.Windows.Forms.ComboBox comboBox35;
        private System.Windows.Forms.ComboBox comboBox38;
        private System.Windows.Forms.ComboBox comboBox34;
        private System.Windows.Forms.ComboBox comboBox29;
        private System.Windows.Forms.ComboBox comboBox28;
        private System.Windows.Forms.ComboBox comboBox37;
        private System.Windows.Forms.ComboBox comboBox33;
        private System.Windows.Forms.ComboBox comboBox31;
        private System.Windows.Forms.ComboBox comboBox36;
        private System.Windows.Forms.ComboBox comboBox32;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.ComboBox comboBox30;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.ComboBox comboBox27;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox comboBox44;
        private System.Windows.Forms.ComboBox comboBox43;
        private System.Windows.Forms.ComboBox comboBox42;
        private System.Windows.Forms.ComboBox comboBox40;
        private System.Windows.Forms.ComboBox comboBox41;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.ComboBox comboBox45;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.ComboBox comboBox52;
        private System.Windows.Forms.ComboBox comboBox56;
        private System.Windows.Forms.ComboBox comboBox48;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.ComboBox comboBox59;
        private System.Windows.Forms.ComboBox comboBox51;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.ComboBox comboBox55;
        private System.Windows.Forms.ComboBox comboBox58;
        private System.Windows.Forms.ComboBox comboBox47;
        private System.Windows.Forms.ComboBox comboBox50;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.ComboBox comboBox54;
        private System.Windows.Forms.ComboBox comboBox46;
        private System.Windows.Forms.ComboBox comboBox57;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.ComboBox comboBox49;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.ComboBox comboBox53;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.ComboBox comboBox61;
        private System.Windows.Forms.ComboBox comboBox63;
        private System.Windows.Forms.ComboBox comboBox65;
        private System.Windows.Forms.ComboBox comboBox68;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.ComboBox comboBox69;
        private System.Windows.Forms.ComboBox comboBox70;
        private System.Windows.Forms.ComboBox comboBox72;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.ComboBox comboBox73;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.ComboBox comboBox74;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.ComboBox comboBox83;
        private System.Windows.Forms.ComboBox comboBox84;
        private System.Windows.Forms.ComboBox comboBox64;
        private System.Windows.Forms.ComboBox comboBox71;
        private System.Windows.Forms.ComboBox comboBox66;
        private System.Windows.Forms.ComboBox comboBox62;
        private System.Windows.Forms.ComboBox comboBox60;
        private System.Windows.Forms.ComboBox comboBox67;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.ComboBox comboBox82;
        private System.Windows.Forms.ComboBox comboBox81;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.ComboBox comboBox80;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.ComboBox comboBox79;
        private System.Windows.Forms.ComboBox comboBox78;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.ComboBox comboBox77;
        private System.Windows.Forms.ComboBox comboBox76;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.ComboBox comboBox75;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.ComboBox comboBox87;
        private System.Windows.Forms.ComboBox comboBox88;
        private System.Windows.Forms.ComboBox comboBox86;
        private System.Windows.Forms.ComboBox comboBox85;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.ComboBox comboBox120;
        private System.Windows.Forms.ComboBox comboBox119;
        private System.Windows.Forms.ComboBox comboBox116;
        private System.Windows.Forms.ComboBox comboBox115;
        private System.Windows.Forms.ComboBox comboBox111;
        private System.Windows.Forms.ComboBox comboBox118;
        private System.Windows.Forms.ComboBox comboBox114;
        private System.Windows.Forms.ComboBox comboBox110;
        private System.Windows.Forms.ComboBox comboBox106;
        private System.Windows.Forms.ComboBox comboBox117;
        private System.Windows.Forms.ComboBox comboBox102;
        private System.Windows.Forms.ComboBox comboBox113;
        private System.Windows.Forms.ComboBox comboBox109;
        private System.Windows.Forms.ComboBox comboBox105;
        private System.Windows.Forms.ComboBox comboBox92;
        private System.Windows.Forms.ComboBox comboBox101;
        private System.Windows.Forms.ComboBox comboBox94;
        private System.Windows.Forms.ComboBox comboBox97;
        private System.Windows.Forms.ComboBox comboBox91;
        private System.Windows.Forms.ComboBox comboBox93;
        private System.Windows.Forms.ComboBox comboBox90;
        private System.Windows.Forms.ComboBox comboBox89;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.ComboBox comboBox130;
        private System.Windows.Forms.ComboBox comboBox129;
        private System.Windows.Forms.ComboBox comboBox122;
        private System.Windows.Forms.ComboBox comboBox107;
        private System.Windows.Forms.ComboBox comboBox98;
        private System.Windows.Forms.ComboBox comboBox133;
        private System.Windows.Forms.ComboBox comboBox131;
        private System.Windows.Forms.ComboBox comboBox128;
        private System.Windows.Forms.ComboBox comboBox121;
        private System.Windows.Forms.ComboBox comboBox126;
        private System.Windows.Forms.ComboBox comboBox104;
        private System.Windows.Forms.ComboBox comboBox96;
        private System.Windows.Forms.ComboBox comboBox125;
        private System.Windows.Forms.ComboBox comboBox124;
        private System.Windows.Forms.ComboBox comboBox132;
        private System.Windows.Forms.ComboBox comboBox108;
        private System.Windows.Forms.ComboBox comboBox127;
        private System.Windows.Forms.ComboBox comboBox103;
        private System.Windows.Forms.ComboBox comboBox112;
        private System.Windows.Forms.ComboBox comboBox123;
        private System.Windows.Forms.ComboBox comboBox100;
        private System.Windows.Forms.ComboBox comboBox99;
        private System.Windows.Forms.ComboBox comboBox95;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.ComboBox comboBox135;
        private System.Windows.Forms.ComboBox comboBox136;
        private System.Windows.Forms.ComboBox comboBox134;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox30;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox29;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.CheckBox checkBox28;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.ComboBox comboBox138;
        private System.Windows.Forms.ComboBox comboBox139;
        private System.Windows.Forms.ComboBox comboBox137;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.ComboBox comboBox141;
        private System.Windows.Forms.ComboBox comboBox140;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label162;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.ComboBox comboBox147;
        private System.Windows.Forms.ComboBox comboBox145;
        private System.Windows.Forms.Label label159;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.ComboBox comboBox143;
        private System.Windows.Forms.ComboBox comboBox149;
        private System.Windows.Forms.ComboBox comboBox148;
        private System.Windows.Forms.ComboBox comboBox146;
        private System.Windows.Forms.Label label161;
        private System.Windows.Forms.ComboBox comboBox144;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.Label label158;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.ComboBox comboBox142;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.DateTimePicker 初诊日期_dateTimePicker;

    }
}