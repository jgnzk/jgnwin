﻿namespace 生殖中心病例管理系统
{
    partial class 新增患者
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.女方身份证_splitContainer = new System.Windows.Forms.SplitContainer();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.男方身份证_splitContainer = new System.Windows.Forms.SplitContainer();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.女方电话_textBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.详细住址_textBox = new System.Windows.Forms.TextBox();
            this.男方电话_textBox = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.市_comboBox = new System.Windows.Forms.ComboBox();
            this.县_comboBox = new System.Windows.Forms.ComboBox();
            this.省_comboBox = new System.Windows.Forms.ComboBox();
            this.其他电话3_textBox = new System.Windows.Forms.TextBox();
            this.其他电话4_textBox = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.其他电话2_textBox = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.其他电话1_textBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.男方出生日期_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.男方民族_comboBox = new System.Windows.Forms.ComboBox();
            this.男方文化程度_comboBox = new System.Windows.Forms.ComboBox();
            this.男方婚姻_comboBox = new System.Windows.Forms.ComboBox();
            this.男方职业_comboBox = new System.Windows.Forms.ComboBox();
            this.男方年龄_comboBox = new System.Windows.Forms.ComboBox();
            this.男方证件号_textBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.男方姓名_textBox = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.男方户口住址_textBox = new System.Windows.Forms.TextBox();
            this.男方邮政编码_textBox = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.女方信息_groupBox = new System.Windows.Forms.GroupBox();
            this.女方出生日期_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.女方民族_comboBox = new System.Windows.Forms.ComboBox();
            this.女方文化程度_comboBox = new System.Windows.Forms.ComboBox();
            this.女方婚姻_comboBox = new System.Windows.Forms.ComboBox();
            this.女方职业_comboBox = new System.Windows.Forms.ComboBox();
            this.女方年龄_comboBox = new System.Windows.Forms.ComboBox();
            this.女方证件号_textBox = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.女方姓名_textBox = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.女方户口住址_textBox = new System.Windows.Forms.TextBox();
            this.女方邮政编码_textBox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.病历号_textBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.序号_textBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.男方HIS_textBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.女方HIS_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.读身份证_button = new System.Windows.Forms.Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.生育证_pictureBox = new System.Windows.Forms.PictureBox();
            this.结婚证_pictureBox = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.男方照片_pictureBox = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.女方照片pictureBox = new System.Windows.Forms.PictureBox();
            this.三证扫描_button = new System.Windows.Forms.Button();
            this.三证扫描确认_button = new System.Windows.Forms.Button();
            this.指纹登记_button = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.女方身份证_splitContainer.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.男方身份证_splitContainer.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.女方信息_groupBox.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.生育证_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.结婚证_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.男方照片_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.女方照片pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(231)))), ((int)(((byte)(239)))));
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.女方信息_groupBox);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(968, 737);
            this.panel1.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button5);
            this.panel3.Controls.Add(this.button4);
            this.panel3.Controls.Add(this.指纹登记_button);
            this.panel3.Controls.Add(this.三证扫描确认_button);
            this.panel3.Controls.Add(this.三证扫描_button);
            this.panel3.Controls.Add(this.读身份证_button);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 697);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(968, 61);
            this.panel3.TabIndex = 18;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pictureBox6);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.女方身份证_splitContainer);
            this.groupBox3.Controls.Add(this.groupBox7);
            this.groupBox3.Controls.Add(this.groupBox6);
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Location = new System.Drawing.Point(32, 409);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(876, 288);
            this.groupBox3.TabIndex = 17;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "       证件扫描";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(130, 260);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(99, 20);
            this.label11.TabIndex = 1;
            this.label11.Text = "已连接/未连接";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(27, 260);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 20);
            this.label10.TabIndex = 1;
            this.label10.Text = "扫描仪连接状态：";
            // 
            // 女方身份证_splitContainer
            // 
            this.女方身份证_splitContainer.IsSplitterFixed = true;
            this.女方身份证_splitContainer.Location = new System.Drawing.Point(33, 34);
            this.女方身份证_splitContainer.Name = "女方身份证_splitContainer";
            this.女方身份证_splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.女方身份证_splitContainer.Panel2MinSize = 1;
            this.女方身份证_splitContainer.Size = new System.Drawing.Size(172, 216);
            this.女方身份证_splitContainer.SplitterDistance = 108;
            this.女方身份证_splitContainer.SplitterWidth = 1;
            this.女方身份证_splitContainer.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.生育证_pictureBox);
            this.groupBox7.Location = new System.Drawing.Point(669, 34);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(172, 216);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "生育证";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.结婚证_pictureBox);
            this.groupBox6.Location = new System.Drawing.Point(465, 33);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(172, 216);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "结婚证";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.男方身份证_splitContainer);
            this.groupBox5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox5.Location = new System.Drawing.Point(243, 19);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(176, 231);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "男方身份证";
            // 
            // 男方身份证_splitContainer
            // 
            this.男方身份证_splitContainer.IsSplitterFixed = true;
            this.男方身份证_splitContainer.Location = new System.Drawing.Point(0, 14);
            this.男方身份证_splitContainer.Name = "男方身份证_splitContainer";
            this.男方身份证_splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // 男方身份证_splitContainer.Panel1
            // 
            this.男方身份证_splitContainer.Panel1.Tag = "";
            this.男方身份证_splitContainer.Panel2MinSize = 1;
            this.男方身份证_splitContainer.Size = new System.Drawing.Size(172, 216);
            this.男方身份证_splitContainer.SplitterDistance = 108;
            this.男方身份证_splitContainer.SplitterWidth = 1;
            this.男方身份证_splitContainer.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox4.Location = new System.Drawing.Point(31, 19);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(176, 245);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "女方身份证";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pictureBox5);
            this.groupBox2.Controls.Add(this.女方电话_textBox);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.详细住址_textBox);
            this.groupBox2.Controls.Add(this.男方电话_textBox);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.市_comboBox);
            this.groupBox2.Controls.Add(this.县_comboBox);
            this.groupBox2.Controls.Add(this.省_comboBox);
            this.groupBox2.Controls.Add(this.其他电话3_textBox);
            this.groupBox2.Controls.Add(this.其他电话4_textBox);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.其他电话2_textBox);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.其他电话1_textBox);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Location = new System.Drawing.Point(30, 296);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(876, 110);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "        联系方式";
            // 
            // 女方电话_textBox
            // 
            this.女方电话_textBox.Location = new System.Drawing.Point(93, 20);
            this.女方电话_textBox.Name = "女方电话_textBox";
            this.女方电话_textBox.Size = new System.Drawing.Size(125, 26);
            this.女方电话_textBox.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(27, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 14);
            this.label8.TabIndex = 0;
            this.label8.Text = "女方电话:";
            // 
            // 详细住址_textBox
            // 
            this.详细住址_textBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.详细住址_textBox.Location = new System.Drawing.Point(354, 87);
            this.详细住址_textBox.Name = "详细住址_textBox";
            this.详细住址_textBox.Size = new System.Drawing.Size(432, 23);
            this.详细住址_textBox.TabIndex = 9;
            // 
            // 男方电话_textBox
            // 
            this.男方电话_textBox.Location = new System.Drawing.Point(93, 52);
            this.男方电话_textBox.Name = "男方电话_textBox";
            this.男方电话_textBox.Size = new System.Drawing.Size(125, 26);
            this.男方电话_textBox.TabIndex = 9;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.Location = new System.Drawing.Point(21, 88);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(70, 14);
            this.label34.TabIndex = 0;
            this.label34.Text = "通讯地址:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(27, 55);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 14);
            this.label9.TabIndex = 0;
            this.label9.Text = "男方电话：";
            // 
            // 市_comboBox
            // 
            this.市_comboBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.市_comboBox.FormattingEnabled = true;
            this.市_comboBox.Location = new System.Drawing.Point(179, 84);
            this.市_comboBox.Name = "市_comboBox";
            this.市_comboBox.Size = new System.Drawing.Size(83, 25);
            this.市_comboBox.TabIndex = 8;
            this.市_comboBox.Text = "            市";
            // 
            // 县_comboBox
            // 
            this.县_comboBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.县_comboBox.FormattingEnabled = true;
            this.县_comboBox.Location = new System.Drawing.Point(264, 85);
            this.县_comboBox.Name = "县_comboBox";
            this.县_comboBox.Size = new System.Drawing.Size(85, 25);
            this.县_comboBox.TabIndex = 8;
            this.县_comboBox.Text = "        县/区";
            // 
            // 省_comboBox
            // 
            this.省_comboBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.省_comboBox.FormattingEnabled = true;
            this.省_comboBox.Location = new System.Drawing.Point(92, 84);
            this.省_comboBox.Name = "省_comboBox";
            this.省_comboBox.Size = new System.Drawing.Size(83, 25);
            this.省_comboBox.TabIndex = 8;
            this.省_comboBox.Text = "            省";
            // 
            // 其他电话3_textBox
            // 
            this.其他电话3_textBox.Location = new System.Drawing.Point(650, 21);
            this.其他电话3_textBox.Name = "其他电话3_textBox";
            this.其他电话3_textBox.Size = new System.Drawing.Size(142, 26);
            this.其他电话3_textBox.TabIndex = 11;
            // 
            // 其他电话4_textBox
            // 
            this.其他电话4_textBox.Location = new System.Drawing.Point(650, 52);
            this.其他电话4_textBox.Name = "其他电话4_textBox";
            this.其他电话4_textBox.Size = new System.Drawing.Size(142, 26);
            this.其他电话4_textBox.TabIndex = 11;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(567, 55);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 14);
            this.label14.TabIndex = 0;
            this.label14.Text = "其他电话4:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label32.Location = new System.Drawing.Point(302, 29);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(77, 14);
            this.label32.TabIndex = 0;
            this.label32.Text = "其他电话1:";
            // 
            // 其他电话2_textBox
            // 
            this.其他电话2_textBox.Location = new System.Drawing.Point(379, 52);
            this.其他电话2_textBox.Name = "其他电话2_textBox";
            this.其他电话2_textBox.Size = new System.Drawing.Size(127, 26);
            this.其他电话2_textBox.TabIndex = 10;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.Location = new System.Drawing.Point(567, 28);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(77, 14);
            this.label33.TabIndex = 0;
            this.label33.Text = "其他电话3:";
            // 
            // 其他电话1_textBox
            // 
            this.其他电话1_textBox.Location = new System.Drawing.Point(379, 22);
            this.其他电话1_textBox.Name = "其他电话1_textBox";
            this.其他电话1_textBox.Size = new System.Drawing.Size(127, 26);
            this.其他电话1_textBox.TabIndex = 10;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(302, 55);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 14);
            this.label13.TabIndex = 0;
            this.label13.Text = "其他电话2:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.男方照片_pictureBox);
            this.groupBox1.Controls.Add(this.男方出生日期_dateTimePicker);
            this.groupBox1.Controls.Add(this.男方民族_comboBox);
            this.groupBox1.Controls.Add(this.男方文化程度_comboBox);
            this.groupBox1.Controls.Add(this.男方婚姻_comboBox);
            this.groupBox1.Controls.Add(this.男方职业_comboBox);
            this.groupBox1.Controls.Add(this.男方年龄_comboBox);
            this.groupBox1.Controls.Add(this.男方证件号_textBox);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.男方姓名_textBox);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.男方户口住址_textBox);
            this.groupBox1.Controls.Add(this.男方邮政编码_textBox);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(504, 79);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(464, 208);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "        男方信息";
            // 
            // 男方出生日期_dateTimePicker
            // 
            this.男方出生日期_dateTimePicker.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.男方出生日期_dateTimePicker.Location = new System.Drawing.Point(95, 65);
            this.男方出生日期_dateTimePicker.Name = "男方出生日期_dateTimePicker";
            this.男方出生日期_dateTimePicker.Size = new System.Drawing.Size(112, 23);
            this.男方出生日期_dateTimePicker.TabIndex = 9;
            this.男方出生日期_dateTimePicker.Value = new System.DateTime(1990, 11, 30, 0, 0, 0, 0);
            // 
            // 男方民族_comboBox
            // 
            this.男方民族_comboBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.男方民族_comboBox.FormattingEnabled = true;
            this.男方民族_comboBox.Location = new System.Drawing.Point(251, 113);
            this.男方民族_comboBox.Name = "男方民族_comboBox";
            this.男方民族_comboBox.Size = new System.Drawing.Size(53, 25);
            this.男方民族_comboBox.TabIndex = 8;
            // 
            // 男方文化程度_comboBox
            // 
            this.男方文化程度_comboBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.男方文化程度_comboBox.FormattingEnabled = true;
            this.男方文化程度_comboBox.Location = new System.Drawing.Point(95, 113);
            this.男方文化程度_comboBox.Name = "男方文化程度_comboBox";
            this.男方文化程度_comboBox.Size = new System.Drawing.Size(53, 25);
            this.男方文化程度_comboBox.TabIndex = 8;
            // 
            // 男方婚姻_comboBox
            // 
            this.男方婚姻_comboBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.男方婚姻_comboBox.FormattingEnabled = true;
            this.男方婚姻_comboBox.Location = new System.Drawing.Point(251, 89);
            this.男方婚姻_comboBox.Name = "男方婚姻_comboBox";
            this.男方婚姻_comboBox.Size = new System.Drawing.Size(53, 25);
            this.男方婚姻_comboBox.TabIndex = 8;
            // 
            // 男方职业_comboBox
            // 
            this.男方职业_comboBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.男方职业_comboBox.FormattingEnabled = true;
            this.男方职业_comboBox.Location = new System.Drawing.Point(95, 88);
            this.男方职业_comboBox.Name = "男方职业_comboBox";
            this.男方职业_comboBox.Size = new System.Drawing.Size(53, 25);
            this.男方职业_comboBox.TabIndex = 8;
            // 
            // 男方年龄_comboBox
            // 
            this.男方年龄_comboBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.男方年龄_comboBox.FormattingEnabled = true;
            this.男方年龄_comboBox.Location = new System.Drawing.Point(251, 64);
            this.男方年龄_comboBox.Name = "男方年龄_comboBox";
            this.男方年龄_comboBox.Size = new System.Drawing.Size(53, 25);
            this.男方年龄_comboBox.TabIndex = 8;
            // 
            // 男方证件号_textBox
            // 
            this.男方证件号_textBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.男方证件号_textBox.Location = new System.Drawing.Point(95, 42);
            this.男方证件号_textBox.Name = "男方证件号_textBox";
            this.男方证件号_textBox.Size = new System.Drawing.Size(209, 23);
            this.男方证件号_textBox.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(28, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 21);
            this.label6.TabIndex = 0;
            this.label6.Text = "证件号：";
            // 
            // 男方姓名_textBox
            // 
            this.男方姓名_textBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.男方姓名_textBox.Location = new System.Drawing.Point(95, 20);
            this.男方姓名_textBox.Name = "男方姓名_textBox";
            this.男方姓名_textBox.Size = new System.Drawing.Size(209, 23);
            this.男方姓名_textBox.TabIndex = 4;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.Location = new System.Drawing.Point(208, 115);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(46, 21);
            this.label23.TabIndex = 0;
            this.label23.Text = "民族:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.Location = new System.Drawing.Point(44, 23);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(58, 21);
            this.label24.TabIndex = 0;
            this.label24.Text = "姓名：";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.Location = new System.Drawing.Point(14, 114);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(90, 21);
            this.label25.TabIndex = 0;
            this.label25.Text = "文化程度：";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.Location = new System.Drawing.Point(208, 91);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(46, 21);
            this.label26.TabIndex = 0;
            this.label26.Text = "婚姻:";
            // 
            // 男方户口住址_textBox
            // 
            this.男方户口住址_textBox.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.男方户口住址_textBox.Location = new System.Drawing.Point(95, 161);
            this.男方户口住址_textBox.Name = "男方户口住址_textBox";
            this.男方户口住址_textBox.Size = new System.Drawing.Size(344, 29);
            this.男方户口住址_textBox.TabIndex = 7;
            // 
            // 男方邮政编码_textBox
            // 
            this.男方邮政编码_textBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.男方邮政编码_textBox.Location = new System.Drawing.Point(95, 138);
            this.男方邮政编码_textBox.Name = "男方邮政编码_textBox";
            this.男方邮政编码_textBox.Size = new System.Drawing.Size(189, 23);
            this.男方邮政编码_textBox.TabIndex = 7;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(45, 88);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(58, 21);
            this.label27.TabIndex = 0;
            this.label27.Text = "职业：";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label28.Location = new System.Drawing.Point(13, 66);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(90, 21);
            this.label28.TabIndex = 0;
            this.label28.Text = "出生日期：";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label29.Location = new System.Drawing.Point(12, 164);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(90, 21);
            this.label29.TabIndex = 0;
            this.label29.Text = "户口住址：";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label30.Location = new System.Drawing.Point(208, 65);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(46, 21);
            this.label30.TabIndex = 0;
            this.label30.Text = "年龄:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.Location = new System.Drawing.Point(14, 136);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(90, 21);
            this.label31.TabIndex = 0;
            this.label31.Text = "邮政编码：";
            // 
            // 女方信息_groupBox
            // 
            this.女方信息_groupBox.Controls.Add(this.pictureBox3);
            this.女方信息_groupBox.Controls.Add(this.女方照片pictureBox);
            this.女方信息_groupBox.Controls.Add(this.女方出生日期_dateTimePicker);
            this.女方信息_groupBox.Controls.Add(this.女方民族_comboBox);
            this.女方信息_groupBox.Controls.Add(this.女方文化程度_comboBox);
            this.女方信息_groupBox.Controls.Add(this.女方婚姻_comboBox);
            this.女方信息_groupBox.Controls.Add(this.女方职业_comboBox);
            this.女方信息_groupBox.Controls.Add(this.女方年龄_comboBox);
            this.女方信息_groupBox.Controls.Add(this.女方证件号_textBox);
            this.女方信息_groupBox.Controls.Add(this.label18);
            this.女方信息_groupBox.Controls.Add(this.女方姓名_textBox);
            this.女方信息_groupBox.Controls.Add(this.label22);
            this.女方信息_groupBox.Controls.Add(this.label4);
            this.女方信息_groupBox.Controls.Add(this.label21);
            this.女方信息_groupBox.Controls.Add(this.label20);
            this.女方信息_groupBox.Controls.Add(this.女方户口住址_textBox);
            this.女方信息_groupBox.Controls.Add(this.女方邮政编码_textBox);
            this.女方信息_groupBox.Controls.Add(this.label19);
            this.女方信息_groupBox.Controls.Add(this.label16);
            this.女方信息_groupBox.Controls.Add(this.label5);
            this.女方信息_groupBox.Controls.Add(this.label17);
            this.女方信息_groupBox.Controls.Add(this.label7);
            this.女方信息_groupBox.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.女方信息_groupBox.Location = new System.Drawing.Point(32, 79);
            this.女方信息_groupBox.Name = "女方信息_groupBox";
            this.女方信息_groupBox.Size = new System.Drawing.Size(464, 208);
            this.女方信息_groupBox.TabIndex = 15;
            this.女方信息_groupBox.TabStop = false;
            this.女方信息_groupBox.Text = "        女方信息";
            // 
            // 女方出生日期_dateTimePicker
            // 
            this.女方出生日期_dateTimePicker.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.女方出生日期_dateTimePicker.Location = new System.Drawing.Point(95, 65);
            this.女方出生日期_dateTimePicker.Name = "女方出生日期_dateTimePicker";
            this.女方出生日期_dateTimePicker.Size = new System.Drawing.Size(112, 23);
            this.女方出生日期_dateTimePicker.TabIndex = 9;
            this.女方出生日期_dateTimePicker.Value = new System.DateTime(1990, 11, 30, 0, 0, 0, 0);
            // 
            // 女方民族_comboBox
            // 
            this.女方民族_comboBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.女方民族_comboBox.FormattingEnabled = true;
            this.女方民族_comboBox.Location = new System.Drawing.Point(251, 113);
            this.女方民族_comboBox.Name = "女方民族_comboBox";
            this.女方民族_comboBox.Size = new System.Drawing.Size(53, 25);
            this.女方民族_comboBox.TabIndex = 8;
            // 
            // 女方文化程度_comboBox
            // 
            this.女方文化程度_comboBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.女方文化程度_comboBox.FormattingEnabled = true;
            this.女方文化程度_comboBox.Location = new System.Drawing.Point(95, 113);
            this.女方文化程度_comboBox.Name = "女方文化程度_comboBox";
            this.女方文化程度_comboBox.Size = new System.Drawing.Size(53, 25);
            this.女方文化程度_comboBox.TabIndex = 8;
            // 
            // 女方婚姻_comboBox
            // 
            this.女方婚姻_comboBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.女方婚姻_comboBox.FormattingEnabled = true;
            this.女方婚姻_comboBox.Location = new System.Drawing.Point(251, 89);
            this.女方婚姻_comboBox.Name = "女方婚姻_comboBox";
            this.女方婚姻_comboBox.Size = new System.Drawing.Size(53, 25);
            this.女方婚姻_comboBox.TabIndex = 8;
            // 
            // 女方职业_comboBox
            // 
            this.女方职业_comboBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.女方职业_comboBox.FormattingEnabled = true;
            this.女方职业_comboBox.Location = new System.Drawing.Point(95, 88);
            this.女方职业_comboBox.Name = "女方职业_comboBox";
            this.女方职业_comboBox.Size = new System.Drawing.Size(53, 25);
            this.女方职业_comboBox.TabIndex = 8;
            // 
            // 女方年龄_comboBox
            // 
            this.女方年龄_comboBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.女方年龄_comboBox.FormattingEnabled = true;
            this.女方年龄_comboBox.Location = new System.Drawing.Point(251, 64);
            this.女方年龄_comboBox.Name = "女方年龄_comboBox";
            this.女方年龄_comboBox.Size = new System.Drawing.Size(53, 25);
            this.女方年龄_comboBox.TabIndex = 8;
            // 
            // 女方证件号_textBox
            // 
            this.女方证件号_textBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.女方证件号_textBox.Location = new System.Drawing.Point(95, 42);
            this.女方证件号_textBox.Name = "女方证件号_textBox";
            this.女方证件号_textBox.Size = new System.Drawing.Size(209, 23);
            this.女方证件号_textBox.TabIndex = 4;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(31, 42);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(74, 21);
            this.label18.TabIndex = 0;
            this.label18.Text = "证件号：";
            // 
            // 女方姓名_textBox
            // 
            this.女方姓名_textBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.女方姓名_textBox.Location = new System.Drawing.Point(95, 20);
            this.女方姓名_textBox.Name = "女方姓名_textBox";
            this.女方姓名_textBox.Size = new System.Drawing.Size(209, 23);
            this.女方姓名_textBox.TabIndex = 4;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.Location = new System.Drawing.Point(208, 115);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(46, 21);
            this.label22.TabIndex = 0;
            this.label22.Text = "民族:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(47, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 21);
            this.label4.TabIndex = 0;
            this.label4.Text = "姓名：";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(14, 114);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(90, 21);
            this.label21.TabIndex = 0;
            this.label21.Text = "文化程度：";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(208, 91);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(46, 21);
            this.label20.TabIndex = 0;
            this.label20.Text = "婚姻:";
            // 
            // 女方户口住址_textBox
            // 
            this.女方户口住址_textBox.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.女方户口住址_textBox.Location = new System.Drawing.Point(95, 161);
            this.女方户口住址_textBox.Name = "女方户口住址_textBox";
            this.女方户口住址_textBox.Size = new System.Drawing.Size(344, 29);
            this.女方户口住址_textBox.TabIndex = 7;
            // 
            // 女方邮政编码_textBox
            // 
            this.女方邮政编码_textBox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.女方邮政编码_textBox.Location = new System.Drawing.Point(95, 138);
            this.女方邮政编码_textBox.Name = "女方邮政编码_textBox";
            this.女方邮政编码_textBox.Size = new System.Drawing.Size(189, 23);
            this.女方邮政编码_textBox.TabIndex = 7;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(44, 89);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(58, 21);
            this.label19.TabIndex = 0;
            this.label19.Text = "职业：";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(14, 66);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(90, 21);
            this.label16.TabIndex = 0;
            this.label16.Text = "出生日期：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(12, 164);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 21);
            this.label5.TabIndex = 0;
            this.label5.Text = "户口住址：";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(208, 65);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(46, 21);
            this.label17.TabIndex = 0;
            this.label17.Text = "年龄:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(14, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 21);
            this.label7.TabIndex = 0;
            this.label7.Text = "邮政编码：";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.病历号_textBox);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.序号_textBox);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.男方HIS_textBox);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.女方HIS_textBox);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(32, 38);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(927, 40);
            this.panel2.TabIndex = 14;
            // 
            // 病历号_textBox
            // 
            this.病历号_textBox.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.病历号_textBox.Location = new System.Drawing.Point(73, 7);
            this.病历号_textBox.Name = "病历号_textBox";
            this.病历号_textBox.Size = new System.Drawing.Size(100, 29);
            this.病历号_textBox.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(8, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 21);
            this.label3.TabIndex = 0;
            this.label3.Text = "病例号：";
            // 
            // 序号_textBox
            // 
            this.序号_textBox.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.序号_textBox.Location = new System.Drawing.Point(227, 5);
            this.序号_textBox.Name = "序号_textBox";
            this.序号_textBox.Size = new System.Drawing.Size(100, 29);
            this.序号_textBox.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(179, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 21);
            this.label2.TabIndex = 0;
            this.label2.Text = "序号：";
            // 
            // 男方HIS_textBox
            // 
            this.男方HIS_textBox.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.男方HIS_textBox.Location = new System.Drawing.Point(603, 7);
            this.男方HIS_textBox.Name = "男方HIS_textBox";
            this.男方HIS_textBox.Size = new System.Drawing.Size(100, 29);
            this.男方HIS_textBox.TabIndex = 1;
            this.男方HIS_textBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.date_MouseDown);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(522, 9);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(84, 21);
            this.label15.TabIndex = 0;
            this.label15.Text = "男方HIS：";
            // 
            // 女方HIS_textBox
            // 
            this.女方HIS_textBox.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.女方HIS_textBox.Location = new System.Drawing.Point(408, 6);
            this.女方HIS_textBox.Name = "女方HIS_textBox";
            this.女方HIS_textBox.Size = new System.Drawing.Size(100, 29);
            this.女方HIS_textBox.TabIndex = 1;
            this.女方HIS_textBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.date_MouseDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(333, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "女方HIS：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(65, 576);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 14);
            this.label12.TabIndex = 0;
            this.label12.Text = "诊断";
            // 
            // 读身份证_button
            // 
            this.读身份证_button.BackgroundImage = global::生殖中心病例管理系统.Properties.Resources.读身份证1;
            this.读身份证_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.读身份证_button.Location = new System.Drawing.Point(3, 9);
            this.读身份证_button.Name = "读身份证_button";
            this.读身份证_button.Size = new System.Drawing.Size(158, 49);
            this.读身份证_button.TabIndex = 0;
            this.读身份证_button.UseVisualStyleBackColor = true;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = global::生殖中心病例管理系统.Properties.Resources.扫描1;
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Location = new System.Drawing.Point(-2, 0);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(37, 35);
            this.pictureBox6.TabIndex = 18;
            this.pictureBox6.TabStop = false;
            // 
            // 生育证_pictureBox
            // 
            this.生育证_pictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.生育证_pictureBox.Location = new System.Drawing.Point(3, 22);
            this.生育证_pictureBox.Name = "生育证_pictureBox";
            this.生育证_pictureBox.Size = new System.Drawing.Size(166, 191);
            this.生育证_pictureBox.TabIndex = 0;
            this.生育证_pictureBox.TabStop = false;
            // 
            // 结婚证_pictureBox
            // 
            this.结婚证_pictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.结婚证_pictureBox.Location = new System.Drawing.Point(3, 22);
            this.结婚证_pictureBox.Name = "结婚证_pictureBox";
            this.结婚证_pictureBox.Size = new System.Drawing.Size(166, 191);
            this.结婚证_pictureBox.TabIndex = 0;
            this.结婚证_pictureBox.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = global::生殖中心病例管理系统.Properties.Resources.电话;
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(0, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(29, 33);
            this.pictureBox5.TabIndex = 18;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::生殖中心病例管理系统.Properties.Resources.男;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(0, -2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(29, 33);
            this.pictureBox2.TabIndex = 18;
            this.pictureBox2.TabStop = false;
            // 
            // 男方照片_pictureBox
            // 
            this.男方照片_pictureBox.Location = new System.Drawing.Point(310, 20);
            this.男方照片_pictureBox.Name = "男方照片_pictureBox";
            this.男方照片_pictureBox.Size = new System.Drawing.Size(120, 130);
            this.男方照片_pictureBox.TabIndex = 10;
            this.男方照片_pictureBox.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::生殖中心病例管理系统.Properties.Resources.女;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(0, -2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(29, 33);
            this.pictureBox3.TabIndex = 18;
            this.pictureBox3.TabStop = false;
            // 
            // 女方照片pictureBox
            // 
            this.女方照片pictureBox.Location = new System.Drawing.Point(310, 20);
            this.女方照片pictureBox.Name = "女方照片pictureBox";
            this.女方照片pictureBox.Size = new System.Drawing.Size(120, 130);
            this.女方照片pictureBox.TabIndex = 10;
            this.女方照片pictureBox.TabStop = false;
            // 
            // 三证扫描_button
            // 
            this.三证扫描_button.BackgroundImage = global::生殖中心病例管理系统.Properties.Resources.三证扫描1;
            this.三证扫描_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.三证扫描_button.Location = new System.Drawing.Point(166, 9);
            this.三证扫描_button.Name = "三证扫描_button";
            this.三证扫描_button.Size = new System.Drawing.Size(150, 52);
            this.三证扫描_button.TabIndex = 0;
            this.三证扫描_button.UseVisualStyleBackColor = true;
            // 
            // 三证扫描确认_button
            // 
            this.三证扫描确认_button.BackgroundImage = global::生殖中心病例管理系统.Properties.Resources.三证审核1;
            this.三证扫描确认_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.三证扫描确认_button.Location = new System.Drawing.Point(322, 8);
            this.三证扫描确认_button.Name = "三证扫描确认_button";
            this.三证扫描确认_button.Size = new System.Drawing.Size(172, 48);
            this.三证扫描确认_button.TabIndex = 0;
            this.三证扫描确认_button.UseVisualStyleBackColor = true;
            // 
            // 指纹登记_button
            // 
            this.指纹登记_button.BackgroundImage = global::生殖中心病例管理系统.Properties.Resources.指纹登记1;
            this.指纹登记_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.指纹登记_button.Location = new System.Drawing.Point(500, 10);
            this.指纹登记_button.Name = "指纹登记_button";
            this.指纹登记_button.Size = new System.Drawing.Size(155, 46);
            this.指纹登记_button.TabIndex = 0;
            this.指纹登记_button.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.BackgroundImage = global::生殖中心病例管理系统.Properties.Resources.保存1;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.Location = new System.Drawing.Point(674, 9);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(125, 47);
            this.button4.TabIndex = 0;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.BackgroundImage = global::生殖中心病例管理系统.Properties.Resources.退出1;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.Location = new System.Drawing.Point(814, 9);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(125, 47);
            this.button5.TabIndex = 0;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // 新增患者
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(968, 737);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "新增患者";
            this.Text = "新增患者";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.新增患者_FormClosing);
            this.Load += new System.EventHandler(this.基本信息_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.女方身份证_splitContainer.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.男方身份证_splitContainer.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.女方信息_groupBox.ResumeLayout(false);
            this.女方信息_groupBox.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.生育证_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.结婚证_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.男方照片_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.女方照片pictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox 女方HIS_textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox 男方电话_textBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox 女方电话_textBox;
        private System.Windows.Forms.TextBox 病历号_textBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox 女方邮政编码_textBox;
        private System.Windows.Forms.TextBox 序号_textBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox 女方姓名_textBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox 其他电话4_textBox;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox 其他电话2_textBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox 女方信息_groupBox;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox 男方HIS_textBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox 详细住址_textBox;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox 市_comboBox;
        private System.Windows.Forms.ComboBox 县_comboBox;
        private System.Windows.Forms.ComboBox 省_comboBox;
        private System.Windows.Forms.TextBox 其他电话3_textBox;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox 其他电话1_textBox;
        private System.Windows.Forms.PictureBox 女方照片pictureBox;
        private System.Windows.Forms.DateTimePicker 女方出生日期_dateTimePicker;
        private System.Windows.Forms.ComboBox 女方民族_comboBox;
        private System.Windows.Forms.ComboBox 女方文化程度_comboBox;
        private System.Windows.Forms.ComboBox 女方婚姻_comboBox;
        private System.Windows.Forms.ComboBox 女方职业_comboBox;
        private System.Windows.Forms.ComboBox 女方年龄_comboBox;
        private System.Windows.Forms.TextBox 女方证件号_textBox;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox 女方户口住址_textBox;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.SplitContainer 女方身份证_splitContainer;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.SplitContainer 男方身份证_splitContainer;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button 读身份证_button;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox 男方照片_pictureBox;
        private System.Windows.Forms.DateTimePicker 男方出生日期_dateTimePicker;
        private System.Windows.Forms.ComboBox 男方民族_comboBox;
        private System.Windows.Forms.ComboBox 男方文化程度_comboBox;
        private System.Windows.Forms.ComboBox 男方婚姻_comboBox;
        private System.Windows.Forms.ComboBox 男方职业_comboBox;
        private System.Windows.Forms.ComboBox 男方年龄_comboBox;
        private System.Windows.Forms.TextBox 男方证件号_textBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox 男方姓名_textBox;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox 男方户口住址_textBox;
        private System.Windows.Forms.TextBox 男方邮政编码_textBox;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.PictureBox 生育证_pictureBox;
        private System.Windows.Forms.PictureBox 结婚证_pictureBox;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button 指纹登记_button;
        private System.Windows.Forms.Button 三证扫描确认_button;
        private System.Windows.Forms.Button 三证扫描_button;
    }
}