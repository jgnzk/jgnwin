﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClass
{
    public class Class1
    {
        public void ss(bool sss )
        {
        
        }

    }
    
}
